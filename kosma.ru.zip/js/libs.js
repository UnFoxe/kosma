!(function (e, t) {
  "use strict";
  "object" == typeof module && "object" == typeof module.exports
    ? (module.exports = e.document
        ? t(e, !0)
        : function (e) {
            if (!e.document)
              throw new Error("jQuery requires a window with a document");
            return t(e);
          })
    : t(e);
})("undefined" != typeof window ? window : this, function (x, e) {
  "use strict";
  function g(e) {
    return null != e && e === e.window;
  }
  var t = [],
    S = x.document,
    i = Object.getPrototypeOf,
    a = t.slice,
    v = t.concat,
    l = t.push,
    o = t.indexOf,
    n = {},
    r = n.toString,
    m = n.hasOwnProperty,
    s = m.toString,
    u = s.call(Object),
    y = {},
    k = function (e) {
      return "function" == typeof e && "number" != typeof e.nodeType;
    },
    c = { type: !0, src: !0, nonce: !0, noModule: !0 };
  function b(e, t, n) {
    var i,
      o,
      r = (n = n || S).createElement("script");
    if (((r.text = e), t))
      for (i in c)
        (o = t[i] || (t.getAttribute && t.getAttribute(i))) &&
          r.setAttribute(i, o);
    n.head.appendChild(r).parentNode.removeChild(r);
  }
  function w(e) {
    return null == e
      ? e + ""
      : "object" == typeof e || "function" == typeof e
      ? n[r.call(e)] || "object"
      : typeof e;
  }
  var d = "3.4.1",
    T = function (e, t) {
      return new T.fn.init(e, t);
    },
    p = /^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g;
  function h(e) {
    var t = !!e && "length" in e && e.length,
      n = w(e);
    return (
      !k(e) &&
      !g(e) &&
      ("array" === n ||
        0 === t ||
        ("number" == typeof t && 0 < t && t - 1 in e))
    );
  }
  (T.fn = T.prototype = {
    jquery: d,
    constructor: T,
    length: 0,
    toArray: function () {
      return a.call(this);
    },
    get: function (e) {
      return null == e ? a.call(this) : e < 0 ? this[e + this.length] : this[e];
    },
    pushStack: function (e) {
      var t = T.merge(this.constructor(), e);
      return (t.prevObject = this), t;
    },
    each: function (e) {
      return T.each(this, e);
    },
    map: function (n) {
      return this.pushStack(
        T.map(this, function (e, t) {
          return n.call(e, t, e);
        })
      );
    },
    slice: function () {
      return this.pushStack(a.apply(this, arguments));
    },
    first: function () {
      return this.eq(0);
    },
    last: function () {
      return this.eq(-1);
    },
    eq: function (e) {
      var t = this.length,
        n = +e + (e < 0 ? t : 0);
      return this.pushStack(0 <= n && n < t ? [this[n]] : []);
    },
    end: function () {
      return this.prevObject || this.constructor();
    },
    push: l,
    sort: t.sort,
    splice: t.splice,
  }),
    (T.extend = T.fn.extend = function () {
      var e,
        t,
        n,
        i,
        o,
        r,
        s = arguments[0] || {},
        a = 1,
        l = arguments.length,
        u = !1;
      for (
        "boolean" == typeof s && ((u = s), (s = arguments[a] || {}), a++),
          "object" == typeof s || k(s) || (s = {}),
          a === l && ((s = this), a--);
        a < l;
        a++
      )
        if (null != (e = arguments[a]))
          for (t in e)
            (i = e[t]),
              "__proto__" !== t &&
                s !== i &&
                (u && i && (T.isPlainObject(i) || (o = Array.isArray(i)))
                  ? ((n = s[t]),
                    (r =
                      o && !Array.isArray(n)
                        ? []
                        : o || T.isPlainObject(n)
                        ? n
                        : {}),
                    (o = !1),
                    (s[t] = T.extend(u, r, i)))
                  : void 0 !== i && (s[t] = i));
      return s;
    }),
    T.extend({
      expando: "jQuery" + (d + Math.random()).replace(/\D/g, ""),
      isReady: !0,
      error: function (e) {
        throw new Error(e);
      },
      noop: function () {},
      isPlainObject: function (e) {
        var t, n;
        return !(
          !e ||
          "[object Object]" !== r.call(e) ||
          ((t = i(e)) &&
            ("function" !=
              typeof (n = m.call(t, "constructor") && t.constructor) ||
              s.call(n) !== u))
        );
      },
      isEmptyObject: function (e) {
        var t;
        for (t in e) return !1;
        return !0;
      },
      globalEval: function (e, t) {
        b(e, { nonce: t && t.nonce });
      },
      each: function (e, t) {
        var n,
          i = 0;
        if (h(e))
          for (n = e.length; i < n && !1 !== t.call(e[i], i, e[i]); i++);
        else for (i in e) if (!1 === t.call(e[i], i, e[i])) break;
        return e;
      },
      trim: function (e) {
        return null == e ? "" : (e + "").replace(p, "");
      },
      makeArray: function (e, t) {
        var n = t || [];
        return (
          null != e &&
            (h(Object(e))
              ? T.merge(n, "string" == typeof e ? [e] : e)
              : l.call(n, e)),
          n
        );
      },
      inArray: function (e, t, n) {
        return null == t ? -1 : o.call(t, e, n);
      },
      merge: function (e, t) {
        for (var n = +t.length, i = 0, o = e.length; i < n; i++) e[o++] = t[i];
        return (e.length = o), e;
      },
      grep: function (e, t, n) {
        for (var i = [], o = 0, r = e.length, s = !n; o < r; o++)
          !t(e[o], o) != s && i.push(e[o]);
        return i;
      },
      map: function (e, t, n) {
        var i,
          o,
          r = 0,
          s = [];
        if (h(e))
          for (i = e.length; r < i; r++)
            null != (o = t(e[r], r, n)) && s.push(o);
        else for (r in e) null != (o = t(e[r], r, n)) && s.push(o);
        return v.apply([], s);
      },
      guid: 1,
      support: y,
    }),
    "function" == typeof Symbol && (T.fn[Symbol.iterator] = t[Symbol.iterator]),
    T.each(
      "Boolean Number String Function Array Date RegExp Object Error Symbol".split(
        " "
      ),
      function (e, t) {
        n["[object " + t + "]"] = t.toLowerCase();
      }
    );
  var f = (function (n) {
    function d(e, t, n) {
      var i = "0x" + t - 65536;
      return i != i || n
        ? t
        : i < 0
        ? String.fromCharCode(65536 + i)
        : String.fromCharCode((i >> 10) | 55296, (1023 & i) | 56320);
    }
    function o() {
      C();
    }
    var e,
      h,
      b,
      r,
      s,
      f,
      p,
      g,
      w,
      l,
      u,
      C,
      x,
      a,
      S,
      v,
      c,
      m,
      y,
      T = "sizzle" + +new Date(),
      k = n.document,
      A = 0,
      i = 0,
      E = le(),
      $ = le(),
      _ = le(),
      D = le(),
      F = function (e, t) {
        return e === t && (u = !0), 0;
      },
      P = {}.hasOwnProperty,
      t = [],
      j = t.pop,
      O = t.push,
      M = t.push,
      B = t.slice,
      L = function (e, t) {
        for (var n = 0, i = e.length; n < i; n++) if (e[n] === t) return n;
        return -1;
      },
      I =
        "checked|selected|async|autofocus|autoplay|controls|defer|disabled|hidden|ismap|loop|multiple|open|readonly|required|scoped",
      N = "[\\x20\\t\\r\\n\\f]",
      H = "(?:\\\\.|[\\w-]|[^\0-\\xa0])+",
      q =
        "\\[" +
        N +
        "*(" +
        H +
        ")(?:" +
        N +
        "*([*^$|!~]?=)" +
        N +
        "*(?:'((?:\\\\.|[^\\\\'])*)'|\"((?:\\\\.|[^\\\\\"])*)\"|(" +
        H +
        "))|)" +
        N +
        "*\\]",
      R =
        ":(" +
        H +
        ")(?:\\((('((?:\\\\.|[^\\\\'])*)'|\"((?:\\\\.|[^\\\\\"])*)\")|((?:\\\\.|[^\\\\()[\\]]|" +
        q +
        ")*)|.*)\\)|)",
      z = new RegExp(N + "+", "g"),
      V = new RegExp("^" + N + "+|((?:^|[^\\\\])(?:\\\\.)*)" + N + "+$", "g"),
      W = new RegExp("^" + N + "*," + N + "*"),
      X = new RegExp("^" + N + "*([>+~]|" + N + ")" + N + "*"),
      Y = new RegExp(N + "|>"),
      U = new RegExp(R),
      G = new RegExp("^" + H + "$"),
      K = {
        ID: new RegExp("^#(" + H + ")"),
        CLASS: new RegExp("^\\.(" + H + ")"),
        TAG: new RegExp("^(" + H + "|[*])"),
        ATTR: new RegExp("^" + q),
        PSEUDO: new RegExp("^" + R),
        CHILD: new RegExp(
          "^:(only|first|last|nth|nth-last)-(child|of-type)(?:\\(" +
            N +
            "*(even|odd|(([+-]|)(\\d*)n|)" +
            N +
            "*(?:([+-]|)" +
            N +
            "*(\\d+)|))" +
            N +
            "*\\)|)",
          "i"
        ),
        bool: new RegExp("^(?:" + I + ")$", "i"),
        needsContext: new RegExp(
          "^" +
            N +
            "*[>+~]|:(even|odd|eq|gt|lt|nth|first|last)(?:\\(" +
            N +
            "*((?:-\\d)?\\d*)" +
            N +
            "*\\)|)(?=[^-]|$)",
          "i"
        ),
      },
      Q = /HTML$/i,
      Z = /^(?:input|select|textarea|button)$/i,
      J = /^h\d$/i,
      ee = /^[^{]+\{\s*\[native \w/,
      te = /^(?:#([\w-]+)|(\w+)|\.([\w-]+))$/,
      ne = /[+~]/,
      ie = new RegExp("\\\\([\\da-f]{1,6}" + N + "?|(" + N + ")|.)", "ig"),
      oe = /([\0-\x1f\x7f]|^-?\d)|^-$|[^\0-\x1f\x7f-\uFFFF\w-]/g,
      re = function (e, t) {
        return t
          ? "\0" === e
            ? "�"
            : e.slice(0, -1) +
              "\\" +
              e.charCodeAt(e.length - 1).toString(16) +
              " "
          : "\\" + e;
      },
      se = be(
        function (e) {
          return !0 === e.disabled && "fieldset" === e.nodeName.toLowerCase();
        },
        { dir: "parentNode", next: "legend" }
      );
    try {
      M.apply((t = B.call(k.childNodes)), k.childNodes),
        t[k.childNodes.length].nodeType;
    } catch (e) {
      M = {
        apply: t.length
          ? function (e, t) {
              O.apply(e, B.call(t));
            }
          : function (e, t) {
              for (var n = e.length, i = 0; (e[n++] = t[i++]); );
              e.length = n - 1;
            },
      };
    }
    function ae(e, t, n, i) {
      var o,
        r,
        s,
        a,
        l,
        u,
        c,
        d = t && t.ownerDocument,
        p = t ? t.nodeType : 9;
      if (
        ((n = n || []),
        "string" != typeof e || !e || (1 !== p && 9 !== p && 11 !== p))
      )
        return n;
      if (
        !i &&
        ((t ? t.ownerDocument || t : k) !== x && C(t), (t = t || x), S)
      ) {
        if (11 !== p && (l = te.exec(e)))
          if ((o = l[1])) {
            if (9 === p) {
              if (!(s = t.getElementById(o))) return n;
              if (s.id === o) return n.push(s), n;
            } else if (d && (s = d.getElementById(o)) && y(t, s) && s.id === o)
              return n.push(s), n;
          } else {
            if (l[2]) return M.apply(n, t.getElementsByTagName(e)), n;
            if (
              (o = l[3]) &&
              h.getElementsByClassName &&
              t.getElementsByClassName
            )
              return M.apply(n, t.getElementsByClassName(o)), n;
          }
        if (
          h.qsa &&
          !D[e + " "] &&
          (!v || !v.test(e)) &&
          (1 !== p || "object" !== t.nodeName.toLowerCase())
        ) {
          if (((c = e), (d = t), 1 === p && Y.test(e))) {
            for (
              (a = t.getAttribute("id"))
                ? (a = a.replace(oe, re))
                : t.setAttribute("id", (a = T)),
                r = (u = f(e)).length;
              r--;

            )
              u[r] = "#" + a + " " + ke(u[r]);
            (c = u.join(",")), (d = (ne.test(e) && me(t.parentNode)) || t);
          }
          try {
            return M.apply(n, d.querySelectorAll(c)), n;
          } catch (t) {
            D(e, !0);
          } finally {
            a === T && t.removeAttribute("id");
          }
        }
      }
      return g(e.replace(V, "$1"), t, n, i);
    }
    function le() {
      var i = [];
      return function e(t, n) {
        return (
          i.push(t + " ") > b.cacheLength && delete e[i.shift()],
          (e[t + " "] = n)
        );
      };
    }
    function ue(e) {
      return (e[T] = !0), e;
    }
    function ce(e) {
      var t = x.createElement("fieldset");
      try {
        return !!e(t);
      } catch (e) {
        return !1;
      } finally {
        t.parentNode && t.parentNode.removeChild(t), (t = null);
      }
    }
    function de(e, t) {
      for (var n = e.split("|"), i = n.length; i--; ) b.attrHandle[n[i]] = t;
    }
    function pe(e, t) {
      var n = t && e,
        i =
          n &&
          1 === e.nodeType &&
          1 === t.nodeType &&
          e.sourceIndex - t.sourceIndex;
      if (i) return i;
      if (n) for (; (n = n.nextSibling); ) if (n === t) return -1;
      return e ? 1 : -1;
    }
    function he(t) {
      return function (e) {
        return "input" === e.nodeName.toLowerCase() && e.type === t;
      };
    }
    function fe(n) {
      return function (e) {
        var t = e.nodeName.toLowerCase();
        return ("input" === t || "button" === t) && e.type === n;
      };
    }
    function ge(t) {
      return function (e) {
        return "form" in e
          ? e.parentNode && !1 === e.disabled
            ? "label" in e
              ? "label" in e.parentNode
                ? e.parentNode.disabled === t
                : e.disabled === t
              : e.isDisabled === t || (e.isDisabled !== !t && se(e) === t)
            : e.disabled === t
          : "label" in e && e.disabled === t;
      };
    }
    function ve(s) {
      return ue(function (r) {
        return (
          (r = +r),
          ue(function (e, t) {
            for (var n, i = s([], e.length, r), o = i.length; o--; )
              e[(n = i[o])] && (e[n] = !(t[n] = e[n]));
          })
        );
      });
    }
    function me(e) {
      return e && void 0 !== e.getElementsByTagName && e;
    }
    for (e in ((h = ae.support = {}),
    (s = ae.isXML = function (e) {
      var t = e.namespaceURI,
        n = (e.ownerDocument || e).documentElement;
      return !Q.test(t || (n && n.nodeName) || "HTML");
    }),
    (C = ae.setDocument = function (e) {
      var t,
        n,
        i = e ? e.ownerDocument || e : k;
      return (
        i !== x &&
          9 === i.nodeType &&
          i.documentElement &&
          ((a = (x = i).documentElement),
          (S = !s(x)),
          k !== x &&
            (n = x.defaultView) &&
            n.top !== n &&
            (n.addEventListener
              ? n.addEventListener("unload", o, !1)
              : n.attachEvent && n.attachEvent("onunload", o)),
          (h.attributes = ce(function (e) {
            return (e.className = "i"), !e.getAttribute("className");
          })),
          (h.getElementsByTagName = ce(function (e) {
            return (
              e.appendChild(x.createComment("")),
              !e.getElementsByTagName("*").length
            );
          })),
          (h.getElementsByClassName = ee.test(x.getElementsByClassName)),
          (h.getById = ce(function (e) {
            return (
              (a.appendChild(e).id = T),
              !x.getElementsByName || !x.getElementsByName(T).length
            );
          })),
          h.getById
            ? ((b.filter.ID = function (e) {
                var t = e.replace(ie, d);
                return function (e) {
                  return e.getAttribute("id") === t;
                };
              }),
              (b.find.ID = function (e, t) {
                if (void 0 !== t.getElementById && S) {
                  var n = t.getElementById(e);
                  return n ? [n] : [];
                }
              }))
            : ((b.filter.ID = function (e) {
                var n = e.replace(ie, d);
                return function (e) {
                  var t =
                    void 0 !== e.getAttributeNode && e.getAttributeNode("id");
                  return t && t.value === n;
                };
              }),
              (b.find.ID = function (e, t) {
                if (void 0 !== t.getElementById && S) {
                  var n,
                    i,
                    o,
                    r = t.getElementById(e);
                  if (r) {
                    if ((n = r.getAttributeNode("id")) && n.value === e)
                      return [r];
                    for (o = t.getElementsByName(e), i = 0; (r = o[i++]); )
                      if ((n = r.getAttributeNode("id")) && n.value === e)
                        return [r];
                  }
                  return [];
                }
              })),
          (b.find.TAG = h.getElementsByTagName
            ? function (e, t) {
                return void 0 !== t.getElementsByTagName
                  ? t.getElementsByTagName(e)
                  : h.qsa
                  ? t.querySelectorAll(e)
                  : void 0;
              }
            : function (e, t) {
                var n,
                  i = [],
                  o = 0,
                  r = t.getElementsByTagName(e);
                if ("*" !== e) return r;
                for (; (n = r[o++]); ) 1 === n.nodeType && i.push(n);
                return i;
              }),
          (b.find.CLASS =
            h.getElementsByClassName &&
            function (e, t) {
              if (void 0 !== t.getElementsByClassName && S)
                return t.getElementsByClassName(e);
            }),
          (c = []),
          (v = []),
          (h.qsa = ee.test(x.querySelectorAll)) &&
            (ce(function (e) {
              (a.appendChild(e).innerHTML =
                "<a id='" +
                T +
                "'></a><select id='" +
                T +
                "-\r\\' msallowcapture=''><option selected=''></option></select>"),
                e.querySelectorAll("[msallowcapture^='']").length &&
                  v.push("[*^$]=" + N + "*(?:''|\"\")"),
                e.querySelectorAll("[selected]").length ||
                  v.push("\\[" + N + "*(?:value|" + I + ")"),
                e.querySelectorAll("[id~=" + T + "-]").length || v.push("~="),
                e.querySelectorAll(":checked").length || v.push(":checked"),
                e.querySelectorAll("a#" + T + "+*").length ||
                  v.push(".#.+[+~]");
            }),
            ce(function (e) {
              e.innerHTML =
                "<a href='' disabled='disabled'></a><select disabled='disabled'><option/></select>";
              var t = x.createElement("input");
              t.setAttribute("type", "hidden"),
                e.appendChild(t).setAttribute("name", "D"),
                e.querySelectorAll("[name=d]").length &&
                  v.push("name" + N + "*[*^$|!~]?="),
                2 !== e.querySelectorAll(":enabled").length &&
                  v.push(":enabled", ":disabled"),
                (a.appendChild(e).disabled = !0),
                2 !== e.querySelectorAll(":disabled").length &&
                  v.push(":enabled", ":disabled"),
                e.querySelectorAll("*,:x"),
                v.push(",.*:");
            })),
          (h.matchesSelector = ee.test(
            (m =
              a.matches ||
              a.webkitMatchesSelector ||
              a.mozMatchesSelector ||
              a.oMatchesSelector ||
              a.msMatchesSelector)
          )) &&
            ce(function (e) {
              (h.disconnectedMatch = m.call(e, "*")),
                m.call(e, "[s!='']:x"),
                c.push("!=", R);
            }),
          (v = v.length && new RegExp(v.join("|"))),
          (c = c.length && new RegExp(c.join("|"))),
          (t = ee.test(a.compareDocumentPosition)),
          (y =
            t || ee.test(a.contains)
              ? function (e, t) {
                  var n = 9 === e.nodeType ? e.documentElement : e,
                    i = t && t.parentNode;
                  return (
                    e === i ||
                    !(
                      !i ||
                      1 !== i.nodeType ||
                      !(n.contains
                        ? n.contains(i)
                        : e.compareDocumentPosition &&
                          16 & e.compareDocumentPosition(i))
                    )
                  );
                }
              : function (e, t) {
                  if (t) for (; (t = t.parentNode); ) if (t === e) return !0;
                  return !1;
                }),
          (F = t
            ? function (e, t) {
                if (e === t) return (u = !0), 0;
                var n = !e.compareDocumentPosition - !t.compareDocumentPosition;
                return (
                  n ||
                  (1 &
                    (n =
                      (e.ownerDocument || e) === (t.ownerDocument || t)
                        ? e.compareDocumentPosition(t)
                        : 1) ||
                  (!h.sortDetached && t.compareDocumentPosition(e) === n)
                    ? e === x || (e.ownerDocument === k && y(k, e))
                      ? -1
                      : t === x || (t.ownerDocument === k && y(k, t))
                      ? 1
                      : l
                      ? L(l, e) - L(l, t)
                      : 0
                    : 4 & n
                    ? -1
                    : 1)
                );
              }
            : function (e, t) {
                if (e === t) return (u = !0), 0;
                var n,
                  i = 0,
                  o = e.parentNode,
                  r = t.parentNode,
                  s = [e],
                  a = [t];
                if (!o || !r)
                  return e === x
                    ? -1
                    : t === x
                    ? 1
                    : o
                    ? -1
                    : r
                    ? 1
                    : l
                    ? L(l, e) - L(l, t)
                    : 0;
                if (o === r) return pe(e, t);
                for (n = e; (n = n.parentNode); ) s.unshift(n);
                for (n = t; (n = n.parentNode); ) a.unshift(n);
                for (; s[i] === a[i]; ) i++;
                return i
                  ? pe(s[i], a[i])
                  : s[i] === k
                  ? -1
                  : a[i] === k
                  ? 1
                  : 0;
              })),
        x
      );
    }),
    (ae.matches = function (e, t) {
      return ae(e, null, null, t);
    }),
    (ae.matchesSelector = function (e, t) {
      if (
        ((e.ownerDocument || e) !== x && C(e),
        h.matchesSelector &&
          S &&
          !D[t + " "] &&
          (!c || !c.test(t)) &&
          (!v || !v.test(t)))
      )
        try {
          var n = m.call(e, t);
          if (
            n ||
            h.disconnectedMatch ||
            (e.document && 11 !== e.document.nodeType)
          )
            return n;
        } catch (e) {
          D(t, !0);
        }
      return 0 < ae(t, x, null, [e]).length;
    }),
    (ae.contains = function (e, t) {
      return (e.ownerDocument || e) !== x && C(e), y(e, t);
    }),
    (ae.attr = function (e, t) {
      (e.ownerDocument || e) !== x && C(e);
      var n = b.attrHandle[t.toLowerCase()],
        i = n && P.call(b.attrHandle, t.toLowerCase()) ? n(e, t, !S) : void 0;
      return void 0 !== i
        ? i
        : h.attributes || !S
        ? e.getAttribute(t)
        : (i = e.getAttributeNode(t)) && i.specified
        ? i.value
        : null;
    }),
    (ae.escape = function (e) {
      return (e + "").replace(oe, re);
    }),
    (ae.error = function (e) {
      throw new Error("Syntax error, unrecognized expression: " + e);
    }),
    (ae.uniqueSort = function (e) {
      var t,
        n = [],
        i = 0,
        o = 0;
      if (
        ((u = !h.detectDuplicates),
        (l = !h.sortStable && e.slice(0)),
        e.sort(F),
        u)
      ) {
        for (; (t = e[o++]); ) t === e[o] && (i = n.push(o));
        for (; i--; ) e.splice(n[i], 1);
      }
      return (l = null), e;
    }),
    (r = ae.getText = function (e) {
      var t,
        n = "",
        i = 0,
        o = e.nodeType;
      if (o) {
        if (1 === o || 9 === o || 11 === o) {
          if ("string" == typeof e.textContent) return e.textContent;
          for (e = e.firstChild; e; e = e.nextSibling) n += r(e);
        } else if (3 === o || 4 === o) return e.nodeValue;
      } else for (; (t = e[i++]); ) n += r(t);
      return n;
    }),
    ((b = ae.selectors = {
      cacheLength: 50,
      createPseudo: ue,
      match: K,
      attrHandle: {},
      find: {},
      relative: {
        ">": { dir: "parentNode", first: !0 },
        " ": { dir: "parentNode" },
        "+": { dir: "previousSibling", first: !0 },
        "~": { dir: "previousSibling" },
      },
      preFilter: {
        ATTR: function (e) {
          return (
            (e[1] = e[1].replace(ie, d)),
            (e[3] = (e[3] || e[4] || e[5] || "").replace(ie, d)),
            "~=" === e[2] && (e[3] = " " + e[3] + " "),
            e.slice(0, 4)
          );
        },
        CHILD: function (e) {
          return (
            (e[1] = e[1].toLowerCase()),
            "nth" === e[1].slice(0, 3)
              ? (e[3] || ae.error(e[0]),
                (e[4] = +(e[4]
                  ? e[5] + (e[6] || 1)
                  : 2 * ("even" === e[3] || "odd" === e[3]))),
                (e[5] = +(e[7] + e[8] || "odd" === e[3])))
              : e[3] && ae.error(e[0]),
            e
          );
        },
        PSEUDO: function (e) {
          var t,
            n = !e[6] && e[2];
          return K.CHILD.test(e[0])
            ? null
            : (e[3]
                ? (e[2] = e[4] || e[5] || "")
                : n &&
                  U.test(n) &&
                  (t = f(n, !0)) &&
                  (t = n.indexOf(")", n.length - t) - n.length) &&
                  ((e[0] = e[0].slice(0, t)), (e[2] = n.slice(0, t))),
              e.slice(0, 3));
        },
      },
      filter: {
        TAG: function (e) {
          var t = e.replace(ie, d).toLowerCase();
          return "*" === e
            ? function () {
                return !0;
              }
            : function (e) {
                return e.nodeName && e.nodeName.toLowerCase() === t;
              };
        },
        CLASS: function (e) {
          var t = E[e + " "];
          return (
            t ||
            ((t = new RegExp("(^|" + N + ")" + e + "(" + N + "|$)")) &&
              E(e, function (e) {
                return t.test(
                  ("string" == typeof e.className && e.className) ||
                    (void 0 !== e.getAttribute && e.getAttribute("class")) ||
                    ""
                );
              }))
          );
        },
        ATTR: function (n, i, o) {
          return function (e) {
            var t = ae.attr(e, n);
            return null == t
              ? "!=" === i
              : !i ||
                  ((t += ""),
                  "=" === i
                    ? t === o
                    : "!=" === i
                    ? t !== o
                    : "^=" === i
                    ? o && 0 === t.indexOf(o)
                    : "*=" === i
                    ? o && -1 < t.indexOf(o)
                    : "$=" === i
                    ? o && t.slice(-o.length) === o
                    : "~=" === i
                    ? -1 < (" " + t.replace(z, " ") + " ").indexOf(o)
                    : "|=" === i &&
                      (t === o || t.slice(0, o.length + 1) === o + "-"));
          };
        },
        CHILD: function (f, e, t, g, v) {
          var m = "nth" !== f.slice(0, 3),
            y = "last" !== f.slice(-4),
            k = "of-type" === e;
          return 1 === g && 0 === v
            ? function (e) {
                return !!e.parentNode;
              }
            : function (e, t, n) {
                var i,
                  o,
                  r,
                  s,
                  a,
                  l,
                  u = m != y ? "nextSibling" : "previousSibling",
                  c = e.parentNode,
                  d = k && e.nodeName.toLowerCase(),
                  p = !n && !k,
                  h = !1;
                if (c) {
                  if (m) {
                    for (; u; ) {
                      for (s = e; (s = s[u]); )
                        if (
                          k ? s.nodeName.toLowerCase() === d : 1 === s.nodeType
                        )
                          return !1;
                      l = u = "only" === f && !l && "nextSibling";
                    }
                    return !0;
                  }
                  if (((l = [y ? c.firstChild : c.lastChild]), y && p)) {
                    for (
                      h =
                        (a =
                          (i =
                            (o =
                              (r = (s = c)[T] || (s[T] = {}))[s.uniqueID] ||
                              (r[s.uniqueID] = {}))[f] || [])[0] === A &&
                          i[1]) && i[2],
                        s = a && c.childNodes[a];
                      (s = (++a && s && s[u]) || (h = a = 0) || l.pop());

                    )
                      if (1 === s.nodeType && ++h && s === e) {
                        o[f] = [A, a, h];
                        break;
                      }
                  } else if (
                    (p &&
                      (h = a =
                        (i =
                          (o =
                            (r = (s = e)[T] || (s[T] = {}))[s.uniqueID] ||
                            (r[s.uniqueID] = {}))[f] || [])[0] === A && i[1]),
                    !1 === h)
                  )
                    for (
                      ;
                      (s = (++a && s && s[u]) || (h = a = 0) || l.pop()) &&
                      ((k
                        ? s.nodeName.toLowerCase() !== d
                        : 1 !== s.nodeType) ||
                        !++h ||
                        (p &&
                          ((o =
                            (r = s[T] || (s[T] = {}))[s.uniqueID] ||
                            (r[s.uniqueID] = {}))[f] = [A, h]),
                        s !== e));

                    );
                  return (h -= v) === g || (h % g == 0 && 0 <= h / g);
                }
              };
        },
        PSEUDO: function (e, r) {
          var t,
            s =
              b.pseudos[e] ||
              b.setFilters[e.toLowerCase()] ||
              ae.error("unsupported pseudo: " + e);
          return s[T]
            ? s(r)
            : 1 < s.length
            ? ((t = [e, e, "", r]),
              b.setFilters.hasOwnProperty(e.toLowerCase())
                ? ue(function (e, t) {
                    for (var n, i = s(e, r), o = i.length; o--; )
                      e[(n = L(e, i[o]))] = !(t[n] = i[o]);
                  })
                : function (e) {
                    return s(e, 0, t);
                  })
            : s;
        },
      },
      pseudos: {
        not: ue(function (e) {
          var i = [],
            o = [],
            a = p(e.replace(V, "$1"));
          return a[T]
            ? ue(function (e, t, n, i) {
                for (var o, r = a(e, null, i, []), s = e.length; s--; )
                  (o = r[s]) && (e[s] = !(t[s] = o));
              })
            : function (e, t, n) {
                return (i[0] = e), a(i, null, n, o), (i[0] = null), !o.pop();
              };
        }),
        has: ue(function (t) {
          return function (e) {
            return 0 < ae(t, e).length;
          };
        }),
        contains: ue(function (t) {
          return (
            (t = t.replace(ie, d)),
            function (e) {
              return -1 < (e.textContent || r(e)).indexOf(t);
            }
          );
        }),
        lang: ue(function (n) {
          return (
            G.test(n || "") || ae.error("unsupported lang: " + n),
            (n = n.replace(ie, d).toLowerCase()),
            function (e) {
              var t;
              do {
                if (
                  (t = S
                    ? e.lang
                    : e.getAttribute("xml:lang") || e.getAttribute("lang"))
                )
                  return (
                    (t = t.toLowerCase()) === n || 0 === t.indexOf(n + "-")
                  );
              } while ((e = e.parentNode) && 1 === e.nodeType);
              return !1;
            }
          );
        }),
        target: function (e) {
          var t = n.location && n.location.hash;
          return t && t.slice(1) === e.id;
        },
        root: function (e) {
          return e === a;
        },
        focus: function (e) {
          return (
            e === x.activeElement &&
            (!x.hasFocus || x.hasFocus()) &&
            !!(e.type || e.href || ~e.tabIndex)
          );
        },
        enabled: ge(!1),
        disabled: ge(!0),
        checked: function (e) {
          var t = e.nodeName.toLowerCase();
          return (
            ("input" === t && !!e.checked) || ("option" === t && !!e.selected)
          );
        },
        selected: function (e) {
          return e.parentNode && e.parentNode.selectedIndex, !0 === e.selected;
        },
        empty: function (e) {
          for (e = e.firstChild; e; e = e.nextSibling)
            if (e.nodeType < 6) return !1;
          return !0;
        },
        parent: function (e) {
          return !b.pseudos.empty(e);
        },
        header: function (e) {
          return J.test(e.nodeName);
        },
        input: function (e) {
          return Z.test(e.nodeName);
        },
        button: function (e) {
          var t = e.nodeName.toLowerCase();
          return ("input" === t && "button" === e.type) || "button" === t;
        },
        text: function (e) {
          var t;
          return (
            "input" === e.nodeName.toLowerCase() &&
            "text" === e.type &&
            (null == (t = e.getAttribute("type")) || "text" === t.toLowerCase())
          );
        },
        first: ve(function () {
          return [0];
        }),
        last: ve(function (e, t) {
          return [t - 1];
        }),
        eq: ve(function (e, t, n) {
          return [n < 0 ? n + t : n];
        }),
        even: ve(function (e, t) {
          for (var n = 0; n < t; n += 2) e.push(n);
          return e;
        }),
        odd: ve(function (e, t) {
          for (var n = 1; n < t; n += 2) e.push(n);
          return e;
        }),
        lt: ve(function (e, t, n) {
          for (var i = n < 0 ? n + t : t < n ? t : n; 0 <= --i; ) e.push(i);
          return e;
        }),
        gt: ve(function (e, t, n) {
          for (var i = n < 0 ? n + t : n; ++i < t; ) e.push(i);
          return e;
        }),
      },
    }).pseudos.nth = b.pseudos.eq),
    { radio: !0, checkbox: !0, file: !0, password: !0, image: !0 }))
      b.pseudos[e] = he(e);
    for (e in { submit: !0, reset: !0 }) b.pseudos[e] = fe(e);
    function ye() {}
    function ke(e) {
      for (var t = 0, n = e.length, i = ""; t < n; t++) i += e[t].value;
      return i;
    }
    function be(a, e, t) {
      var l = e.dir,
        u = e.next,
        c = u || l,
        d = t && "parentNode" === c,
        p = i++;
      return e.first
        ? function (e, t, n) {
            for (; (e = e[l]); ) if (1 === e.nodeType || d) return a(e, t, n);
            return !1;
          }
        : function (e, t, n) {
            var i,
              o,
              r,
              s = [A, p];
            if (n) {
              for (; (e = e[l]); )
                if ((1 === e.nodeType || d) && a(e, t, n)) return !0;
            } else
              for (; (e = e[l]); )
                if (1 === e.nodeType || d)
                  if (
                    ((o =
                      (r = e[T] || (e[T] = {}))[e.uniqueID] ||
                      (r[e.uniqueID] = {})),
                    u && u === e.nodeName.toLowerCase())
                  )
                    e = e[l] || e;
                  else {
                    if ((i = o[c]) && i[0] === A && i[1] === p)
                      return (s[2] = i[2]);
                    if (((o[c] = s)[2] = a(e, t, n))) return !0;
                  }
            return !1;
          };
    }
    function we(o) {
      return 1 < o.length
        ? function (e, t, n) {
            for (var i = o.length; i--; ) if (!o[i](e, t, n)) return !1;
            return !0;
          }
        : o[0];
    }
    function Ce(e, t, n, i, o) {
      for (var r, s = [], a = 0, l = e.length, u = null != t; a < l; a++)
        (r = e[a]) && ((n && !n(r, i, o)) || (s.push(r), u && t.push(a)));
      return s;
    }
    function xe(h, f, g, v, m, e) {
      return (
        v && !v[T] && (v = xe(v)),
        m && !m[T] && (m = xe(m, e)),
        ue(function (e, t, n, i) {
          var o,
            r,
            s,
            a = [],
            l = [],
            u = t.length,
            c =
              e ||
              (function (e, t, n) {
                for (var i = 0, o = t.length; i < o; i++) ae(e, t[i], n);
                return n;
              })(f || "*", n.nodeType ? [n] : n, []),
            d = !h || (!e && f) ? c : Ce(c, a, h, n, i),
            p = g ? (m || (e ? h : u || v) ? [] : t) : d;
          if ((g && g(d, p, n, i), v))
            for (o = Ce(p, l), v(o, [], n, i), r = o.length; r--; )
              (s = o[r]) && (p[l[r]] = !(d[l[r]] = s));
          if (e) {
            if (m || h) {
              if (m) {
                for (o = [], r = p.length; r--; )
                  (s = p[r]) && o.push((d[r] = s));
                m(null, (p = []), o, i);
              }
              for (r = p.length; r--; )
                (s = p[r]) &&
                  -1 < (o = m ? L(e, s) : a[r]) &&
                  (e[o] = !(t[o] = s));
            }
          } else (p = Ce(p === t ? p.splice(u, p.length) : p)), m ? m(null, t, p, i) : M.apply(t, p);
        })
      );
    }
    function Se(e) {
      for (
        var o,
          t,
          n,
          i = e.length,
          r = b.relative[e[0].type],
          s = r || b.relative[" "],
          a = r ? 1 : 0,
          l = be(
            function (e) {
              return e === o;
            },
            s,
            !0
          ),
          u = be(
            function (e) {
              return -1 < L(o, e);
            },
            s,
            !0
          ),
          c = [
            function (e, t, n) {
              var i =
                (!r && (n || t !== w)) || ((o = t).nodeType ? l : u)(e, t, n);
              return (o = null), i;
            },
          ];
        a < i;
        a++
      )
        if ((t = b.relative[e[a].type])) c = [be(we(c), t)];
        else {
          if ((t = b.filter[e[a].type].apply(null, e[a].matches))[T]) {
            for (n = ++a; n < i && !b.relative[e[n].type]; n++);
            return xe(
              1 < a && we(c),
              1 < a &&
                ke(
                  e
                    .slice(0, a - 1)
                    .concat({ value: " " === e[a - 2].type ? "*" : "" })
                ).replace(V, "$1"),
              t,
              a < n && Se(e.slice(a, n)),
              n < i && Se((e = e.slice(n))),
              n < i && ke(e)
            );
          }
          c.push(t);
        }
      return we(c);
    }
    return (
      (ye.prototype = b.filters = b.pseudos),
      (b.setFilters = new ye()),
      (f = ae.tokenize = function (e, t) {
        var n,
          i,
          o,
          r,
          s,
          a,
          l,
          u = $[e + " "];
        if (u) return t ? 0 : u.slice(0);
        for (s = e, a = [], l = b.preFilter; s; ) {
          for (r in ((n && !(i = W.exec(s))) ||
            (i && (s = s.slice(i[0].length) || s), a.push((o = []))),
          (n = !1),
          (i = X.exec(s)) &&
            ((n = i.shift()),
            o.push({ value: n, type: i[0].replace(V, " ") }),
            (s = s.slice(n.length))),
          b.filter))
            !(i = K[r].exec(s)) ||
              (l[r] && !(i = l[r](i))) ||
              ((n = i.shift()),
              o.push({ value: n, type: r, matches: i }),
              (s = s.slice(n.length)));
          if (!n) break;
        }
        return t ? s.length : s ? ae.error(e) : $(e, a).slice(0);
      }),
      (p = ae.compile = function (e, t) {
        var n,
          v,
          m,
          y,
          k,
          i,
          o = [],
          r = [],
          s = _[e + " "];
        if (!s) {
          for (n = (t = t || f(e)).length; n--; )
            (s = Se(t[n]))[T] ? o.push(s) : r.push(s);
          (s = _(
            e,
            ((v = r),
            (y = 0 < (m = o).length),
            (k = 0 < v.length),
            (i = function (e, t, n, i, o) {
              var r,
                s,
                a,
                l = 0,
                u = "0",
                c = e && [],
                d = [],
                p = w,
                h = e || (k && b.find.TAG("*", o)),
                f = (A += null == p ? 1 : Math.random() || 0.1),
                g = h.length;
              for (
                o && (w = t === x || t || o);
                u !== g && null != (r = h[u]);
                u++
              ) {
                if (k && r) {
                  for (
                    s = 0, t || r.ownerDocument === x || (C(r), (n = !S));
                    (a = v[s++]);

                  )
                    if (a(r, t || x, n)) {
                      i.push(r);
                      break;
                    }
                  o && (A = f);
                }
                y && ((r = !a && r) && l--, e && c.push(r));
              }
              if (((l += u), y && u !== l)) {
                for (s = 0; (a = m[s++]); ) a(c, d, t, n);
                if (e) {
                  if (0 < l) for (; u--; ) c[u] || d[u] || (d[u] = j.call(i));
                  d = Ce(d);
                }
                M.apply(i, d),
                  o &&
                    !e &&
                    0 < d.length &&
                    1 < l + m.length &&
                    ae.uniqueSort(i);
              }
              return o && ((A = f), (w = p)), c;
            }),
            y ? ue(i) : i)
          )).selector = e;
        }
        return s;
      }),
      (g = ae.select = function (e, t, n, i) {
        var o,
          r,
          s,
          a,
          l,
          u = "function" == typeof e && e,
          c = !i && f((e = u.selector || e));
        if (((n = n || []), 1 === c.length)) {
          if (
            2 < (r = c[0] = c[0].slice(0)).length &&
            "ID" === (s = r[0]).type &&
            9 === t.nodeType &&
            S &&
            b.relative[r[1].type]
          ) {
            if (!(t = (b.find.ID(s.matches[0].replace(ie, d), t) || [])[0]))
              return n;
            u && (t = t.parentNode), (e = e.slice(r.shift().value.length));
          }
          for (
            o = K.needsContext.test(e) ? 0 : r.length;
            o-- && ((s = r[o]), !b.relative[(a = s.type)]);

          )
            if (
              (l = b.find[a]) &&
              (i = l(
                s.matches[0].replace(ie, d),
                (ne.test(r[0].type) && me(t.parentNode)) || t
              ))
            ) {
              if ((r.splice(o, 1), !(e = i.length && ke(r))))
                return M.apply(n, i), n;
              break;
            }
        }
        return (
          (u || p(e, c))(
            i,
            t,
            !S,
            n,
            !t || (ne.test(e) && me(t.parentNode)) || t
          ),
          n
        );
      }),
      (h.sortStable = T.split("").sort(F).join("") === T),
      (h.detectDuplicates = !!u),
      C(),
      (h.sortDetached = ce(function (e) {
        return 1 & e.compareDocumentPosition(x.createElement("fieldset"));
      })),
      ce(function (e) {
        return (
          (e.innerHTML = "<a href='#'></a>"),
          "#" === e.firstChild.getAttribute("href")
        );
      }) ||
        de("type|href|height|width", function (e, t, n) {
          if (!n) return e.getAttribute(t, "type" === t.toLowerCase() ? 1 : 2);
        }),
      (h.attributes &&
        ce(function (e) {
          return (
            (e.innerHTML = "<input/>"),
            e.firstChild.setAttribute("value", ""),
            "" === e.firstChild.getAttribute("value")
          );
        })) ||
        de("value", function (e, t, n) {
          if (!n && "input" === e.nodeName.toLowerCase()) return e.defaultValue;
        }),
      ce(function (e) {
        return null == e.getAttribute("disabled");
      }) ||
        de(I, function (e, t, n) {
          var i;
          if (!n)
            return !0 === e[t]
              ? t.toLowerCase()
              : (i = e.getAttributeNode(t)) && i.specified
              ? i.value
              : null;
        }),
      ae
    );
  })(x);
  (T.find = f),
    (T.expr = f.selectors),
    (T.expr[":"] = T.expr.pseudos),
    (T.uniqueSort = T.unique = f.uniqueSort),
    (T.text = f.getText),
    (T.isXMLDoc = f.isXML),
    (T.contains = f.contains),
    (T.escapeSelector = f.escape);
  function C(e, t, n) {
    for (var i = [], o = void 0 !== n; (e = e[t]) && 9 !== e.nodeType; )
      if (1 === e.nodeType) {
        if (o && T(e).is(n)) break;
        i.push(e);
      }
    return i;
  }
  function A(e, t) {
    for (var n = []; e; e = e.nextSibling)
      1 === e.nodeType && e !== t && n.push(e);
    return n;
  }
  var E = T.expr.match.needsContext;
  function $(e, t) {
    return e.nodeName && e.nodeName.toLowerCase() === t.toLowerCase();
  }
  var _ = /^<([a-z][^\/\0>:\x20\t\r\n\f]*)[\x20\t\r\n\f]*\/?>(?:<\/\1>|)$/i;
  function D(e, n, i) {
    return k(n)
      ? T.grep(e, function (e, t) {
          return !!n.call(e, t, e) !== i;
        })
      : n.nodeType
      ? T.grep(e, function (e) {
          return (e === n) !== i;
        })
      : "string" != typeof n
      ? T.grep(e, function (e) {
          return -1 < o.call(n, e) !== i;
        })
      : T.filter(n, e, i);
  }
  (T.filter = function (e, t, n) {
    var i = t[0];
    return (
      n && (e = ":not(" + e + ")"),
      1 === t.length && 1 === i.nodeType
        ? T.find.matchesSelector(i, e)
          ? [i]
          : []
        : T.find.matches(
            e,
            T.grep(t, function (e) {
              return 1 === e.nodeType;
            })
          )
    );
  }),
    T.fn.extend({
      find: function (e) {
        var t,
          n,
          i = this.length,
          o = this;
        if ("string" != typeof e)
          return this.pushStack(
            T(e).filter(function () {
              for (t = 0; t < i; t++) if (T.contains(o[t], this)) return !0;
            })
          );
        for (n = this.pushStack([]), t = 0; t < i; t++) T.find(e, o[t], n);
        return 1 < i ? T.uniqueSort(n) : n;
      },
      filter: function (e) {
        return this.pushStack(D(this, e || [], !1));
      },
      not: function (e) {
        return this.pushStack(D(this, e || [], !0));
      },
      is: function (e) {
        return !!D(this, "string" == typeof e && E.test(e) ? T(e) : e || [], !1)
          .length;
      },
    });
  var F,
    P = /^(?:\s*(<[\w\W]+>)[^>]*|#([\w-]+))$/;
  ((T.fn.init = function (e, t, n) {
    var i, o;
    if (!e) return this;
    if (((n = n || F), "string" != typeof e))
      return e.nodeType
        ? ((this[0] = e), (this.length = 1), this)
        : k(e)
        ? void 0 !== n.ready
          ? n.ready(e)
          : e(T)
        : T.makeArray(e, this);
    if (
      !(i =
        "<" === e[0] && ">" === e[e.length - 1] && 3 <= e.length
          ? [null, e, null]
          : P.exec(e)) ||
      (!i[1] && t)
    )
      return !t || t.jquery ? (t || n).find(e) : this.constructor(t).find(e);
    if (i[1]) {
      if (
        ((t = t instanceof T ? t[0] : t),
        T.merge(
          this,
          T.parseHTML(i[1], t && t.nodeType ? t.ownerDocument || t : S, !0)
        ),
        _.test(i[1]) && T.isPlainObject(t))
      )
        for (i in t) k(this[i]) ? this[i](t[i]) : this.attr(i, t[i]);
      return this;
    }
    return (
      (o = S.getElementById(i[2])) && ((this[0] = o), (this.length = 1)), this
    );
  }).prototype = T.fn),
    (F = T(S));
  var j = /^(?:parents|prev(?:Until|All))/,
    O = { children: !0, contents: !0, next: !0, prev: !0 };
  function M(e, t) {
    for (; (e = e[t]) && 1 !== e.nodeType; );
    return e;
  }
  T.fn.extend({
    has: function (e) {
      var t = T(e, this),
        n = t.length;
      return this.filter(function () {
        for (var e = 0; e < n; e++) if (T.contains(this, t[e])) return !0;
      });
    },
    closest: function (e, t) {
      var n,
        i = 0,
        o = this.length,
        r = [],
        s = "string" != typeof e && T(e);
      if (!E.test(e))
        for (; i < o; i++)
          for (n = this[i]; n && n !== t; n = n.parentNode)
            if (
              n.nodeType < 11 &&
              (s
                ? -1 < s.index(n)
                : 1 === n.nodeType && T.find.matchesSelector(n, e))
            ) {
              r.push(n);
              break;
            }
      return this.pushStack(1 < r.length ? T.uniqueSort(r) : r);
    },
    index: function (e) {
      return e
        ? "string" == typeof e
          ? o.call(T(e), this[0])
          : o.call(this, e.jquery ? e[0] : e)
        : this[0] && this[0].parentNode
        ? this.first().prevAll().length
        : -1;
    },
    add: function (e, t) {
      return this.pushStack(T.uniqueSort(T.merge(this.get(), T(e, t))));
    },
    addBack: function (e) {
      return this.add(null == e ? this.prevObject : this.prevObject.filter(e));
    },
  }),
    T.each(
      {
        parent: function (e) {
          var t = e.parentNode;
          return t && 11 !== t.nodeType ? t : null;
        },
        parents: function (e) {
          return C(e, "parentNode");
        },
        parentsUntil: function (e, t, n) {
          return C(e, "parentNode", n);
        },
        next: function (e) {
          return M(e, "nextSibling");
        },
        prev: function (e) {
          return M(e, "previousSibling");
        },
        nextAll: function (e) {
          return C(e, "nextSibling");
        },
        prevAll: function (e) {
          return C(e, "previousSibling");
        },
        nextUntil: function (e, t, n) {
          return C(e, "nextSibling", n);
        },
        prevUntil: function (e, t, n) {
          return C(e, "previousSibling", n);
        },
        siblings: function (e) {
          return A((e.parentNode || {}).firstChild, e);
        },
        children: function (e) {
          return A(e.firstChild);
        },
        contents: function (e) {
          return void 0 !== e.contentDocument
            ? e.contentDocument
            : ($(e, "template") && (e = e.content || e),
              T.merge([], e.childNodes));
        },
      },
      function (i, o) {
        T.fn[i] = function (e, t) {
          var n = T.map(this, o, e);
          return (
            "Until" !== i.slice(-5) && (t = e),
            t && "string" == typeof t && (n = T.filter(t, n)),
            1 < this.length &&
              (O[i] || T.uniqueSort(n), j.test(i) && n.reverse()),
            this.pushStack(n)
          );
        };
      }
    );
  var B = /[^\x20\t\r\n\f]+/g;
  function L(e) {
    return e;
  }
  function I(e) {
    throw e;
  }
  function N(e, t, n, i) {
    var o;
    try {
      e && k((o = e.promise))
        ? o.call(e).done(t).fail(n)
        : e && k((o = e.then))
        ? o.call(e, t, n)
        : t.apply(void 0, [e].slice(i));
    } catch (e) {
      n.apply(void 0, [e]);
    }
  }
  (T.Callbacks = function (i) {
    var n;
    i =
      "string" == typeof i
        ? ((n = {}),
          T.each(i.match(B) || [], function (e, t) {
            n[t] = !0;
          }),
          n)
        : T.extend({}, i);
    function o() {
      for (s = s || i.once, t = r = !0; l.length; u = -1)
        for (e = l.shift(); ++u < a.length; )
          !1 === a[u].apply(e[0], e[1]) &&
            i.stopOnFalse &&
            ((u = a.length), (e = !1));
      i.memory || (e = !1), (r = !1), s && (a = e ? [] : "");
    }
    var r,
      e,
      t,
      s,
      a = [],
      l = [],
      u = -1,
      c = {
        add: function () {
          return (
            a &&
              (e && !r && ((u = a.length - 1), l.push(e)),
              (function n(e) {
                T.each(e, function (e, t) {
                  k(t)
                    ? (i.unique && c.has(t)) || a.push(t)
                    : t && t.length && "string" !== w(t) && n(t);
                });
              })(arguments),
              e && !r && o()),
            this
          );
        },
        remove: function () {
          return (
            T.each(arguments, function (e, t) {
              for (var n; -1 < (n = T.inArray(t, a, n)); )
                a.splice(n, 1), n <= u && u--;
            }),
            this
          );
        },
        has: function (e) {
          return e ? -1 < T.inArray(e, a) : 0 < a.length;
        },
        empty: function () {
          return (a = a && []), this;
        },
        disable: function () {
          return (s = l = []), (a = e = ""), this;
        },
        disabled: function () {
          return !a;
        },
        lock: function () {
          return (s = l = []), e || r || (a = e = ""), this;
        },
        locked: function () {
          return !!s;
        },
        fireWith: function (e, t) {
          return (
            s ||
              ((t = [e, (t = t || []).slice ? t.slice() : t]),
              l.push(t),
              r || o()),
            this
          );
        },
        fire: function () {
          return c.fireWith(this, arguments), this;
        },
        fired: function () {
          return !!t;
        },
      };
    return c;
  }),
    T.extend({
      Deferred: function (e) {
        var r = [
            [
              "notify",
              "progress",
              T.Callbacks("memory"),
              T.Callbacks("memory"),
              2,
            ],
            [
              "resolve",
              "done",
              T.Callbacks("once memory"),
              T.Callbacks("once memory"),
              0,
              "resolved",
            ],
            [
              "reject",
              "fail",
              T.Callbacks("once memory"),
              T.Callbacks("once memory"),
              1,
              "rejected",
            ],
          ],
          o = "pending",
          s = {
            state: function () {
              return o;
            },
            always: function () {
              return a.done(arguments).fail(arguments), this;
            },
            catch: function (e) {
              return s.then(null, e);
            },
            pipe: function () {
              var o = arguments;
              return T.Deferred(function (i) {
                T.each(r, function (e, t) {
                  var n = k(o[t[4]]) && o[t[4]];
                  a[t[1]](function () {
                    var e = n && n.apply(this, arguments);
                    e && k(e.promise)
                      ? e
                          .promise()
                          .progress(i.notify)
                          .done(i.resolve)
                          .fail(i.reject)
                      : i[t[0] + "With"](this, n ? [e] : arguments);
                  });
                }),
                  (o = null);
              }).promise();
            },
            then: function (t, n, i) {
              var l = 0;
              function u(o, r, s, a) {
                return function () {
                  function e() {
                    var e, t;
                    if (!(o < l)) {
                      if ((e = s.apply(n, i)) === r.promise())
                        throw new TypeError("Thenable self-resolution");
                      (t =
                        e &&
                        ("object" == typeof e || "function" == typeof e) &&
                        e.then),
                        k(t)
                          ? a
                            ? t.call(e, u(l, r, L, a), u(l, r, I, a))
                            : (l++,
                              t.call(
                                e,
                                u(l, r, L, a),
                                u(l, r, I, a),
                                u(l, r, L, r.notifyWith)
                              ))
                          : (s !== L && ((n = void 0), (i = [e])),
                            (a || r.resolveWith)(n, i));
                    }
                  }
                  var n = this,
                    i = arguments,
                    t = a
                      ? e
                      : function () {
                          try {
                            e();
                          } catch (e) {
                            T.Deferred.exceptionHook &&
                              T.Deferred.exceptionHook(e, t.stackTrace),
                              l <= o + 1 &&
                                (s !== I && ((n = void 0), (i = [e])),
                                r.rejectWith(n, i));
                          }
                        };
                  o
                    ? t()
                    : (T.Deferred.getStackHook &&
                        (t.stackTrace = T.Deferred.getStackHook()),
                      x.setTimeout(t));
                };
              }
              return T.Deferred(function (e) {
                r[0][3].add(u(0, e, k(i) ? i : L, e.notifyWith)),
                  r[1][3].add(u(0, e, k(t) ? t : L)),
                  r[2][3].add(u(0, e, k(n) ? n : I));
              }).promise();
            },
            promise: function (e) {
              return null != e ? T.extend(e, s) : s;
            },
          },
          a = {};
        return (
          T.each(r, function (e, t) {
            var n = t[2],
              i = t[5];
            (s[t[1]] = n.add),
              i &&
                n.add(
                  function () {
                    o = i;
                  },
                  r[3 - e][2].disable,
                  r[3 - e][3].disable,
                  r[0][2].lock,
                  r[0][3].lock
                ),
              n.add(t[3].fire),
              (a[t[0]] = function () {
                return (
                  a[t[0] + "With"](this === a ? void 0 : this, arguments), this
                );
              }),
              (a[t[0] + "With"] = n.fireWith);
          }),
          s.promise(a),
          e && e.call(a, a),
          a
        );
      },
      when: function (e) {
        function t(t) {
          return function (e) {
            (o[t] = this),
              (r[t] = 1 < arguments.length ? a.call(arguments) : e),
              --n || s.resolveWith(o, r);
          };
        }
        var n = arguments.length,
          i = n,
          o = Array(i),
          r = a.call(arguments),
          s = T.Deferred();
        if (
          n <= 1 &&
          (N(e, s.done(t(i)).resolve, s.reject, !n),
          "pending" === s.state() || k(r[i] && r[i].then))
        )
          return s.then();
        for (; i--; ) N(r[i], t(i), s.reject);
        return s.promise();
      },
    });
  var H = /^(Eval|Internal|Range|Reference|Syntax|Type|URI)Error$/;
  (T.Deferred.exceptionHook = function (e, t) {
    x.console &&
      x.console.warn &&
      e &&
      H.test(e.name) &&
      x.console.warn("jQuery.Deferred exception: " + e.message, e.stack, t);
  }),
    (T.readyException = function (e) {
      x.setTimeout(function () {
        throw e;
      });
    });
  var q = T.Deferred();
  function R() {
    S.removeEventListener("DOMContentLoaded", R),
      x.removeEventListener("load", R),
      T.ready();
  }
  (T.fn.ready = function (e) {
    return (
      q.then(e).catch(function (e) {
        T.readyException(e);
      }),
      this
    );
  }),
    T.extend({
      isReady: !1,
      readyWait: 1,
      ready: function (e) {
        (!0 === e ? --T.readyWait : T.isReady) ||
          ((T.isReady = !0) !== e && 0 < --T.readyWait) ||
          q.resolveWith(S, [T]);
      },
    }),
    (T.ready.then = q.then),
    "complete" === S.readyState ||
    ("loading" !== S.readyState && !S.documentElement.doScroll)
      ? x.setTimeout(T.ready)
      : (S.addEventListener("DOMContentLoaded", R),
        x.addEventListener("load", R));
  var z = function (e, t, n, i, o, r, s) {
      var a = 0,
        l = e.length,
        u = null == n;
      if ("object" === w(n))
        for (a in ((o = !0), n)) z(e, t, a, n[a], !0, r, s);
      else if (
        void 0 !== i &&
        ((o = !0),
        k(i) || (s = !0),
        u &&
          (t = s
            ? (t.call(e, i), null)
            : ((u = t),
              function (e, t, n) {
                return u.call(T(e), n);
              })),
        t)
      )
        for (; a < l; a++) t(e[a], n, s ? i : i.call(e[a], a, t(e[a], n)));
      return o ? e : u ? t.call(e) : l ? t(e[0], n) : r;
    },
    V = /^-ms-/,
    W = /-([a-z])/g;
  function X(e, t) {
    return t.toUpperCase();
  }
  function Y(e) {
    return e.replace(V, "ms-").replace(W, X);
  }
  function U(e) {
    return 1 === e.nodeType || 9 === e.nodeType || !+e.nodeType;
  }
  function G() {
    this.expando = T.expando + G.uid++;
  }
  (G.uid = 1),
    (G.prototype = {
      cache: function (e) {
        var t = e[this.expando];
        return (
          t ||
            ((t = {}),
            U(e) &&
              (e.nodeType
                ? (e[this.expando] = t)
                : Object.defineProperty(e, this.expando, {
                    value: t,
                    configurable: !0,
                  }))),
          t
        );
      },
      set: function (e, t, n) {
        var i,
          o = this.cache(e);
        if ("string" == typeof t) o[Y(t)] = n;
        else for (i in t) o[Y(i)] = t[i];
        return o;
      },
      get: function (e, t) {
        return void 0 === t
          ? this.cache(e)
          : e[this.expando] && e[this.expando][Y(t)];
      },
      access: function (e, t, n) {
        return void 0 === t || (t && "string" == typeof t && void 0 === n)
          ? this.get(e, t)
          : (this.set(e, t, n), void 0 !== n ? n : t);
      },
      remove: function (e, t) {
        var n,
          i = e[this.expando];
        if (void 0 !== i) {
          if (void 0 !== t) {
            n = (t = Array.isArray(t)
              ? t.map(Y)
              : (t = Y(t)) in i
              ? [t]
              : t.match(B) || []).length;
            for (; n--; ) delete i[t[n]];
          }
          (void 0 !== t && !T.isEmptyObject(i)) ||
            (e.nodeType ? (e[this.expando] = void 0) : delete e[this.expando]);
        }
      },
      hasData: function (e) {
        var t = e[this.expando];
        return void 0 !== t && !T.isEmptyObject(t);
      },
    });
  var K = new G(),
    Q = new G(),
    Z = /^(?:\{[\w\W]*\}|\[[\w\W]*\])$/,
    J = /[A-Z]/g;
  function ee(e, t, n) {
    var i, o;
    if (void 0 === n && 1 === e.nodeType)
      if (
        ((i = "data-" + t.replace(J, "-$&").toLowerCase()),
        "string" == typeof (n = e.getAttribute(i)))
      ) {
        try {
          n =
            "true" === (o = n) ||
            ("false" !== o &&
              ("null" === o
                ? null
                : o === +o + ""
                ? +o
                : Z.test(o)
                ? JSON.parse(o)
                : o));
        } catch (e) {}
        Q.set(e, t, n);
      } else n = void 0;
    return n;
  }
  T.extend({
    hasData: function (e) {
      return Q.hasData(e) || K.hasData(e);
    },
    data: function (e, t, n) {
      return Q.access(e, t, n);
    },
    removeData: function (e, t) {
      Q.remove(e, t);
    },
    _data: function (e, t, n) {
      return K.access(e, t, n);
    },
    _removeData: function (e, t) {
      K.remove(e, t);
    },
  }),
    T.fn.extend({
      data: function (n, e) {
        var t,
          i,
          o,
          r = this[0],
          s = r && r.attributes;
        if (void 0 !== n)
          return "object" == typeof n
            ? this.each(function () {
                Q.set(this, n);
              })
            : z(
                this,
                function (e) {
                  var t;
                  if (r && void 0 === e)
                    return void 0 !== (t = Q.get(r, n)) ||
                      void 0 !== (t = ee(r, n))
                      ? t
                      : void 0;
                  this.each(function () {
                    Q.set(this, n, e);
                  });
                },
                null,
                e,
                1 < arguments.length,
                null,
                !0
              );
        if (
          this.length &&
          ((o = Q.get(r)), 1 === r.nodeType && !K.get(r, "hasDataAttrs"))
        ) {
          for (t = s.length; t--; )
            s[t] &&
              0 === (i = s[t].name).indexOf("data-") &&
              ((i = Y(i.slice(5))), ee(r, i, o[i]));
          K.set(r, "hasDataAttrs", !0);
        }
        return o;
      },
      removeData: function (e) {
        return this.each(function () {
          Q.remove(this, e);
        });
      },
    }),
    T.extend({
      queue: function (e, t, n) {
        var i;
        if (e)
          return (
            (t = (t || "fx") + "queue"),
            (i = K.get(e, t)),
            n &&
              (!i || Array.isArray(n)
                ? (i = K.access(e, t, T.makeArray(n)))
                : i.push(n)),
            i || []
          );
      },
      dequeue: function (e, t) {
        t = t || "fx";
        var n = T.queue(e, t),
          i = n.length,
          o = n.shift(),
          r = T._queueHooks(e, t);
        "inprogress" === o && ((o = n.shift()), i--),
          o &&
            ("fx" === t && n.unshift("inprogress"),
            delete r.stop,
            o.call(
              e,
              function () {
                T.dequeue(e, t);
              },
              r
            )),
          !i && r && r.empty.fire();
      },
      _queueHooks: function (e, t) {
        var n = t + "queueHooks";
        return (
          K.get(e, n) ||
          K.access(e, n, {
            empty: T.Callbacks("once memory").add(function () {
              K.remove(e, [t + "queue", n]);
            }),
          })
        );
      },
    }),
    T.fn.extend({
      queue: function (t, n) {
        var e = 2;
        return (
          "string" != typeof t && ((n = t), (t = "fx"), e--),
          arguments.length < e
            ? T.queue(this[0], t)
            : void 0 === n
            ? this
            : this.each(function () {
                var e = T.queue(this, t, n);
                T._queueHooks(this, t),
                  "fx" === t && "inprogress" !== e[0] && T.dequeue(this, t);
              })
        );
      },
      dequeue: function (e) {
        return this.each(function () {
          T.dequeue(this, e);
        });
      },
      clearQueue: function (e) {
        return this.queue(e || "fx", []);
      },
      promise: function (e, t) {
        function n() {
          --o || r.resolveWith(s, [s]);
        }
        var i,
          o = 1,
          r = T.Deferred(),
          s = this,
          a = this.length;
        for (
          "string" != typeof e && ((t = e), (e = void 0)), e = e || "fx";
          a--;

        )
          (i = K.get(s[a], e + "queueHooks")) &&
            i.empty &&
            (o++, i.empty.add(n));
        return n(), r.promise(t);
      },
    });
  var te = /[+-]?(?:\d*\.|)\d+(?:[eE][+-]?\d+|)/.source,
    ne = new RegExp("^(?:([+-])=|)(" + te + ")([a-z%]*)$", "i"),
    ie = ["Top", "Right", "Bottom", "Left"],
    oe = S.documentElement,
    re = function (e) {
      return T.contains(e.ownerDocument, e);
    },
    se = { composed: !0 };
  oe.getRootNode &&
    (re = function (e) {
      return (
        T.contains(e.ownerDocument, e) || e.getRootNode(se) === e.ownerDocument
      );
    });
  function ae(e, t) {
    return (
      "none" === (e = t || e).style.display ||
      ("" === e.style.display && re(e) && "none" === T.css(e, "display"))
    );
  }
  function le(e, t, n, i) {
    var o,
      r,
      s = {};
    for (r in t) (s[r] = e.style[r]), (e.style[r] = t[r]);
    for (r in ((o = n.apply(e, i || [])), t)) e.style[r] = s[r];
    return o;
  }
  function ue(e, t, n, i) {
    var o,
      r,
      s = 20,
      a = i
        ? function () {
            return i.cur();
          }
        : function () {
            return T.css(e, t, "");
          },
      l = a(),
      u = (n && n[3]) || (T.cssNumber[t] ? "" : "px"),
      c =
        e.nodeType &&
        (T.cssNumber[t] || ("px" !== u && +l)) &&
        ne.exec(T.css(e, t));
    if (c && c[3] !== u) {
      for (l /= 2, u = u || c[3], c = +l || 1; s--; )
        T.style(e, t, c + u),
          (1 - r) * (1 - (r = a() / l || 0.5)) <= 0 && (s = 0),
          (c /= r);
      (c *= 2), T.style(e, t, c + u), (n = n || []);
    }
    return (
      n &&
        ((c = +c || +l || 0),
        (o = n[1] ? c + (n[1] + 1) * n[2] : +n[2]),
        i && ((i.unit = u), (i.start = c), (i.end = o))),
      o
    );
  }
  var ce = {};
  function de(e, t) {
    for (var n, i, o, r, s, a, l = [], u = 0, c = e.length; u < c; u++)
      (i = e[u]).style &&
        ((n = i.style.display),
        t
          ? ("none" === n &&
              ((l[u] = K.get(i, "display") || null),
              l[u] || (i.style.display = "")),
            "" === i.style.display &&
              ae(i) &&
              (l[u] =
                ((a = r = o = void 0),
                (r = i.ownerDocument),
                (s = i.nodeName),
                (a = ce[s]) ||
                  ((o = r.body.appendChild(r.createElement(s))),
                  (a = T.css(o, "display")),
                  o.parentNode.removeChild(o),
                  "none" === a && (a = "block"),
                  (ce[s] = a)))))
          : "none" !== n && ((l[u] = "none"), K.set(i, "display", n)));
    for (u = 0; u < c; u++) null != l[u] && (e[u].style.display = l[u]);
    return e;
  }
  T.fn.extend({
    show: function () {
      return de(this, !0);
    },
    hide: function () {
      return de(this);
    },
    toggle: function (e) {
      return "boolean" == typeof e
        ? e
          ? this.show()
          : this.hide()
        : this.each(function () {
            ae(this) ? T(this).show() : T(this).hide();
          });
    },
  });
  var pe = /^(?:checkbox|radio)$/i,
    he = /<([a-z][^\/\0>\x20\t\r\n\f]*)/i,
    fe = /^$|^module$|\/(?:java|ecma)script/i,
    ge = {
      option: [1, "<select multiple='multiple'>", "</select>"],
      thead: [1, "<table>", "</table>"],
      col: [2, "<table><colgroup>", "</colgroup></table>"],
      tr: [2, "<table><tbody>", "</tbody></table>"],
      td: [3, "<table><tbody><tr>", "</tr></tbody></table>"],
      _default: [0, "", ""],
    };
  function ve(e, t) {
    var n;
    return (
      (n =
        void 0 !== e.getElementsByTagName
          ? e.getElementsByTagName(t || "*")
          : void 0 !== e.querySelectorAll
          ? e.querySelectorAll(t || "*")
          : []),
      void 0 === t || (t && $(e, t)) ? T.merge([e], n) : n
    );
  }
  function me(e, t) {
    for (var n = 0, i = e.length; n < i; n++)
      K.set(e[n], "globalEval", !t || K.get(t[n], "globalEval"));
  }
  (ge.optgroup = ge.option),
    (ge.tbody = ge.tfoot = ge.colgroup = ge.caption = ge.thead),
    (ge.th = ge.td);
  var ye,
    ke,
    be = /<|&#?\w+;/;
  function we(e, t, n, i, o) {
    for (
      var r,
        s,
        a,
        l,
        u,
        c,
        d = t.createDocumentFragment(),
        p = [],
        h = 0,
        f = e.length;
      h < f;
      h++
    )
      if ((r = e[h]) || 0 === r)
        if ("object" === w(r)) T.merge(p, r.nodeType ? [r] : r);
        else if (be.test(r)) {
          for (
            s = s || d.appendChild(t.createElement("div")),
              a = (he.exec(r) || ["", ""])[1].toLowerCase(),
              l = ge[a] || ge._default,
              s.innerHTML = l[1] + T.htmlPrefilter(r) + l[2],
              c = l[0];
            c--;

          )
            s = s.lastChild;
          T.merge(p, s.childNodes), ((s = d.firstChild).textContent = "");
        } else p.push(t.createTextNode(r));
    for (d.textContent = "", h = 0; (r = p[h++]); )
      if (i && -1 < T.inArray(r, i)) o && o.push(r);
      else if (
        ((u = re(r)), (s = ve(d.appendChild(r), "script")), u && me(s), n)
      )
        for (c = 0; (r = s[c++]); ) fe.test(r.type || "") && n.push(r);
    return d;
  }
  (ye = S.createDocumentFragment().appendChild(S.createElement("div"))),
    (ke = S.createElement("input")).setAttribute("type", "radio"),
    ke.setAttribute("checked", "checked"),
    ke.setAttribute("name", "t"),
    ye.appendChild(ke),
    (y.checkClone = ye.cloneNode(!0).cloneNode(!0).lastChild.checked),
    (ye.innerHTML = "<textarea>x</textarea>"),
    (y.noCloneChecked = !!ye.cloneNode(!0).lastChild.defaultValue);
  var Ce = /^key/,
    xe = /^(?:mouse|pointer|contextmenu|drag|drop)|click/,
    Se = /^([^.]*)(?:\.(.+)|)/;
  function Te() {
    return !0;
  }
  function Ae() {
    return !1;
  }
  function Ee(e, t) {
    return (
      (e ===
        (function () {
          try {
            return S.activeElement;
          } catch (e) {}
        })()) ==
      ("focus" === t)
    );
  }
  function $e(e, t, n, i, o, r) {
    var s, a;
    if ("object" == typeof t) {
      for (a in ("string" != typeof n && ((i = i || n), (n = void 0)), t))
        $e(e, a, n, i, t[a], r);
      return e;
    }
    if (
      (null == i && null == o
        ? ((o = n), (i = n = void 0))
        : null == o &&
          ("string" == typeof n
            ? ((o = i), (i = void 0))
            : ((o = i), (i = n), (n = void 0))),
      !1 === o)
    )
      o = Ae;
    else if (!o) return e;
    return (
      1 === r &&
        ((s = o),
        ((o = function (e) {
          return T().off(e), s.apply(this, arguments);
        }).guid = s.guid || (s.guid = T.guid++))),
      e.each(function () {
        T.event.add(this, t, o, i, n);
      })
    );
  }
  function _e(e, o, r) {
    r
      ? (K.set(e, o, !1),
        T.event.add(e, o, {
          namespace: !1,
          handler: function (e) {
            var t,
              n,
              i = K.get(this, o);
            if (1 & e.isTrigger && this[o]) {
              if (i.length)
                (T.event.special[o] || {}).delegateType && e.stopPropagation();
              else if (
                ((i = a.call(arguments)),
                K.set(this, o, i),
                (t = r(this, o)),
                this[o](),
                i !== (n = K.get(this, o)) || t ? K.set(this, o, !1) : (n = {}),
                i !== n)
              )
                return (
                  e.stopImmediatePropagation(), e.preventDefault(), n.value
                );
            } else
              i.length &&
                (K.set(this, o, {
                  value: T.event.trigger(
                    T.extend(i[0], T.Event.prototype),
                    i.slice(1),
                    this
                  ),
                }),
                e.stopImmediatePropagation());
          },
        }))
      : void 0 === K.get(e, o) && T.event.add(e, o, Te);
  }
  (T.event = {
    global: {},
    add: function (t, e, n, i, o) {
      var r,
        s,
        a,
        l,
        u,
        c,
        d,
        p,
        h,
        f,
        g,
        v = K.get(t);
      if (v)
        for (
          n.handler && ((n = (r = n).handler), (o = r.selector)),
            o && T.find.matchesSelector(oe, o),
            n.guid || (n.guid = T.guid++),
            (l = v.events) || (l = v.events = {}),
            (s = v.handle) ||
              (s = v.handle = function (e) {
                return void 0 !== T && T.event.triggered !== e.type
                  ? T.event.dispatch.apply(t, arguments)
                  : void 0;
              }),
            u = (e = (e || "").match(B) || [""]).length;
          u--;

        )
          (h = g = (a = Se.exec(e[u]) || [])[1]),
            (f = (a[2] || "").split(".").sort()),
            h &&
              ((d = T.event.special[h] || {}),
              (h = (o ? d.delegateType : d.bindType) || h),
              (d = T.event.special[h] || {}),
              (c = T.extend(
                {
                  type: h,
                  origType: g,
                  data: i,
                  handler: n,
                  guid: n.guid,
                  selector: o,
                  needsContext: o && T.expr.match.needsContext.test(o),
                  namespace: f.join("."),
                },
                r
              )),
              (p = l[h]) ||
                (((p = l[h] = []).delegateCount = 0),
                (d.setup && !1 !== d.setup.call(t, i, f, s)) ||
                  (t.addEventListener && t.addEventListener(h, s))),
              d.add &&
                (d.add.call(t, c), c.handler.guid || (c.handler.guid = n.guid)),
              o ? p.splice(p.delegateCount++, 0, c) : p.push(c),
              (T.event.global[h] = !0));
    },
    remove: function (e, t, n, i, o) {
      var r,
        s,
        a,
        l,
        u,
        c,
        d,
        p,
        h,
        f,
        g,
        v = K.hasData(e) && K.get(e);
      if (v && (l = v.events)) {
        for (u = (t = (t || "").match(B) || [""]).length; u--; )
          if (
            ((h = g = (a = Se.exec(t[u]) || [])[1]),
            (f = (a[2] || "").split(".").sort()),
            h)
          ) {
            for (
              d = T.event.special[h] || {},
                p = l[(h = (i ? d.delegateType : d.bindType) || h)] || [],
                a =
                  a[2] &&
                  new RegExp("(^|\\.)" + f.join("\\.(?:.*\\.|)") + "(\\.|$)"),
                s = r = p.length;
              r--;

            )
              (c = p[r]),
                (!o && g !== c.origType) ||
                  (n && n.guid !== c.guid) ||
                  (a && !a.test(c.namespace)) ||
                  (i && i !== c.selector && ("**" !== i || !c.selector)) ||
                  (p.splice(r, 1),
                  c.selector && p.delegateCount--,
                  d.remove && d.remove.call(e, c));
            s &&
              !p.length &&
              ((d.teardown && !1 !== d.teardown.call(e, f, v.handle)) ||
                T.removeEvent(e, h, v.handle),
              delete l[h]);
          } else for (h in l) T.event.remove(e, h + t[u], n, i, !0);
        T.isEmptyObject(l) && K.remove(e, "handle events");
      }
    },
    dispatch: function (e) {
      var t,
        n,
        i,
        o,
        r,
        s,
        a = T.event.fix(e),
        l = new Array(arguments.length),
        u = (K.get(this, "events") || {})[a.type] || [],
        c = T.event.special[a.type] || {};
      for (l[0] = a, t = 1; t < arguments.length; t++) l[t] = arguments[t];
      if (
        ((a.delegateTarget = this),
        !c.preDispatch || !1 !== c.preDispatch.call(this, a))
      ) {
        for (
          s = T.event.handlers.call(this, a, u), t = 0;
          (o = s[t++]) && !a.isPropagationStopped();

        )
          for (
            a.currentTarget = o.elem, n = 0;
            (r = o.handlers[n++]) && !a.isImmediatePropagationStopped();

          )
            (a.rnamespace &&
              !1 !== r.namespace &&
              !a.rnamespace.test(r.namespace)) ||
              ((a.handleObj = r),
              (a.data = r.data),
              void 0 !==
                (i = (
                  (T.event.special[r.origType] || {}).handle || r.handler
                ).apply(o.elem, l)) &&
                !1 === (a.result = i) &&
                (a.preventDefault(), a.stopPropagation()));
        return c.postDispatch && c.postDispatch.call(this, a), a.result;
      }
    },
    handlers: function (e, t) {
      var n,
        i,
        o,
        r,
        s,
        a = [],
        l = t.delegateCount,
        u = e.target;
      if (l && u.nodeType && !("click" === e.type && 1 <= e.button))
        for (; u !== this; u = u.parentNode || this)
          if (1 === u.nodeType && ("click" !== e.type || !0 !== u.disabled)) {
            for (r = [], s = {}, n = 0; n < l; n++)
              void 0 === s[(o = (i = t[n]).selector + " ")] &&
                (s[o] = i.needsContext
                  ? -1 < T(o, this).index(u)
                  : T.find(o, this, null, [u]).length),
                s[o] && r.push(i);
            r.length && a.push({ elem: u, handlers: r });
          }
      return (
        (u = this), l < t.length && a.push({ elem: u, handlers: t.slice(l) }), a
      );
    },
    addProp: function (t, e) {
      Object.defineProperty(T.Event.prototype, t, {
        enumerable: !0,
        configurable: !0,
        get: k(e)
          ? function () {
              if (this.originalEvent) return e(this.originalEvent);
            }
          : function () {
              if (this.originalEvent) return this.originalEvent[t];
            },
        set: function (e) {
          Object.defineProperty(this, t, {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: e,
          });
        },
      });
    },
    fix: function (e) {
      return e[T.expando] ? e : new T.Event(e);
    },
    special: {
      load: { noBubble: !0 },
      click: {
        setup: function (e) {
          var t = this || e;
          return (
            pe.test(t.type) && t.click && $(t, "input") && _e(t, "click", Te),
            !1
          );
        },
        trigger: function (e) {
          var t = this || e;
          return (
            pe.test(t.type) && t.click && $(t, "input") && _e(t, "click"), !0
          );
        },
        _default: function (e) {
          var t = e.target;
          return (
            (pe.test(t.type) &&
              t.click &&
              $(t, "input") &&
              K.get(t, "click")) ||
            $(t, "a")
          );
        },
      },
      beforeunload: {
        postDispatch: function (e) {
          void 0 !== e.result &&
            e.originalEvent &&
            (e.originalEvent.returnValue = e.result);
        },
      },
    },
  }),
    (T.removeEvent = function (e, t, n) {
      e.removeEventListener && e.removeEventListener(t, n);
    }),
    (T.Event = function (e, t) {
      if (!(this instanceof T.Event)) return new T.Event(e, t);
      e && e.type
        ? ((this.originalEvent = e),
          (this.type = e.type),
          (this.isDefaultPrevented =
            e.defaultPrevented ||
            (void 0 === e.defaultPrevented && !1 === e.returnValue)
              ? Te
              : Ae),
          (this.target =
            e.target && 3 === e.target.nodeType
              ? e.target.parentNode
              : e.target),
          (this.currentTarget = e.currentTarget),
          (this.relatedTarget = e.relatedTarget))
        : (this.type = e),
        t && T.extend(this, t),
        (this.timeStamp = (e && e.timeStamp) || Date.now()),
        (this[T.expando] = !0);
    }),
    (T.Event.prototype = {
      constructor: T.Event,
      isDefaultPrevented: Ae,
      isPropagationStopped: Ae,
      isImmediatePropagationStopped: Ae,
      isSimulated: !1,
      preventDefault: function () {
        var e = this.originalEvent;
        (this.isDefaultPrevented = Te),
          e && !this.isSimulated && e.preventDefault();
      },
      stopPropagation: function () {
        var e = this.originalEvent;
        (this.isPropagationStopped = Te),
          e && !this.isSimulated && e.stopPropagation();
      },
      stopImmediatePropagation: function () {
        var e = this.originalEvent;
        (this.isImmediatePropagationStopped = Te),
          e && !this.isSimulated && e.stopImmediatePropagation(),
          this.stopPropagation();
      },
    }),
    T.each(
      {
        altKey: !0,
        bubbles: !0,
        cancelable: !0,
        changedTouches: !0,
        ctrlKey: !0,
        detail: !0,
        eventPhase: !0,
        metaKey: !0,
        pageX: !0,
        pageY: !0,
        shiftKey: !0,
        view: !0,
        char: !0,
        code: !0,
        charCode: !0,
        key: !0,
        keyCode: !0,
        button: !0,
        buttons: !0,
        clientX: !0,
        clientY: !0,
        offsetX: !0,
        offsetY: !0,
        pointerId: !0,
        pointerType: !0,
        screenX: !0,
        screenY: !0,
        targetTouches: !0,
        toElement: !0,
        touches: !0,
        which: function (e) {
          var t = e.button;
          return null == e.which && Ce.test(e.type)
            ? null != e.charCode
              ? e.charCode
              : e.keyCode
            : !e.which && void 0 !== t && xe.test(e.type)
            ? 1 & t
              ? 1
              : 2 & t
              ? 3
              : 4 & t
              ? 2
              : 0
            : e.which;
        },
      },
      T.event.addProp
    ),
    T.each({ focus: "focusin", blur: "focusout" }, function (e, t) {
      T.event.special[e] = {
        setup: function () {
          return _e(this, e, Ee), !1;
        },
        trigger: function () {
          return _e(this, e), !0;
        },
        delegateType: t,
      };
    }),
    T.each(
      {
        mouseenter: "mouseover",
        mouseleave: "mouseout",
        pointerenter: "pointerover",
        pointerleave: "pointerout",
      },
      function (e, o) {
        T.event.special[e] = {
          delegateType: o,
          bindType: o,
          handle: function (e) {
            var t,
              n = e.relatedTarget,
              i = e.handleObj;
            return (
              (n && (n === this || T.contains(this, n))) ||
                ((e.type = i.origType),
                (t = i.handler.apply(this, arguments)),
                (e.type = o)),
              t
            );
          },
        };
      }
    ),
    T.fn.extend({
      on: function (e, t, n, i) {
        return $e(this, e, t, n, i);
      },
      one: function (e, t, n, i) {
        return $e(this, e, t, n, i, 1);
      },
      off: function (e, t, n) {
        var i, o;
        if (e && e.preventDefault && e.handleObj)
          return (
            (i = e.handleObj),
            T(e.delegateTarget).off(
              i.namespace ? i.origType + "." + i.namespace : i.origType,
              i.selector,
              i.handler
            ),
            this
          );
        if ("object" != typeof e)
          return (
            (!1 !== t && "function" != typeof t) || ((n = t), (t = void 0)),
            !1 === n && (n = Ae),
            this.each(function () {
              T.event.remove(this, e, n, t);
            })
          );
        for (o in e) this.off(o, t, e[o]);
        return this;
      },
    });
  var De = /<(?!area|br|col|embed|hr|img|input|link|meta|param)(([a-z][^\/\0>\x20\t\r\n\f]*)[^>]*)\/>/gi,
    Fe = /<script|<style|<link/i,
    Pe = /checked\s*(?:[^=]|=\s*.checked.)/i,
    je = /^\s*<!(?:\[CDATA\[|--)|(?:\]\]|--)>\s*$/g;
  function Oe(e, t) {
    return (
      ($(e, "table") &&
        $(11 !== t.nodeType ? t : t.firstChild, "tr") &&
        T(e).children("tbody")[0]) ||
      e
    );
  }
  function Me(e) {
    return (e.type = (null !== e.getAttribute("type")) + "/" + e.type), e;
  }
  function Be(e) {
    return (
      "true/" === (e.type || "").slice(0, 5)
        ? (e.type = e.type.slice(5))
        : e.removeAttribute("type"),
      e
    );
  }
  function Le(e, t) {
    var n, i, o, r, s, a, l, u;
    if (1 === t.nodeType) {
      if (
        K.hasData(e) &&
        ((r = K.access(e)), (s = K.set(t, r)), (u = r.events))
      )
        for (o in (delete s.handle, (s.events = {}), u))
          for (n = 0, i = u[o].length; n < i; n++) T.event.add(t, o, u[o][n]);
      Q.hasData(e) && ((a = Q.access(e)), (l = T.extend({}, a)), Q.set(t, l));
    }
  }
  function Ie(n, i, o, r) {
    i = v.apply([], i);
    var e,
      t,
      s,
      a,
      l,
      u,
      c = 0,
      d = n.length,
      p = d - 1,
      h = i[0],
      f = k(h);
    if (f || (1 < d && "string" == typeof h && !y.checkClone && Pe.test(h)))
      return n.each(function (e) {
        var t = n.eq(e);
        f && (i[0] = h.call(this, e, t.html())), Ie(t, i, o, r);
      });
    if (
      d &&
      ((t = (e = we(i, n[0].ownerDocument, !1, n, r)).firstChild),
      1 === e.childNodes.length && (e = t),
      t || r)
    ) {
      for (a = (s = T.map(ve(e, "script"), Me)).length; c < d; c++)
        (l = e),
          c !== p &&
            ((l = T.clone(l, !0, !0)), a && T.merge(s, ve(l, "script"))),
          o.call(n[c], l, c);
      if (a)
        for (u = s[s.length - 1].ownerDocument, T.map(s, Be), c = 0; c < a; c++)
          (l = s[c]),
            fe.test(l.type || "") &&
              !K.access(l, "globalEval") &&
              T.contains(u, l) &&
              (l.src && "module" !== (l.type || "").toLowerCase()
                ? T._evalUrl &&
                  !l.noModule &&
                  T._evalUrl(l.src, {
                    nonce: l.nonce || l.getAttribute("nonce"),
                  })
                : b(l.textContent.replace(je, ""), l, u));
    }
    return n;
  }
  function Ne(e, t, n) {
    for (var i, o = t ? T.filter(t, e) : e, r = 0; null != (i = o[r]); r++)
      n || 1 !== i.nodeType || T.cleanData(ve(i)),
        i.parentNode &&
          (n && re(i) && me(ve(i, "script")), i.parentNode.removeChild(i));
    return e;
  }
  T.extend({
    htmlPrefilter: function (e) {
      return e.replace(De, "<$1></$2>");
    },
    clone: function (e, t, n) {
      var i,
        o,
        r,
        s,
        a,
        l,
        u,
        c = e.cloneNode(!0),
        d = re(e);
      if (
        !(
          y.noCloneChecked ||
          (1 !== e.nodeType && 11 !== e.nodeType) ||
          T.isXMLDoc(e)
        )
      )
        for (s = ve(c), i = 0, o = (r = ve(e)).length; i < o; i++)
          (a = r[i]),
            "input" === (u = (l = s[i]).nodeName.toLowerCase()) &&
            pe.test(a.type)
              ? (l.checked = a.checked)
              : ("input" !== u && "textarea" !== u) ||
                (l.defaultValue = a.defaultValue);
      if (t)
        if (n)
          for (r = r || ve(e), s = s || ve(c), i = 0, o = r.length; i < o; i++)
            Le(r[i], s[i]);
        else Le(e, c);
      return (
        0 < (s = ve(c, "script")).length && me(s, !d && ve(e, "script")), c
      );
    },
    cleanData: function (e) {
      for (var t, n, i, o = T.event.special, r = 0; void 0 !== (n = e[r]); r++)
        if (U(n)) {
          if ((t = n[K.expando])) {
            if (t.events)
              for (i in t.events)
                o[i] ? T.event.remove(n, i) : T.removeEvent(n, i, t.handle);
            n[K.expando] = void 0;
          }
          n[Q.expando] && (n[Q.expando] = void 0);
        }
    },
  }),
    T.fn.extend({
      detach: function (e) {
        return Ne(this, e, !0);
      },
      remove: function (e) {
        return Ne(this, e);
      },
      text: function (e) {
        return z(
          this,
          function (e) {
            return void 0 === e
              ? T.text(this)
              : this.empty().each(function () {
                  (1 !== this.nodeType &&
                    11 !== this.nodeType &&
                    9 !== this.nodeType) ||
                    (this.textContent = e);
                });
          },
          null,
          e,
          arguments.length
        );
      },
      append: function () {
        return Ie(this, arguments, function (e) {
          (1 !== this.nodeType &&
            11 !== this.nodeType &&
            9 !== this.nodeType) ||
            Oe(this, e).appendChild(e);
        });
      },
      prepend: function () {
        return Ie(this, arguments, function (e) {
          if (
            1 === this.nodeType ||
            11 === this.nodeType ||
            9 === this.nodeType
          ) {
            var t = Oe(this, e);
            t.insertBefore(e, t.firstChild);
          }
        });
      },
      before: function () {
        return Ie(this, arguments, function (e) {
          this.parentNode && this.parentNode.insertBefore(e, this);
        });
      },
      after: function () {
        return Ie(this, arguments, function (e) {
          this.parentNode && this.parentNode.insertBefore(e, this.nextSibling);
        });
      },
      empty: function () {
        for (var e, t = 0; null != (e = this[t]); t++)
          1 === e.nodeType && (T.cleanData(ve(e, !1)), (e.textContent = ""));
        return this;
      },
      clone: function (e, t) {
        return (
          (e = null != e && e),
          (t = null == t ? e : t),
          this.map(function () {
            return T.clone(this, e, t);
          })
        );
      },
      html: function (e) {
        return z(
          this,
          function (e) {
            var t = this[0] || {},
              n = 0,
              i = this.length;
            if (void 0 === e && 1 === t.nodeType) return t.innerHTML;
            if (
              "string" == typeof e &&
              !Fe.test(e) &&
              !ge[(he.exec(e) || ["", ""])[1].toLowerCase()]
            ) {
              e = T.htmlPrefilter(e);
              try {
                for (; n < i; n++)
                  1 === (t = this[n] || {}).nodeType &&
                    (T.cleanData(ve(t, !1)), (t.innerHTML = e));
                t = 0;
              } catch (e) {}
            }
            t && this.empty().append(e);
          },
          null,
          e,
          arguments.length
        );
      },
      replaceWith: function () {
        var n = [];
        return Ie(
          this,
          arguments,
          function (e) {
            var t = this.parentNode;
            T.inArray(this, n) < 0 &&
              (T.cleanData(ve(this)), t && t.replaceChild(e, this));
          },
          n
        );
      },
    }),
    T.each(
      {
        appendTo: "append",
        prependTo: "prepend",
        insertBefore: "before",
        insertAfter: "after",
        replaceAll: "replaceWith",
      },
      function (e, s) {
        T.fn[e] = function (e) {
          for (var t, n = [], i = T(e), o = i.length - 1, r = 0; r <= o; r++)
            (t = r === o ? this : this.clone(!0)),
              T(i[r])[s](t),
              l.apply(n, t.get());
          return this.pushStack(n);
        };
      }
    );
  var He,
    qe,
    Re,
    ze,
    Ve,
    We,
    Xe,
    Ye = new RegExp("^(" + te + ")(?!px)[a-z%]+$", "i"),
    Ue = function (e) {
      var t = e.ownerDocument.defaultView;
      return (t && t.opener) || (t = x), t.getComputedStyle(e);
    },
    Ge = new RegExp(ie.join("|"), "i");
  function Ke(e, t, n) {
    var i,
      o,
      r,
      s,
      a = e.style;
    return (
      (n = n || Ue(e)) &&
        ("" !== (s = n.getPropertyValue(t) || n[t]) ||
          re(e) ||
          (s = T.style(e, t)),
        !y.pixelBoxStyles() &&
          Ye.test(s) &&
          Ge.test(t) &&
          ((i = a.width),
          (o = a.minWidth),
          (r = a.maxWidth),
          (a.minWidth = a.maxWidth = a.width = s),
          (s = n.width),
          (a.width = i),
          (a.minWidth = o),
          (a.maxWidth = r))),
      void 0 !== s ? s + "" : s
    );
  }
  function Qe(e, t) {
    return {
      get: function () {
        if (!e()) return (this.get = t).apply(this, arguments);
        delete this.get;
      },
    };
  }
  function Ze() {
    if (Xe) {
      (We.style.cssText =
        "position:absolute;left:-11111px;width:60px;margin-top:1px;padding:0;border:0"),
        (Xe.style.cssText =
          "position:relative;display:block;box-sizing:border-box;overflow:scroll;margin:auto;border:1px;padding:1px;width:60%;top:1%"),
        oe.appendChild(We).appendChild(Xe);
      var e = x.getComputedStyle(Xe);
      (He = "1%" !== e.top),
        (Ve = 12 === Je(e.marginLeft)),
        (Xe.style.right = "60%"),
        (ze = 36 === Je(e.right)),
        (qe = 36 === Je(e.width)),
        (Xe.style.position = "absolute"),
        (Re = 12 === Je(Xe.offsetWidth / 3)),
        oe.removeChild(We),
        (Xe = null);
    }
  }
  function Je(e) {
    return Math.round(parseFloat(e));
  }
  (We = S.createElement("div")),
    (Xe = S.createElement("div")).style &&
      ((Xe.style.backgroundClip = "content-box"),
      (Xe.cloneNode(!0).style.backgroundClip = ""),
      (y.clearCloneStyle = "content-box" === Xe.style.backgroundClip),
      T.extend(y, {
        boxSizingReliable: function () {
          return Ze(), qe;
        },
        pixelBoxStyles: function () {
          return Ze(), ze;
        },
        pixelPosition: function () {
          return Ze(), He;
        },
        reliableMarginLeft: function () {
          return Ze(), Ve;
        },
        scrollboxSize: function () {
          return Ze(), Re;
        },
      }));
  var et = ["Webkit", "Moz", "ms"],
    tt = S.createElement("div").style,
    nt = {};
  function it(e) {
    return (
      T.cssProps[e] ||
      nt[e] ||
      (e in tt
        ? e
        : (nt[e] =
            (function (e) {
              for (
                var t = e[0].toUpperCase() + e.slice(1), n = et.length;
                n--;

              )
                if ((e = et[n] + t) in tt) return e;
            })(e) || e))
    );
  }
  var ot = /^(none|table(?!-c[ea]).+)/,
    rt = /^--/,
    st = { position: "absolute", visibility: "hidden", display: "block" },
    at = { letterSpacing: "0", fontWeight: "400" };
  function lt(e, t, n) {
    var i = ne.exec(t);
    return i ? Math.max(0, i[2] - (n || 0)) + (i[3] || "px") : t;
  }
  function ut(e, t, n, i, o, r) {
    var s = "width" === t ? 1 : 0,
      a = 0,
      l = 0;
    if (n === (i ? "border" : "content")) return 0;
    for (; s < 4; s += 2)
      "margin" === n && (l += T.css(e, n + ie[s], !0, o)),
        i
          ? ("content" === n && (l -= T.css(e, "padding" + ie[s], !0, o)),
            "margin" !== n &&
              (l -= T.css(e, "border" + ie[s] + "Width", !0, o)))
          : ((l += T.css(e, "padding" + ie[s], !0, o)),
            "padding" !== n
              ? (l += T.css(e, "border" + ie[s] + "Width", !0, o))
              : (a += T.css(e, "border" + ie[s] + "Width", !0, o)));
    return (
      !i &&
        0 <= r &&
        (l +=
          Math.max(
            0,
            Math.ceil(
              e["offset" + t[0].toUpperCase() + t.slice(1)] - r - l - a - 0.5
            )
          ) || 0),
      l
    );
  }
  function ct(e, t, n) {
    var i = Ue(e),
      o =
        (!y.boxSizingReliable() || n) &&
        "border-box" === T.css(e, "boxSizing", !1, i),
      r = o,
      s = Ke(e, t, i),
      a = "offset" + t[0].toUpperCase() + t.slice(1);
    if (Ye.test(s)) {
      if (!n) return s;
      s = "auto";
    }
    return (
      ((!y.boxSizingReliable() && o) ||
        "auto" === s ||
        (!parseFloat(s) && "inline" === T.css(e, "display", !1, i))) &&
        e.getClientRects().length &&
        ((o = "border-box" === T.css(e, "boxSizing", !1, i)),
        (r = a in e) && (s = e[a])),
      (s = parseFloat(s) || 0) +
        ut(e, t, n || (o ? "border" : "content"), r, i, s) +
        "px"
    );
  }
  function dt(e, t, n, i, o) {
    return new dt.prototype.init(e, t, n, i, o);
  }
  T.extend({
    cssHooks: {
      opacity: {
        get: function (e, t) {
          if (t) {
            var n = Ke(e, "opacity");
            return "" === n ? "1" : n;
          }
        },
      },
    },
    cssNumber: {
      animationIterationCount: !0,
      columnCount: !0,
      fillOpacity: !0,
      flexGrow: !0,
      flexShrink: !0,
      fontWeight: !0,
      gridArea: !0,
      gridColumn: !0,
      gridColumnEnd: !0,
      gridColumnStart: !0,
      gridRow: !0,
      gridRowEnd: !0,
      gridRowStart: !0,
      lineHeight: !0,
      opacity: !0,
      order: !0,
      orphans: !0,
      widows: !0,
      zIndex: !0,
      zoom: !0,
    },
    cssProps: {},
    style: function (e, t, n, i) {
      if (e && 3 !== e.nodeType && 8 !== e.nodeType && e.style) {
        var o,
          r,
          s,
          a = Y(t),
          l = rt.test(t),
          u = e.style;
        if (
          (l || (t = it(a)), (s = T.cssHooks[t] || T.cssHooks[a]), void 0 === n)
        )
          return s && "get" in s && void 0 !== (o = s.get(e, !1, i)) ? o : u[t];
        "string" == (r = typeof n) &&
          (o = ne.exec(n)) &&
          o[1] &&
          ((n = ue(e, t, o)), (r = "number")),
          null != n &&
            n == n &&
            ("number" !== r ||
              l ||
              (n += (o && o[3]) || (T.cssNumber[a] ? "" : "px")),
            y.clearCloneStyle ||
              "" !== n ||
              0 !== t.indexOf("background") ||
              (u[t] = "inherit"),
            (s && "set" in s && void 0 === (n = s.set(e, n, i))) ||
              (l ? u.setProperty(t, n) : (u[t] = n)));
      }
    },
    css: function (e, t, n, i) {
      var o,
        r,
        s,
        a = Y(t);
      return (
        rt.test(t) || (t = it(a)),
        (s = T.cssHooks[t] || T.cssHooks[a]) &&
          "get" in s &&
          (o = s.get(e, !0, n)),
        void 0 === o && (o = Ke(e, t, i)),
        "normal" === o && t in at && (o = at[t]),
        "" === n || n
          ? ((r = parseFloat(o)), !0 === n || isFinite(r) ? r || 0 : o)
          : o
      );
    },
  }),
    T.each(["height", "width"], function (e, l) {
      T.cssHooks[l] = {
        get: function (e, t, n) {
          if (t)
            return !ot.test(T.css(e, "display")) ||
              (e.getClientRects().length && e.getBoundingClientRect().width)
              ? ct(e, l, n)
              : le(e, st, function () {
                  return ct(e, l, n);
                });
        },
        set: function (e, t, n) {
          var i,
            o = Ue(e),
            r = !y.scrollboxSize() && "absolute" === o.position,
            s = (r || n) && "border-box" === T.css(e, "boxSizing", !1, o),
            a = n ? ut(e, l, n, s, o) : 0;
          return (
            s &&
              r &&
              (a -= Math.ceil(
                e["offset" + l[0].toUpperCase() + l.slice(1)] -
                  parseFloat(o[l]) -
                  ut(e, l, "border", !1, o) -
                  0.5
              )),
            a &&
              (i = ne.exec(t)) &&
              "px" !== (i[3] || "px") &&
              ((e.style[l] = t), (t = T.css(e, l))),
            lt(0, t, a)
          );
        },
      };
    }),
    (T.cssHooks.marginLeft = Qe(y.reliableMarginLeft, function (e, t) {
      if (t)
        return (
          (parseFloat(Ke(e, "marginLeft")) ||
            e.getBoundingClientRect().left -
              le(e, { marginLeft: 0 }, function () {
                return e.getBoundingClientRect().left;
              })) + "px"
        );
    })),
    T.each({ margin: "", padding: "", border: "Width" }, function (o, r) {
      (T.cssHooks[o + r] = {
        expand: function (e) {
          for (
            var t = 0, n = {}, i = "string" == typeof e ? e.split(" ") : [e];
            t < 4;
            t++
          )
            n[o + ie[t] + r] = i[t] || i[t - 2] || i[0];
          return n;
        },
      }),
        "margin" !== o && (T.cssHooks[o + r].set = lt);
    }),
    T.fn.extend({
      css: function (e, t) {
        return z(
          this,
          function (e, t, n) {
            var i,
              o,
              r = {},
              s = 0;
            if (Array.isArray(t)) {
              for (i = Ue(e), o = t.length; s < o; s++)
                r[t[s]] = T.css(e, t[s], !1, i);
              return r;
            }
            return void 0 !== n ? T.style(e, t, n) : T.css(e, t);
          },
          e,
          t,
          1 < arguments.length
        );
      },
    }),
    (((T.Tween = dt).prototype = {
      constructor: dt,
      init: function (e, t, n, i, o, r) {
        (this.elem = e),
          (this.prop = n),
          (this.easing = o || T.easing._default),
          (this.options = t),
          (this.start = this.now = this.cur()),
          (this.end = i),
          (this.unit = r || (T.cssNumber[n] ? "" : "px"));
      },
      cur: function () {
        var e = dt.propHooks[this.prop];
        return e && e.get ? e.get(this) : dt.propHooks._default.get(this);
      },
      run: function (e) {
        var t,
          n = dt.propHooks[this.prop];
        return (
          this.options.duration
            ? (this.pos = t = T.easing[this.easing](
                e,
                this.options.duration * e,
                0,
                1,
                this.options.duration
              ))
            : (this.pos = t = e),
          (this.now = (this.end - this.start) * t + this.start),
          this.options.step &&
            this.options.step.call(this.elem, this.now, this),
          n && n.set ? n.set(this) : dt.propHooks._default.set(this),
          this
        );
      },
    }).init.prototype = dt.prototype),
    ((dt.propHooks = {
      _default: {
        get: function (e) {
          var t;
          return 1 !== e.elem.nodeType ||
            (null != e.elem[e.prop] && null == e.elem.style[e.prop])
            ? e.elem[e.prop]
            : (t = T.css(e.elem, e.prop, "")) && "auto" !== t
            ? t
            : 0;
        },
        set: function (e) {
          T.fx.step[e.prop]
            ? T.fx.step[e.prop](e)
            : 1 !== e.elem.nodeType ||
              (!T.cssHooks[e.prop] && null == e.elem.style[it(e.prop)])
            ? (e.elem[e.prop] = e.now)
            : T.style(e.elem, e.prop, e.now + e.unit);
        },
      },
    }).scrollTop = dt.propHooks.scrollLeft = {
      set: function (e) {
        e.elem.nodeType && e.elem.parentNode && (e.elem[e.prop] = e.now);
      },
    }),
    (T.easing = {
      linear: function (e) {
        return e;
      },
      swing: function (e) {
        return 0.5 - Math.cos(e * Math.PI) / 2;
      },
      _default: "swing",
    }),
    (T.fx = dt.prototype.init),
    (T.fx.step = {});
  var pt,
    ht,
    ft,
    gt,
    vt = /^(?:toggle|show|hide)$/,
    mt = /queueHooks$/;
  function yt() {
    ht &&
      (!1 === S.hidden && x.requestAnimationFrame
        ? x.requestAnimationFrame(yt)
        : x.setTimeout(yt, T.fx.interval),
      T.fx.tick());
  }
  function kt() {
    return (
      x.setTimeout(function () {
        pt = void 0;
      }),
      (pt = Date.now())
    );
  }
  function bt(e, t) {
    var n,
      i = 0,
      o = { height: e };
    for (t = t ? 1 : 0; i < 4; i += 2 - t)
      o["margin" + (n = ie[i])] = o["padding" + n] = e;
    return t && (o.opacity = o.width = e), o;
  }
  function wt(e, t, n) {
    for (
      var i,
        o = (Ct.tweeners[t] || []).concat(Ct.tweeners["*"]),
        r = 0,
        s = o.length;
      r < s;
      r++
    )
      if ((i = o[r].call(n, t, e))) return i;
  }
  function Ct(r, e, t) {
    var n,
      s,
      i = 0,
      o = Ct.prefilters.length,
      a = T.Deferred().always(function () {
        delete l.elem;
      }),
      l = function () {
        if (s) return !1;
        for (
          var e = pt || kt(),
            t = Math.max(0, u.startTime + u.duration - e),
            n = 1 - (t / u.duration || 0),
            i = 0,
            o = u.tweens.length;
          i < o;
          i++
        )
          u.tweens[i].run(n);
        return (
          a.notifyWith(r, [u, n, t]),
          n < 1 && o
            ? t
            : (o || a.notifyWith(r, [u, 1, 0]), a.resolveWith(r, [u]), !1)
        );
      },
      u = a.promise({
        elem: r,
        props: T.extend({}, e),
        opts: T.extend(!0, { specialEasing: {}, easing: T.easing._default }, t),
        originalProperties: e,
        originalOptions: t,
        startTime: pt || kt(),
        duration: t.duration,
        tweens: [],
        createTween: function (e, t) {
          var n = T.Tween(
            r,
            u.opts,
            e,
            t,
            u.opts.specialEasing[e] || u.opts.easing
          );
          return u.tweens.push(n), n;
        },
        stop: function (e) {
          var t = 0,
            n = e ? u.tweens.length : 0;
          if (s) return this;
          for (s = !0; t < n; t++) u.tweens[t].run(1);
          return (
            e
              ? (a.notifyWith(r, [u, 1, 0]), a.resolveWith(r, [u, e]))
              : a.rejectWith(r, [u, e]),
            this
          );
        },
      }),
      c = u.props;
    for (
      (function (e, t) {
        var n, i, o, r, s;
        for (n in e)
          if (
            ((o = t[(i = Y(n))]),
            (r = e[n]),
            Array.isArray(r) && ((o = r[1]), (r = e[n] = r[0])),
            n !== i && ((e[i] = r), delete e[n]),
            (s = T.cssHooks[i]) && ("expand" in s))
          )
            for (n in ((r = s.expand(r)), delete e[i], r))
              (n in e) || ((e[n] = r[n]), (t[n] = o));
          else t[i] = o;
      })(c, u.opts.specialEasing);
      i < o;
      i++
    )
      if ((n = Ct.prefilters[i].call(u, r, c, u.opts)))
        return (
          k(n.stop) &&
            (T._queueHooks(u.elem, u.opts.queue).stop = n.stop.bind(n)),
          n
        );
    return (
      T.map(c, wt, u),
      k(u.opts.start) && u.opts.start.call(r, u),
      u
        .progress(u.opts.progress)
        .done(u.opts.done, u.opts.complete)
        .fail(u.opts.fail)
        .always(u.opts.always),
      T.fx.timer(T.extend(l, { elem: r, anim: u, queue: u.opts.queue })),
      u
    );
  }
  (T.Animation = T.extend(Ct, {
    tweeners: {
      "*": [
        function (e, t) {
          var n = this.createTween(e, t);
          return ue(n.elem, e, ne.exec(t), n), n;
        },
      ],
    },
    tweener: function (e, t) {
      for (
        var n, i = 0, o = (e = k(e) ? ((t = e), ["*"]) : e.match(B)).length;
        i < o;
        i++
      )
        (n = e[i]),
          (Ct.tweeners[n] = Ct.tweeners[n] || []),
          Ct.tweeners[n].unshift(t);
    },
    prefilters: [
      function (e, t, n) {
        var i,
          o,
          r,
          s,
          a,
          l,
          u,
          c,
          d = "width" in t || "height" in t,
          p = this,
          h = {},
          f = e.style,
          g = e.nodeType && ae(e),
          v = K.get(e, "fxshow");
        for (i in (n.queue ||
          (null == (s = T._queueHooks(e, "fx")).unqueued &&
            ((s.unqueued = 0),
            (a = s.empty.fire),
            (s.empty.fire = function () {
              s.unqueued || a();
            })),
          s.unqueued++,
          p.always(function () {
            p.always(function () {
              s.unqueued--, T.queue(e, "fx").length || s.empty.fire();
            });
          })),
        t))
          if (((o = t[i]), vt.test(o))) {
            if (
              (delete t[i],
              (r = r || "toggle" === o),
              o === (g ? "hide" : "show"))
            ) {
              if ("show" !== o || !v || void 0 === v[i]) continue;
              g = !0;
            }
            h[i] = (v && v[i]) || T.style(e, i);
          }
        if ((l = !T.isEmptyObject(t)) || !T.isEmptyObject(h))
          for (i in (d &&
            1 === e.nodeType &&
            ((n.overflow = [f.overflow, f.overflowX, f.overflowY]),
            null == (u = v && v.display) && (u = K.get(e, "display")),
            "none" === (c = T.css(e, "display")) &&
              (u
                ? (c = u)
                : (de([e], !0),
                  (u = e.style.display || u),
                  (c = T.css(e, "display")),
                  de([e]))),
            ("inline" === c || ("inline-block" === c && null != u)) &&
              "none" === T.css(e, "float") &&
              (l ||
                (p.done(function () {
                  f.display = u;
                }),
                null == u && ((c = f.display), (u = "none" === c ? "" : c))),
              (f.display = "inline-block"))),
          n.overflow &&
            ((f.overflow = "hidden"),
            p.always(function () {
              (f.overflow = n.overflow[0]),
                (f.overflowX = n.overflow[1]),
                (f.overflowY = n.overflow[2]);
            })),
          (l = !1),
          h))
            l ||
              (v
                ? "hidden" in v && (g = v.hidden)
                : (v = K.access(e, "fxshow", { display: u })),
              r && (v.hidden = !g),
              g && de([e], !0),
              p.done(function () {
                for (i in (g || de([e]), K.remove(e, "fxshow"), h))
                  T.style(e, i, h[i]);
              })),
              (l = wt(g ? v[i] : 0, i, p)),
              i in v ||
                ((v[i] = l.start), g && ((l.end = l.start), (l.start = 0)));
      },
    ],
    prefilter: function (e, t) {
      t ? Ct.prefilters.unshift(e) : Ct.prefilters.push(e);
    },
  })),
    (T.speed = function (e, t, n) {
      var i =
        e && "object" == typeof e
          ? T.extend({}, e)
          : {
              complete: n || (!n && t) || (k(e) && e),
              duration: e,
              easing: (n && t) || (t && !k(t) && t),
            };
      return (
        T.fx.off
          ? (i.duration = 0)
          : "number" != typeof i.duration &&
            (i.duration in T.fx.speeds
              ? (i.duration = T.fx.speeds[i.duration])
              : (i.duration = T.fx.speeds._default)),
        (null != i.queue && !0 !== i.queue) || (i.queue = "fx"),
        (i.old = i.complete),
        (i.complete = function () {
          k(i.old) && i.old.call(this), i.queue && T.dequeue(this, i.queue);
        }),
        i
      );
    }),
    T.fn.extend({
      fadeTo: function (e, t, n, i) {
        return this.filter(ae)
          .css("opacity", 0)
          .show()
          .end()
          .animate({ opacity: t }, e, n, i);
      },
      animate: function (t, e, n, i) {
        function o() {
          var e = Ct(this, T.extend({}, t), s);
          (r || K.get(this, "finish")) && e.stop(!0);
        }
        var r = T.isEmptyObject(t),
          s = T.speed(e, n, i);
        return (
          (o.finish = o),
          r || !1 === s.queue ? this.each(o) : this.queue(s.queue, o)
        );
      },
      stop: function (o, e, r) {
        function s(e) {
          var t = e.stop;
          delete e.stop, t(r);
        }
        return (
          "string" != typeof o && ((r = e), (e = o), (o = void 0)),
          e && !1 !== o && this.queue(o || "fx", []),
          this.each(function () {
            var e = !0,
              t = null != o && o + "queueHooks",
              n = T.timers,
              i = K.get(this);
            if (t) i[t] && i[t].stop && s(i[t]);
            else for (t in i) i[t] && i[t].stop && mt.test(t) && s(i[t]);
            for (t = n.length; t--; )
              n[t].elem !== this ||
                (null != o && n[t].queue !== o) ||
                (n[t].anim.stop(r), (e = !1), n.splice(t, 1));
            (!e && r) || T.dequeue(this, o);
          })
        );
      },
      finish: function (s) {
        return (
          !1 !== s && (s = s || "fx"),
          this.each(function () {
            var e,
              t = K.get(this),
              n = t[s + "queue"],
              i = t[s + "queueHooks"],
              o = T.timers,
              r = n ? n.length : 0;
            for (
              t.finish = !0,
                T.queue(this, s, []),
                i && i.stop && i.stop.call(this, !0),
                e = o.length;
              e--;

            )
              o[e].elem === this &&
                o[e].queue === s &&
                (o[e].anim.stop(!0), o.splice(e, 1));
            for (e = 0; e < r; e++)
              n[e] && n[e].finish && n[e].finish.call(this);
            delete t.finish;
          })
        );
      },
    }),
    T.each(["toggle", "show", "hide"], function (e, i) {
      var o = T.fn[i];
      T.fn[i] = function (e, t, n) {
        return null == e || "boolean" == typeof e
          ? o.apply(this, arguments)
          : this.animate(bt(i, !0), e, t, n);
      };
    }),
    T.each(
      {
        slideDown: bt("show"),
        slideUp: bt("hide"),
        slideToggle: bt("toggle"),
        fadeIn: { opacity: "show" },
        fadeOut: { opacity: "hide" },
        fadeToggle: { opacity: "toggle" },
      },
      function (e, i) {
        T.fn[e] = function (e, t, n) {
          return this.animate(i, e, t, n);
        };
      }
    ),
    (T.timers = []),
    (T.fx.tick = function () {
      var e,
        t = 0,
        n = T.timers;
      for (pt = Date.now(); t < n.length; t++)
        (e = n[t])() || n[t] !== e || n.splice(t--, 1);
      n.length || T.fx.stop(), (pt = void 0);
    }),
    (T.fx.timer = function (e) {
      T.timers.push(e), T.fx.start();
    }),
    (T.fx.interval = 13),
    (T.fx.start = function () {
      ht || ((ht = !0), yt());
    }),
    (T.fx.stop = function () {
      ht = null;
    }),
    (T.fx.speeds = { slow: 600, fast: 200, _default: 400 }),
    (T.fn.delay = function (i, e) {
      return (
        (i = (T.fx && T.fx.speeds[i]) || i),
        (e = e || "fx"),
        this.queue(e, function (e, t) {
          var n = x.setTimeout(e, i);
          t.stop = function () {
            x.clearTimeout(n);
          };
        })
      );
    }),
    (ft = S.createElement("input")),
    (gt = S.createElement("select").appendChild(S.createElement("option"))),
    (ft.type = "checkbox"),
    (y.checkOn = "" !== ft.value),
    (y.optSelected = gt.selected),
    ((ft = S.createElement("input")).value = "t"),
    (ft.type = "radio"),
    (y.radioValue = "t" === ft.value);
  var xt,
    St = T.expr.attrHandle;
  T.fn.extend({
    attr: function (e, t) {
      return z(this, T.attr, e, t, 1 < arguments.length);
    },
    removeAttr: function (e) {
      return this.each(function () {
        T.removeAttr(this, e);
      });
    },
  }),
    T.extend({
      attr: function (e, t, n) {
        var i,
          o,
          r = e.nodeType;
        if (3 !== r && 8 !== r && 2 !== r)
          return void 0 === e.getAttribute
            ? T.prop(e, t, n)
            : ((1 === r && T.isXMLDoc(e)) ||
                (o =
                  T.attrHooks[t.toLowerCase()] ||
                  (T.expr.match.bool.test(t) ? xt : void 0)),
              void 0 !== n
                ? null === n
                  ? void T.removeAttr(e, t)
                  : o && "set" in o && void 0 !== (i = o.set(e, n, t))
                  ? i
                  : (e.setAttribute(t, n + ""), n)
                : !(o && "get" in o && null !== (i = o.get(e, t))) &&
                  null == (i = T.find.attr(e, t))
                ? void 0
                : i);
      },
      attrHooks: {
        type: {
          set: function (e, t) {
            if (!y.radioValue && "radio" === t && $(e, "input")) {
              var n = e.value;
              return e.setAttribute("type", t), n && (e.value = n), t;
            }
          },
        },
      },
      removeAttr: function (e, t) {
        var n,
          i = 0,
          o = t && t.match(B);
        if (o && 1 === e.nodeType) for (; (n = o[i++]); ) e.removeAttribute(n);
      },
    }),
    (xt = {
      set: function (e, t, n) {
        return !1 === t ? T.removeAttr(e, n) : e.setAttribute(n, n), n;
      },
    }),
    T.each(T.expr.match.bool.source.match(/\w+/g), function (e, t) {
      var s = St[t] || T.find.attr;
      St[t] = function (e, t, n) {
        var i,
          o,
          r = t.toLowerCase();
        return (
          n ||
            ((o = St[r]),
            (St[r] = i),
            (i = null != s(e, t, n) ? r : null),
            (St[r] = o)),
          i
        );
      };
    });
  var Tt = /^(?:input|select|textarea|button)$/i,
    At = /^(?:a|area)$/i;
  function Et(e) {
    return (e.match(B) || []).join(" ");
  }
  function $t(e) {
    return (e.getAttribute && e.getAttribute("class")) || "";
  }
  function _t(e) {
    return Array.isArray(e) ? e : ("string" == typeof e && e.match(B)) || [];
  }
  T.fn.extend({
    prop: function (e, t) {
      return z(this, T.prop, e, t, 1 < arguments.length);
    },
    removeProp: function (e) {
      return this.each(function () {
        delete this[T.propFix[e] || e];
      });
    },
  }),
    T.extend({
      prop: function (e, t, n) {
        var i,
          o,
          r = e.nodeType;
        if (3 !== r && 8 !== r && 2 !== r)
          return (
            (1 === r && T.isXMLDoc(e)) ||
              ((t = T.propFix[t] || t), (o = T.propHooks[t])),
            void 0 !== n
              ? o && "set" in o && void 0 !== (i = o.set(e, n, t))
                ? i
                : (e[t] = n)
              : o && "get" in o && null !== (i = o.get(e, t))
              ? i
              : e[t]
          );
      },
      propHooks: {
        tabIndex: {
          get: function (e) {
            var t = T.find.attr(e, "tabindex");
            return t
              ? parseInt(t, 10)
              : Tt.test(e.nodeName) || (At.test(e.nodeName) && e.href)
              ? 0
              : -1;
          },
        },
      },
      propFix: { for: "htmlFor", class: "className" },
    }),
    y.optSelected ||
      (T.propHooks.selected = {
        get: function (e) {
          var t = e.parentNode;
          return t && t.parentNode && t.parentNode.selectedIndex, null;
        },
        set: function (e) {
          var t = e.parentNode;
          t && (t.selectedIndex, t.parentNode && t.parentNode.selectedIndex);
        },
      }),
    T.each(
      [
        "tabIndex",
        "readOnly",
        "maxLength",
        "cellSpacing",
        "cellPadding",
        "rowSpan",
        "colSpan",
        "useMap",
        "frameBorder",
        "contentEditable",
      ],
      function () {
        T.propFix[this.toLowerCase()] = this;
      }
    ),
    T.fn.extend({
      addClass: function (t) {
        var e,
          n,
          i,
          o,
          r,
          s,
          a,
          l = 0;
        if (k(t))
          return this.each(function (e) {
            T(this).addClass(t.call(this, e, $t(this)));
          });
        if ((e = _t(t)).length)
          for (; (n = this[l++]); )
            if (((o = $t(n)), (i = 1 === n.nodeType && " " + Et(o) + " "))) {
              for (s = 0; (r = e[s++]); )
                i.indexOf(" " + r + " ") < 0 && (i += r + " ");
              o !== (a = Et(i)) && n.setAttribute("class", a);
            }
        return this;
      },
      removeClass: function (t) {
        var e,
          n,
          i,
          o,
          r,
          s,
          a,
          l = 0;
        if (k(t))
          return this.each(function (e) {
            T(this).removeClass(t.call(this, e, $t(this)));
          });
        if (!arguments.length) return this.attr("class", "");
        if ((e = _t(t)).length)
          for (; (n = this[l++]); )
            if (((o = $t(n)), (i = 1 === n.nodeType && " " + Et(o) + " "))) {
              for (s = 0; (r = e[s++]); )
                for (; -1 < i.indexOf(" " + r + " "); )
                  i = i.replace(" " + r + " ", " ");
              o !== (a = Et(i)) && n.setAttribute("class", a);
            }
        return this;
      },
      toggleClass: function (o, t) {
        var r = typeof o,
          s = "string" == r || Array.isArray(o);
        return "boolean" == typeof t && s
          ? t
            ? this.addClass(o)
            : this.removeClass(o)
          : k(o)
          ? this.each(function (e) {
              T(this).toggleClass(o.call(this, e, $t(this), t), t);
            })
          : this.each(function () {
              var e, t, n, i;
              if (s)
                for (t = 0, n = T(this), i = _t(o); (e = i[t++]); )
                  n.hasClass(e) ? n.removeClass(e) : n.addClass(e);
              else
                (void 0 !== o && "boolean" != r) ||
                  ((e = $t(this)) && K.set(this, "__className__", e),
                  this.setAttribute &&
                    this.setAttribute(
                      "class",
                      (!e && !1 !== o && K.get(this, "__className__")) || ""
                    ));
            });
      },
      hasClass: function (e) {
        var t,
          n,
          i = 0;
        for (t = " " + e + " "; (n = this[i++]); )
          if (1 === n.nodeType && -1 < (" " + Et($t(n)) + " ").indexOf(t))
            return !0;
        return !1;
      },
    });
  var Dt = /\r/g;
  T.fn.extend({
    val: function (n) {
      var i,
        e,
        o,
        t = this[0];
      return arguments.length
        ? ((o = k(n)),
          this.each(function (e) {
            var t;
            1 === this.nodeType &&
              (null == (t = o ? n.call(this, e, T(this).val()) : n)
                ? (t = "")
                : "number" == typeof t
                ? (t += "")
                : Array.isArray(t) &&
                  (t = T.map(t, function (e) {
                    return null == e ? "" : e + "";
                  })),
              ((i =
                T.valHooks[this.type] ||
                T.valHooks[this.nodeName.toLowerCase()]) &&
                "set" in i &&
                void 0 !== i.set(this, t, "value")) ||
                (this.value = t));
          }))
        : t
        ? (i = T.valHooks[t.type] || T.valHooks[t.nodeName.toLowerCase()]) &&
          "get" in i &&
          void 0 !== (e = i.get(t, "value"))
          ? e
          : "string" == typeof (e = t.value)
          ? e.replace(Dt, "")
          : null == e
          ? ""
          : e
        : void 0;
    },
  }),
    T.extend({
      valHooks: {
        option: {
          get: function (e) {
            var t = T.find.attr(e, "value");
            return null != t ? t : Et(T.text(e));
          },
        },
        select: {
          get: function (e) {
            var t,
              n,
              i,
              o = e.options,
              r = e.selectedIndex,
              s = "select-one" === e.type,
              a = s ? null : [],
              l = s ? r + 1 : o.length;
            for (i = r < 0 ? l : s ? r : 0; i < l; i++)
              if (
                ((n = o[i]).selected || i === r) &&
                !n.disabled &&
                (!n.parentNode.disabled || !$(n.parentNode, "optgroup"))
              ) {
                if (((t = T(n).val()), s)) return t;
                a.push(t);
              }
            return a;
          },
          set: function (e, t) {
            for (
              var n, i, o = e.options, r = T.makeArray(t), s = o.length;
              s--;

            )
              ((i = o[s]).selected =
                -1 < T.inArray(T.valHooks.option.get(i), r)) && (n = !0);
            return n || (e.selectedIndex = -1), r;
          },
        },
      },
    }),
    T.each(["radio", "checkbox"], function () {
      (T.valHooks[this] = {
        set: function (e, t) {
          if (Array.isArray(t))
            return (e.checked = -1 < T.inArray(T(e).val(), t));
        },
      }),
        y.checkOn ||
          (T.valHooks[this].get = function (e) {
            return null === e.getAttribute("value") ? "on" : e.value;
          });
    }),
    (y.focusin = "onfocusin" in x);
  function Ft(e) {
    e.stopPropagation();
  }
  var Pt = /^(?:focusinfocus|focusoutblur)$/;
  T.extend(T.event, {
    trigger: function (e, t, n, i) {
      var o,
        r,
        s,
        a,
        l,
        u,
        c,
        d,
        p = [n || S],
        h = m.call(e, "type") ? e.type : e,
        f = m.call(e, "namespace") ? e.namespace.split(".") : [];
      if (
        ((r = d = s = n = n || S),
        3 !== n.nodeType &&
          8 !== n.nodeType &&
          !Pt.test(h + T.event.triggered) &&
          (-1 < h.indexOf(".") && ((h = (f = h.split(".")).shift()), f.sort()),
          (l = h.indexOf(":") < 0 && "on" + h),
          ((e = e[T.expando]
            ? e
            : new T.Event(h, "object" == typeof e && e)).isTrigger = i ? 2 : 3),
          (e.namespace = f.join(".")),
          (e.rnamespace = e.namespace
            ? new RegExp("(^|\\.)" + f.join("\\.(?:.*\\.|)") + "(\\.|$)")
            : null),
          (e.result = void 0),
          e.target || (e.target = n),
          (t = null == t ? [e] : T.makeArray(t, [e])),
          (c = T.event.special[h] || {}),
          i || !c.trigger || !1 !== c.trigger.apply(n, t)))
      ) {
        if (!i && !c.noBubble && !g(n)) {
          for (
            a = c.delegateType || h, Pt.test(a + h) || (r = r.parentNode);
            r;
            r = r.parentNode
          )
            p.push(r), (s = r);
          s === (n.ownerDocument || S) &&
            p.push(s.defaultView || s.parentWindow || x);
        }
        for (o = 0; (r = p[o++]) && !e.isPropagationStopped(); )
          (d = r),
            (e.type = 1 < o ? a : c.bindType || h),
            (u = (K.get(r, "events") || {})[e.type] && K.get(r, "handle")) &&
              u.apply(r, t),
            (u = l && r[l]) &&
              u.apply &&
              U(r) &&
              ((e.result = u.apply(r, t)),
              !1 === e.result && e.preventDefault());
        return (
          (e.type = h),
          i ||
            e.isDefaultPrevented() ||
            (c._default && !1 !== c._default.apply(p.pop(), t)) ||
            !U(n) ||
            (l &&
              k(n[h]) &&
              !g(n) &&
              ((s = n[l]) && (n[l] = null),
              (T.event.triggered = h),
              e.isPropagationStopped() && d.addEventListener(h, Ft),
              n[h](),
              e.isPropagationStopped() && d.removeEventListener(h, Ft),
              (T.event.triggered = void 0),
              s && (n[l] = s))),
          e.result
        );
      }
    },
    simulate: function (e, t, n) {
      var i = T.extend(new T.Event(), n, { type: e, isSimulated: !0 });
      T.event.trigger(i, null, t);
    },
  }),
    T.fn.extend({
      trigger: function (e, t) {
        return this.each(function () {
          T.event.trigger(e, t, this);
        });
      },
      triggerHandler: function (e, t) {
        var n = this[0];
        if (n) return T.event.trigger(e, t, n, !0);
      },
    }),
    y.focusin ||
      T.each({ focus: "focusin", blur: "focusout" }, function (n, i) {
        function o(e) {
          T.event.simulate(i, e.target, T.event.fix(e));
        }
        T.event.special[i] = {
          setup: function () {
            var e = this.ownerDocument || this,
              t = K.access(e, i);
            t || e.addEventListener(n, o, !0), K.access(e, i, (t || 0) + 1);
          },
          teardown: function () {
            var e = this.ownerDocument || this,
              t = K.access(e, i) - 1;
            t
              ? K.access(e, i, t)
              : (e.removeEventListener(n, o, !0), K.remove(e, i));
          },
        };
      });
  var jt = x.location,
    Ot = Date.now(),
    Mt = /\?/;
  T.parseXML = function (e) {
    var t;
    if (!e || "string" != typeof e) return null;
    try {
      t = new x.DOMParser().parseFromString(e, "text/xml");
    } catch (e) {
      t = void 0;
    }
    return (
      (t && !t.getElementsByTagName("parsererror").length) ||
        T.error("Invalid XML: " + e),
      t
    );
  };
  var Bt = /\[\]$/,
    Lt = /\r?\n/g,
    It = /^(?:submit|button|image|reset|file)$/i,
    Nt = /^(?:input|select|textarea|keygen)/i;
  function Ht(n, e, i, o) {
    var t;
    if (Array.isArray(e))
      T.each(e, function (e, t) {
        i || Bt.test(n)
          ? o(n, t)
          : Ht(
              n + "[" + ("object" == typeof t && null != t ? e : "") + "]",
              t,
              i,
              o
            );
      });
    else if (i || "object" !== w(e)) o(n, e);
    else for (t in e) Ht(n + "[" + t + "]", e[t], i, o);
  }
  (T.param = function (e, t) {
    function n(e, t) {
      var n = k(t) ? t() : t;
      o[o.length] =
        encodeURIComponent(e) + "=" + encodeURIComponent(null == n ? "" : n);
    }
    var i,
      o = [];
    if (null == e) return "";
    if (Array.isArray(e) || (e.jquery && !T.isPlainObject(e)))
      T.each(e, function () {
        n(this.name, this.value);
      });
    else for (i in e) Ht(i, e[i], t, n);
    return o.join("&");
  }),
    T.fn.extend({
      serialize: function () {
        return T.param(this.serializeArray());
      },
      serializeArray: function () {
        return this.map(function () {
          var e = T.prop(this, "elements");
          return e ? T.makeArray(e) : this;
        })
          .filter(function () {
            var e = this.type;
            return (
              this.name &&
              !T(this).is(":disabled") &&
              Nt.test(this.nodeName) &&
              !It.test(e) &&
              (this.checked || !pe.test(e))
            );
          })
          .map(function (e, t) {
            var n = T(this).val();
            return null == n
              ? null
              : Array.isArray(n)
              ? T.map(n, function (e) {
                  return { name: t.name, value: e.replace(Lt, "\r\n") };
                })
              : { name: t.name, value: n.replace(Lt, "\r\n") };
          })
          .get();
      },
    });
  var qt = /%20/g,
    Rt = /#.*$/,
    zt = /([?&])_=[^&]*/,
    Vt = /^(.*?):[ \t]*([^\r\n]*)$/gm,
    Wt = /^(?:GET|HEAD)$/,
    Xt = /^\/\//,
    Yt = {},
    Ut = {},
    Gt = "*/".concat("*"),
    Kt = S.createElement("a");
  function Qt(r) {
    return function (e, t) {
      "string" != typeof e && ((t = e), (e = "*"));
      var n,
        i = 0,
        o = e.toLowerCase().match(B) || [];
      if (k(t))
        for (; (n = o[i++]); )
          "+" === n[0]
            ? ((n = n.slice(1) || "*"), (r[n] = r[n] || []).unshift(t))
            : (r[n] = r[n] || []).push(t);
    };
  }
  function Zt(t, o, r, s) {
    var a = {},
      l = t === Ut;
    function u(e) {
      var i;
      return (
        (a[e] = !0),
        T.each(t[e] || [], function (e, t) {
          var n = t(o, r, s);
          return "string" != typeof n || l || a[n]
            ? l
              ? !(i = n)
              : void 0
            : (o.dataTypes.unshift(n), u(n), !1);
        }),
        i
      );
    }
    return u(o.dataTypes[0]) || (!a["*"] && u("*"));
  }
  function Jt(e, t) {
    var n,
      i,
      o = T.ajaxSettings.flatOptions || {};
    for (n in t) void 0 !== t[n] && ((o[n] ? e : (i = i || {}))[n] = t[n]);
    return i && T.extend(!0, e, i), e;
  }
  (Kt.href = jt.href),
    T.extend({
      active: 0,
      lastModified: {},
      etag: {},
      ajaxSettings: {
        url: jt.href,
        type: "GET",
        isLocal: /^(?:about|app|app-storage|.+-extension|file|res|widget):$/.test(
          jt.protocol
        ),
        global: !0,
        processData: !0,
        async: !0,
        contentType: "application/x-www-form-urlencoded; charset=UTF-8",
        accepts: {
          "*": Gt,
          text: "text/plain",
          html: "text/html",
          xml: "application/xml, text/xml",
          json: "application/json, text/javascript",
        },
        contents: { xml: /\bxml\b/, html: /\bhtml/, json: /\bjson\b/ },
        responseFields: {
          xml: "responseXML",
          text: "responseText",
          json: "responseJSON",
        },
        converters: {
          "* text": String,
          "text html": !0,
          "text json": JSON.parse,
          "text xml": T.parseXML,
        },
        flatOptions: { url: !0, context: !0 },
      },
      ajaxSetup: function (e, t) {
        return t ? Jt(Jt(e, T.ajaxSettings), t) : Jt(T.ajaxSettings, e);
      },
      ajaxPrefilter: Qt(Yt),
      ajaxTransport: Qt(Ut),
      ajax: function (e, t) {
        "object" == typeof e && ((t = e), (e = void 0)), (t = t || {});
        var c,
          d,
          p,
          n,
          h,
          i,
          f,
          g,
          o,
          r,
          v = T.ajaxSetup({}, t),
          m = v.context || v,
          y = v.context && (m.nodeType || m.jquery) ? T(m) : T.event,
          k = T.Deferred(),
          b = T.Callbacks("once memory"),
          w = v.statusCode || {},
          s = {},
          a = {},
          l = "canceled",
          C = {
            readyState: 0,
            getResponseHeader: function (e) {
              var t;
              if (f) {
                if (!n)
                  for (n = {}; (t = Vt.exec(p)); )
                    n[t[1].toLowerCase() + " "] = (
                      n[t[1].toLowerCase() + " "] || []
                    ).concat(t[2]);
                t = n[e.toLowerCase() + " "];
              }
              return null == t ? null : t.join(", ");
            },
            getAllResponseHeaders: function () {
              return f ? p : null;
            },
            setRequestHeader: function (e, t) {
              return (
                null == f &&
                  ((e = a[e.toLowerCase()] = a[e.toLowerCase()] || e),
                  (s[e] = t)),
                this
              );
            },
            overrideMimeType: function (e) {
              return null == f && (v.mimeType = e), this;
            },
            statusCode: function (e) {
              var t;
              if (e)
                if (f) C.always(e[C.status]);
                else for (t in e) w[t] = [w[t], e[t]];
              return this;
            },
            abort: function (e) {
              var t = e || l;
              return c && c.abort(t), u(0, t), this;
            },
          };
        if (
          (k.promise(C),
          (v.url = ((e || v.url || jt.href) + "").replace(
            Xt,
            jt.protocol + "//"
          )),
          (v.type = t.method || t.type || v.method || v.type),
          (v.dataTypes = (v.dataType || "*").toLowerCase().match(B) || [""]),
          null == v.crossDomain)
        ) {
          i = S.createElement("a");
          try {
            (i.href = v.url),
              (i.href = i.href),
              (v.crossDomain =
                Kt.protocol + "//" + Kt.host != i.protocol + "//" + i.host);
          } catch (e) {
            v.crossDomain = !0;
          }
        }
        if (
          (v.data &&
            v.processData &&
            "string" != typeof v.data &&
            (v.data = T.param(v.data, v.traditional)),
          Zt(Yt, v, t, C),
          f)
        )
          return C;
        for (o in ((g = T.event && v.global) &&
          0 == T.active++ &&
          T.event.trigger("ajaxStart"),
        (v.type = v.type.toUpperCase()),
        (v.hasContent = !Wt.test(v.type)),
        (d = v.url.replace(Rt, "")),
        v.hasContent
          ? v.data &&
            v.processData &&
            0 ===
              (v.contentType || "").indexOf(
                "application/x-www-form-urlencoded"
              ) &&
            (v.data = v.data.replace(qt, "+"))
          : ((r = v.url.slice(d.length)),
            v.data &&
              (v.processData || "string" == typeof v.data) &&
              ((d += (Mt.test(d) ? "&" : "?") + v.data), delete v.data),
            !1 === v.cache &&
              ((d = d.replace(zt, "$1")),
              (r = (Mt.test(d) ? "&" : "?") + "_=" + Ot++ + r)),
            (v.url = d + r)),
        v.ifModified &&
          (T.lastModified[d] &&
            C.setRequestHeader("If-Modified-Since", T.lastModified[d]),
          T.etag[d] && C.setRequestHeader("If-None-Match", T.etag[d])),
        ((v.data && v.hasContent && !1 !== v.contentType) || t.contentType) &&
          C.setRequestHeader("Content-Type", v.contentType),
        C.setRequestHeader(
          "Accept",
          v.dataTypes[0] && v.accepts[v.dataTypes[0]]
            ? v.accepts[v.dataTypes[0]] +
                ("*" !== v.dataTypes[0] ? ", " + Gt + "; q=0.01" : "")
            : v.accepts["*"]
        ),
        v.headers))
          C.setRequestHeader(o, v.headers[o]);
        if (v.beforeSend && (!1 === v.beforeSend.call(m, C, v) || f))
          return C.abort();
        if (
          ((l = "abort"),
          b.add(v.complete),
          C.done(v.success),
          C.fail(v.error),
          (c = Zt(Ut, v, t, C)))
        ) {
          if (((C.readyState = 1), g && y.trigger("ajaxSend", [C, v]), f))
            return C;
          v.async &&
            0 < v.timeout &&
            (h = x.setTimeout(function () {
              C.abort("timeout");
            }, v.timeout));
          try {
            (f = !1), c.send(s, u);
          } catch (e) {
            if (f) throw e;
            u(-1, e);
          }
        } else u(-1, "No Transport");
        function u(e, t, n, i) {
          var o,
            r,
            s,
            a,
            l,
            u = t;
          f ||
            ((f = !0),
            h && x.clearTimeout(h),
            (c = void 0),
            (p = i || ""),
            (C.readyState = 0 < e ? 4 : 0),
            (o = (200 <= e && e < 300) || 304 === e),
            n &&
              (a = (function (e, t, n) {
                for (
                  var i, o, r, s, a = e.contents, l = e.dataTypes;
                  "*" === l[0];

                )
                  l.shift(),
                    void 0 === i &&
                      (i = e.mimeType || t.getResponseHeader("Content-Type"));
                if (i)
                  for (o in a)
                    if (a[o] && a[o].test(i)) {
                      l.unshift(o);
                      break;
                    }
                if (l[0] in n) r = l[0];
                else {
                  for (o in n) {
                    if (!l[0] || e.converters[o + " " + l[0]]) {
                      r = o;
                      break;
                    }
                    s = s || o;
                  }
                  r = r || s;
                }
                if (r) return r !== l[0] && l.unshift(r), n[r];
              })(v, C, n)),
            (a = (function (e, t, n, i) {
              var o,
                r,
                s,
                a,
                l,
                u = {},
                c = e.dataTypes.slice();
              if (c[1])
                for (s in e.converters) u[s.toLowerCase()] = e.converters[s];
              for (r = c.shift(); r; )
                if (
                  (e.responseFields[r] && (n[e.responseFields[r]] = t),
                  !l && i && e.dataFilter && (t = e.dataFilter(t, e.dataType)),
                  (l = r),
                  (r = c.shift()))
                )
                  if ("*" === r) r = l;
                  else if ("*" !== l && l !== r) {
                    if (!(s = u[l + " " + r] || u["* " + r]))
                      for (o in u)
                        if (
                          (a = o.split(" "))[1] === r &&
                          (s = u[l + " " + a[0]] || u["* " + a[0]])
                        ) {
                          !0 === s
                            ? (s = u[o])
                            : !0 !== u[o] && ((r = a[0]), c.unshift(a[1]));
                          break;
                        }
                    if (!0 !== s)
                      if (s && e.throws) t = s(t);
                      else
                        try {
                          t = s(t);
                        } catch (e) {
                          return {
                            state: "parsererror",
                            error: s
                              ? e
                              : "No conversion from " + l + " to " + r,
                          };
                        }
                  }
              return { state: "success", data: t };
            })(v, a, C, o)),
            o
              ? (v.ifModified &&
                  ((l = C.getResponseHeader("Last-Modified")) &&
                    (T.lastModified[d] = l),
                  (l = C.getResponseHeader("etag")) && (T.etag[d] = l)),
                204 === e || "HEAD" === v.type
                  ? (u = "nocontent")
                  : 304 === e
                  ? (u = "notmodified")
                  : ((u = a.state), (r = a.data), (o = !(s = a.error))))
              : ((s = u), (!e && u) || ((u = "error"), e < 0 && (e = 0))),
            (C.status = e),
            (C.statusText = (t || u) + ""),
            o ? k.resolveWith(m, [r, u, C]) : k.rejectWith(m, [C, u, s]),
            C.statusCode(w),
            (w = void 0),
            g && y.trigger(o ? "ajaxSuccess" : "ajaxError", [C, v, o ? r : s]),
            b.fireWith(m, [C, u]),
            g &&
              (y.trigger("ajaxComplete", [C, v]),
              --T.active || T.event.trigger("ajaxStop")));
        }
        return C;
      },
      getJSON: function (e, t, n) {
        return T.get(e, t, n, "json");
      },
      getScript: function (e, t) {
        return T.get(e, void 0, t, "script");
      },
    }),
    T.each(["get", "post"], function (e, o) {
      T[o] = function (e, t, n, i) {
        return (
          k(t) && ((i = i || n), (n = t), (t = void 0)),
          T.ajax(
            T.extend(
              { url: e, type: o, dataType: i, data: t, success: n },
              T.isPlainObject(e) && e
            )
          )
        );
      };
    }),
    (T._evalUrl = function (e, t) {
      return T.ajax({
        url: e,
        type: "GET",
        dataType: "script",
        cache: !0,
        async: !1,
        global: !1,
        converters: { "text script": function () {} },
        dataFilter: function (e) {
          T.globalEval(e, t);
        },
      });
    }),
    T.fn.extend({
      wrapAll: function (e) {
        var t;
        return (
          this[0] &&
            (k(e) && (e = e.call(this[0])),
            (t = T(e, this[0].ownerDocument).eq(0).clone(!0)),
            this[0].parentNode && t.insertBefore(this[0]),
            t
              .map(function () {
                for (var e = this; e.firstElementChild; )
                  e = e.firstElementChild;
                return e;
              })
              .append(this)),
          this
        );
      },
      wrapInner: function (n) {
        return k(n)
          ? this.each(function (e) {
              T(this).wrapInner(n.call(this, e));
            })
          : this.each(function () {
              var e = T(this),
                t = e.contents();
              t.length ? t.wrapAll(n) : e.append(n);
            });
      },
      wrap: function (t) {
        var n = k(t);
        return this.each(function (e) {
          T(this).wrapAll(n ? t.call(this, e) : t);
        });
      },
      unwrap: function (e) {
        return (
          this.parent(e)
            .not("body")
            .each(function () {
              T(this).replaceWith(this.childNodes);
            }),
          this
        );
      },
    }),
    (T.expr.pseudos.hidden = function (e) {
      return !T.expr.pseudos.visible(e);
    }),
    (T.expr.pseudos.visible = function (e) {
      return !!(e.offsetWidth || e.offsetHeight || e.getClientRects().length);
    }),
    (T.ajaxSettings.xhr = function () {
      try {
        return new x.XMLHttpRequest();
      } catch (e) {}
    });
  var en = { 0: 200, 1223: 204 },
    tn = T.ajaxSettings.xhr();
  (y.cors = !!tn && "withCredentials" in tn),
    (y.ajax = tn = !!tn),
    T.ajaxTransport(function (o) {
      var r, s;
      if (y.cors || (tn && !o.crossDomain))
        return {
          send: function (e, t) {
            var n,
              i = o.xhr();
            if (
              (i.open(o.type, o.url, o.async, o.username, o.password),
              o.xhrFields)
            )
              for (n in o.xhrFields) i[n] = o.xhrFields[n];
            for (n in (o.mimeType &&
              i.overrideMimeType &&
              i.overrideMimeType(o.mimeType),
            o.crossDomain ||
              e["X-Requested-With"] ||
              (e["X-Requested-With"] = "XMLHttpRequest"),
            e))
              i.setRequestHeader(n, e[n]);
            (r = function (e) {
              return function () {
                r &&
                  ((r = s = i.onload = i.onerror = i.onabort = i.ontimeout = i.onreadystatechange = null),
                  "abort" === e
                    ? i.abort()
                    : "error" === e
                    ? "number" != typeof i.status
                      ? t(0, "error")
                      : t(i.status, i.statusText)
                    : t(
                        en[i.status] || i.status,
                        i.statusText,
                        "text" !== (i.responseType || "text") ||
                          "string" != typeof i.responseText
                          ? { binary: i.response }
                          : { text: i.responseText },
                        i.getAllResponseHeaders()
                      ));
              };
            }),
              (i.onload = r()),
              (s = i.onerror = i.ontimeout = r("error")),
              void 0 !== i.onabort
                ? (i.onabort = s)
                : (i.onreadystatechange = function () {
                    4 === i.readyState &&
                      x.setTimeout(function () {
                        r && s();
                      });
                  }),
              (r = r("abort"));
            try {
              i.send((o.hasContent && o.data) || null);
            } catch (e) {
              if (r) throw e;
            }
          },
          abort: function () {
            r && r();
          },
        };
    }),
    T.ajaxPrefilter(function (e) {
      e.crossDomain && (e.contents.script = !1);
    }),
    T.ajaxSetup({
      accepts: {
        script:
          "text/javascript, application/javascript, application/ecmascript, application/x-ecmascript",
      },
      contents: { script: /\b(?:java|ecma)script\b/ },
      converters: {
        "text script": function (e) {
          return T.globalEval(e), e;
        },
      },
    }),
    T.ajaxPrefilter("script", function (e) {
      void 0 === e.cache && (e.cache = !1), e.crossDomain && (e.type = "GET");
    }),
    T.ajaxTransport("script", function (n) {
      var i, o;
      if (n.crossDomain || n.scriptAttrs)
        return {
          send: function (e, t) {
            (i = T("<script>")
              .attr(n.scriptAttrs || {})
              .prop({ charset: n.scriptCharset, src: n.url })
              .on(
                "load error",
                (o = function (e) {
                  i.remove(),
                    (o = null),
                    e && t("error" === e.type ? 404 : 200, e.type);
                })
              )),
              S.head.appendChild(i[0]);
          },
          abort: function () {
            o && o();
          },
        };
    });
  var nn,
    on = [],
    rn = /(=)\?(?=&|$)|\?\?/;
  T.ajaxSetup({
    jsonp: "callback",
    jsonpCallback: function () {
      var e = on.pop() || T.expando + "_" + Ot++;
      return (this[e] = !0), e;
    },
  }),
    T.ajaxPrefilter("json jsonp", function (e, t, n) {
      var i,
        o,
        r,
        s =
          !1 !== e.jsonp &&
          (rn.test(e.url)
            ? "url"
            : "string" == typeof e.data &&
              0 ===
                (e.contentType || "").indexOf(
                  "application/x-www-form-urlencoded"
                ) &&
              rn.test(e.data) &&
              "data");
      if (s || "jsonp" === e.dataTypes[0])
        return (
          (i = e.jsonpCallback = k(e.jsonpCallback)
            ? e.jsonpCallback()
            : e.jsonpCallback),
          s
            ? (e[s] = e[s].replace(rn, "$1" + i))
            : !1 !== e.jsonp &&
              (e.url += (Mt.test(e.url) ? "&" : "?") + e.jsonp + "=" + i),
          (e.converters["script json"] = function () {
            return r || T.error(i + " was not called"), r[0];
          }),
          (e.dataTypes[0] = "json"),
          (o = x[i]),
          (x[i] = function () {
            r = arguments;
          }),
          n.always(function () {
            void 0 === o ? T(x).removeProp(i) : (x[i] = o),
              e[i] && ((e.jsonpCallback = t.jsonpCallback), on.push(i)),
              r && k(o) && o(r[0]),
              (r = o = void 0);
          }),
          "script"
        );
    }),
    (y.createHTMLDocument =
      (((nn = S.implementation.createHTMLDocument("").body).innerHTML =
        "<form></form><form></form>"),
      2 === nn.childNodes.length)),
    (T.parseHTML = function (e, t, n) {
      return "string" != typeof e
        ? []
        : ("boolean" == typeof t && ((n = t), (t = !1)),
          t ||
            (y.createHTMLDocument
              ? (((i = (t = S.implementation.createHTMLDocument(
                  ""
                )).createElement("base")).href = S.location.href),
                t.head.appendChild(i))
              : (t = S)),
          (r = !n && []),
          (o = _.exec(e))
            ? [t.createElement(o[1])]
            : ((o = we([e], t, r)),
              r && r.length && T(r).remove(),
              T.merge([], o.childNodes)));
      var i, o, r;
    }),
    (T.fn.load = function (e, t, n) {
      var i,
        o,
        r,
        s = this,
        a = e.indexOf(" ");
      return (
        -1 < a && ((i = Et(e.slice(a))), (e = e.slice(0, a))),
        k(t)
          ? ((n = t), (t = void 0))
          : t && "object" == typeof t && (o = "POST"),
        0 < s.length &&
          T.ajax({ url: e, type: o || "GET", dataType: "html", data: t })
            .done(function (e) {
              (r = arguments),
                s.html(i ? T("<div>").append(T.parseHTML(e)).find(i) : e);
            })
            .always(
              n &&
                function (e, t) {
                  s.each(function () {
                    n.apply(this, r || [e.responseText, t, e]);
                  });
                }
            ),
        this
      );
    }),
    T.each(
      [
        "ajaxStart",
        "ajaxStop",
        "ajaxComplete",
        "ajaxError",
        "ajaxSuccess",
        "ajaxSend",
      ],
      function (e, t) {
        T.fn[t] = function (e) {
          return this.on(t, e);
        };
      }
    ),
    (T.expr.pseudos.animated = function (t) {
      return T.grep(T.timers, function (e) {
        return t === e.elem;
      }).length;
    }),
    (T.offset = {
      setOffset: function (e, t, n) {
        var i,
          o,
          r,
          s,
          a,
          l,
          u = T.css(e, "position"),
          c = T(e),
          d = {};
        "static" === u && (e.style.position = "relative"),
          (a = c.offset()),
          (r = T.css(e, "top")),
          (l = T.css(e, "left")),
          (o =
            ("absolute" === u || "fixed" === u) && -1 < (r + l).indexOf("auto")
              ? ((s = (i = c.position()).top), i.left)
              : ((s = parseFloat(r) || 0), parseFloat(l) || 0)),
          k(t) && (t = t.call(e, n, T.extend({}, a))),
          null != t.top && (d.top = t.top - a.top + s),
          null != t.left && (d.left = t.left - a.left + o),
          "using" in t ? t.using.call(e, d) : c.css(d);
      },
    }),
    T.fn.extend({
      offset: function (t) {
        if (arguments.length)
          return void 0 === t
            ? this
            : this.each(function (e) {
                T.offset.setOffset(this, t, e);
              });
        var e,
          n,
          i = this[0];
        return i
          ? i.getClientRects().length
            ? ((e = i.getBoundingClientRect()),
              (n = i.ownerDocument.defaultView),
              { top: e.top + n.pageYOffset, left: e.left + n.pageXOffset })
            : { top: 0, left: 0 }
          : void 0;
      },
      position: function () {
        if (this[0]) {
          var e,
            t,
            n,
            i = this[0],
            o = { top: 0, left: 0 };
          if ("fixed" === T.css(i, "position")) t = i.getBoundingClientRect();
          else {
            for (
              t = this.offset(),
                n = i.ownerDocument,
                e = i.offsetParent || n.documentElement;
              e &&
              (e === n.body || e === n.documentElement) &&
              "static" === T.css(e, "position");

            )
              e = e.parentNode;
            e &&
              e !== i &&
              1 === e.nodeType &&
              (((o = T(e).offset()).top += T.css(e, "borderTopWidth", !0)),
              (o.left += T.css(e, "borderLeftWidth", !0)));
          }
          return {
            top: t.top - o.top - T.css(i, "marginTop", !0),
            left: t.left - o.left - T.css(i, "marginLeft", !0),
          };
        }
      },
      offsetParent: function () {
        return this.map(function () {
          for (
            var e = this.offsetParent;
            e && "static" === T.css(e, "position");

          )
            e = e.offsetParent;
          return e || oe;
        });
      },
    }),
    T.each({ scrollLeft: "pageXOffset", scrollTop: "pageYOffset" }, function (
      t,
      o
    ) {
      var r = "pageYOffset" === o;
      T.fn[t] = function (e) {
        return z(
          this,
          function (e, t, n) {
            var i;
            if (
              (g(e) ? (i = e) : 9 === e.nodeType && (i = e.defaultView),
              void 0 === n)
            )
              return i ? i[o] : e[t];
            i
              ? i.scrollTo(r ? i.pageXOffset : n, r ? n : i.pageYOffset)
              : (e[t] = n);
          },
          t,
          e,
          arguments.length
        );
      };
    }),
    T.each(["top", "left"], function (e, n) {
      T.cssHooks[n] = Qe(y.pixelPosition, function (e, t) {
        if (t)
          return (t = Ke(e, n)), Ye.test(t) ? T(e).position()[n] + "px" : t;
      });
    }),
    T.each({ Height: "height", Width: "width" }, function (s, a) {
      T.each({ padding: "inner" + s, content: a, "": "outer" + s }, function (
        i,
        r
      ) {
        T.fn[r] = function (e, t) {
          var n = arguments.length && (i || "boolean" != typeof e),
            o = i || (!0 === e || !0 === t ? "margin" : "border");
          return z(
            this,
            function (e, t, n) {
              var i;
              return g(e)
                ? 0 === r.indexOf("outer")
                  ? e["inner" + s]
                  : e.document.documentElement["client" + s]
                : 9 === e.nodeType
                ? ((i = e.documentElement),
                  Math.max(
                    e.body["scroll" + s],
                    i["scroll" + s],
                    e.body["offset" + s],
                    i["offset" + s],
                    i["client" + s]
                  ))
                : void 0 === n
                ? T.css(e, t, o)
                : T.style(e, t, n, o);
            },
            a,
            n ? e : void 0,
            n
          );
        };
      });
    }),
    T.each(
      "blur focus focusin focusout resize scroll click dblclick mousedown mouseup mousemove mouseover mouseout mouseenter mouseleave change select submit keydown keypress keyup contextmenu".split(
        " "
      ),
      function (e, n) {
        T.fn[n] = function (e, t) {
          return 0 < arguments.length
            ? this.on(n, null, e, t)
            : this.trigger(n);
        };
      }
    ),
    T.fn.extend({
      hover: function (e, t) {
        return this.mouseenter(e).mouseleave(t || e);
      },
    }),
    T.fn.extend({
      bind: function (e, t, n) {
        return this.on(e, null, t, n);
      },
      unbind: function (e, t) {
        return this.off(e, null, t);
      },
      delegate: function (e, t, n, i) {
        return this.on(t, e, n, i);
      },
      undelegate: function (e, t, n) {
        return 1 === arguments.length
          ? this.off(e, "**")
          : this.off(t, e || "**", n);
      },
    }),
    (T.proxy = function (e, t) {
      var n, i, o;
      if (("string" == typeof t && ((n = e[t]), (t = e), (e = n)), k(e)))
        return (
          (i = a.call(arguments, 2)),
          ((o = function () {
            return e.apply(t || this, i.concat(a.call(arguments)));
          }).guid = e.guid = e.guid || T.guid++),
          o
        );
    }),
    (T.holdReady = function (e) {
      e ? T.readyWait++ : T.ready(!0);
    }),
    (T.isArray = Array.isArray),
    (T.parseJSON = JSON.parse),
    (T.nodeName = $),
    (T.isFunction = k),
    (T.isWindow = g),
    (T.camelCase = Y),
    (T.type = w),
    (T.now = Date.now),
    (T.isNumeric = function (e) {
      var t = T.type(e);
      return ("number" === t || "string" === t) && !isNaN(e - parseFloat(e));
    }),
    "function" == typeof define &&
      define.amd &&
      define("jquery", [], function () {
        return T;
      });
  var sn = x.jQuery,
    an = x.$;
  return (
    (T.noConflict = function (e) {
      return x.$ === T && (x.$ = an), e && x.jQuery === T && (x.jQuery = sn), T;
    }),
    e || (x.jQuery = x.$ = T),
    T
  );
}),
  (function (e) {
    "use strict";
    "function" == typeof define && define.amd
      ? define(["jquery"], e)
      : "undefined" != typeof exports
      ? (module.exports = e(require("jquery")))
      : e(jQuery);
  })(function (u) {
    "use strict";
    var o,
      s = window.Slick || {};
    (o = 0),
      ((s = function (e, t) {
        var n,
          i = this;
        (i.defaults = {
          accessibility: !0,
          adaptiveHeight: !1,
          appendArrows: u(e),
          appendDots: u(e),
          arrows: !0,
          asNavFor: null,
          prevArrow:
            '<button class="slick-prev" aria-label="Previous" type="button">Previous</button>',
          nextArrow:
            '<button class="slick-next" aria-label="Next" type="button">Next</button>',
          autoplay: !1,
          autoplaySpeed: 3e3,
          centerMode: !1,
          centerPadding: "50px",
          cssEase: "ease",
          customPaging: function (e, t) {
            return u('<button type="button" />').text(t + 1);
          },
          dots: !1,
          dotsClass: "slick-dots",
          draggable: !0,
          easing: "linear",
          edgeFriction: 0.35,
          fade: !1,
          focusOnSelect: !1,
          focusOnChange: !1,
          infinite: !0,
          initialSlide: 0,
          lazyLoad: "ondemand",
          mobileFirst: !1,
          pauseOnHover: !0,
          pauseOnFocus: !0,
          pauseOnDotsHover: !1,
          respondTo: "window",
          responsive: null,
          rows: 1,
          rtl: !1,
          slide: "",
          slidesPerRow: 1,
          slidesToShow: 1,
          slidesToScroll: 1,
          speed: 500,
          swipe: !0,
          swipeToSlide: !1,
          touchMove: !0,
          touchThreshold: 5,
          useCSS: !0,
          useTransform: !0,
          variableWidth: !1,
          vertical: !1,
          verticalSwiping: !1,
          waitForAnimate: !0,
          zIndex: 1e3,
        }),
          (i.initials = {
            animating: !1,
            dragging: !1,
            autoPlayTimer: null,
            currentDirection: 0,
            currentLeft: null,
            currentSlide: 0,
            direction: 1,
            $dots: null,
            listWidth: null,
            listHeight: null,
            loadIndex: 0,
            $nextArrow: null,
            $prevArrow: null,
            scrolling: !1,
            slideCount: null,
            slideWidth: null,
            $slideTrack: null,
            $slides: null,
            sliding: !1,
            slideOffset: 0,
            swipeLeft: null,
            swiping: !1,
            $list: null,
            touchObject: {},
            transformsEnabled: !1,
            unslicked: !1,
          }),
          u.extend(i, i.initials),
          (i.activeBreakpoint = null),
          (i.animType = null),
          (i.animProp = null),
          (i.breakpoints = []),
          (i.breakpointSettings = []),
          (i.cssTransitions = !1),
          (i.focussed = !1),
          (i.interrupted = !1),
          (i.hidden = "hidden"),
          (i.paused = !0),
          (i.positionProp = null),
          (i.respondTo = null),
          (i.rowCount = 1),
          (i.shouldClick = !0),
          (i.$slider = u(e)),
          (i.$slidesCache = null),
          (i.transformType = null),
          (i.transitionType = null),
          (i.visibilityChange = "visibilitychange"),
          (i.windowWidth = 0),
          (i.windowTimer = null),
          (n = u(e).data("slick") || {}),
          (i.options = u.extend({}, i.defaults, t, n)),
          (i.currentSlide = i.options.initialSlide),
          (i.originalSettings = i.options),
          void 0 !== document.mozHidden
            ? ((i.hidden = "mozHidden"),
              (i.visibilityChange = "mozvisibilitychange"))
            : void 0 !== document.webkitHidden &&
              ((i.hidden = "webkitHidden"),
              (i.visibilityChange = "webkitvisibilitychange")),
          (i.autoPlay = u.proxy(i.autoPlay, i)),
          (i.autoPlayClear = u.proxy(i.autoPlayClear, i)),
          (i.autoPlayIterator = u.proxy(i.autoPlayIterator, i)),
          (i.changeSlide = u.proxy(i.changeSlide, i)),
          (i.clickHandler = u.proxy(i.clickHandler, i)),
          (i.selectHandler = u.proxy(i.selectHandler, i)),
          (i.setPosition = u.proxy(i.setPosition, i)),
          (i.swipeHandler = u.proxy(i.swipeHandler, i)),
          (i.dragHandler = u.proxy(i.dragHandler, i)),
          (i.keyHandler = u.proxy(i.keyHandler, i)),
          (i.instanceUid = o++),
          (i.htmlExpr = /^(?:\s*(<[\w\W]+>)[^>]*)$/),
          i.registerBreakpoints(),
          i.init(!0);
      }).prototype.activateADA = function () {
        this.$slideTrack
          .find(".slick-active")
          .attr({ "aria-hidden": "false" })
          .find("a, input, button, select")
          .attr({ tabindex: "0" });
      }),
      (s.prototype.addSlide = s.prototype.slickAdd = function (e, t, n) {
        var i = this;
        if ("boolean" == typeof t) (n = t), (t = null);
        else if (t < 0 || t >= i.slideCount) return !1;
        i.unload(),
          "number" == typeof t
            ? 0 === t && 0 === i.$slides.length
              ? u(e).appendTo(i.$slideTrack)
              : n
              ? u(e).insertBefore(i.$slides.eq(t))
              : u(e).insertAfter(i.$slides.eq(t))
            : !0 === n
            ? u(e).prependTo(i.$slideTrack)
            : u(e).appendTo(i.$slideTrack),
          (i.$slides = i.$slideTrack.children(this.options.slide)),
          i.$slideTrack.children(this.options.slide).detach(),
          i.$slideTrack.append(i.$slides),
          i.$slides.each(function (e, t) {
            u(t).attr("data-slick-index", e);
          }),
          (i.$slidesCache = i.$slides),
          i.reinit();
      }),
      (s.prototype.animateHeight = function () {
        var e = this;
        if (
          1 === e.options.slidesToShow &&
          !0 === e.options.adaptiveHeight &&
          !1 === e.options.vertical
        ) {
          var t = e.$slides.eq(e.currentSlide).outerHeight(!0);
          e.$list.animate({ height: t }, e.options.speed);
        }
      }),
      (s.prototype.animateSlide = function (e, t) {
        var n = {},
          i = this;
        i.animateHeight(),
          !0 === i.options.rtl && !1 === i.options.vertical && (e = -e),
          !1 === i.transformsEnabled
            ? !1 === i.options.vertical
              ? i.$slideTrack.animate(
                  { left: e },
                  i.options.speed,
                  i.options.easing,
                  t
                )
              : i.$slideTrack.animate(
                  { top: e },
                  i.options.speed,
                  i.options.easing,
                  t
                )
            : !1 === i.cssTransitions
            ? (!0 === i.options.rtl && (i.currentLeft = -i.currentLeft),
              u({ animStart: i.currentLeft }).animate(
                { animStart: e },
                {
                  duration: i.options.speed,
                  easing: i.options.easing,
                  step: function (e) {
                    (e = Math.ceil(e)),
                      !1 === i.options.vertical
                        ? (n[i.animType] = "translate(" + e + "px, 0px)")
                        : (n[i.animType] = "translate(0px," + e + "px)"),
                      i.$slideTrack.css(n);
                  },
                  complete: function () {
                    t && t.call();
                  },
                }
              ))
            : (i.applyTransition(),
              (e = Math.ceil(e)),
              !1 === i.options.vertical
                ? (n[i.animType] = "translate3d(" + e + "px, 0px, 0px)")
                : (n[i.animType] = "translate3d(0px," + e + "px, 0px)"),
              i.$slideTrack.css(n),
              t &&
                setTimeout(function () {
                  i.disableTransition(), t.call();
                }, i.options.speed));
      }),
      (s.prototype.getNavTarget = function () {
        var e = this.options.asNavFor;
        return e && null !== e && (e = u(e).not(this.$slider)), e;
      }),
      (s.prototype.asNavFor = function (t) {
        var e = this.getNavTarget();
        null !== e &&
          "object" == typeof e &&
          e.each(function () {
            var e = u(this).slick("getSlick");
            e.unslicked || e.slideHandler(t, !0);
          });
      }),
      (s.prototype.applyTransition = function (e) {
        var t = this,
          n = {};
        !1 === t.options.fade
          ? (n[t.transitionType] =
              t.transformType +
              " " +
              t.options.speed +
              "ms " +
              t.options.cssEase)
          : (n[t.transitionType] =
              "opacity " + t.options.speed + "ms " + t.options.cssEase),
          !1 === t.options.fade ? t.$slideTrack.css(n) : t.$slides.eq(e).css(n);
      }),
      (s.prototype.autoPlay = function () {
        var e = this;
        e.autoPlayClear(),
          e.slideCount > e.options.slidesToShow &&
            (e.autoPlayTimer = setInterval(
              e.autoPlayIterator,
              e.options.autoplaySpeed
            ));
      }),
      (s.prototype.autoPlayClear = function () {
        this.autoPlayTimer && clearInterval(this.autoPlayTimer);
      }),
      (s.prototype.autoPlayIterator = function () {
        var e = this,
          t = e.currentSlide + e.options.slidesToScroll;
        e.paused ||
          e.interrupted ||
          e.focussed ||
          (!1 === e.options.infinite &&
            (1 === e.direction && e.currentSlide + 1 === e.slideCount - 1
              ? (e.direction = 0)
              : 0 === e.direction &&
                ((t = e.currentSlide - e.options.slidesToScroll),
                e.currentSlide - 1 == 0 && (e.direction = 1))),
          e.slideHandler(t));
      }),
      (s.prototype.buildArrows = function () {
        var e = this;
        !0 === e.options.arrows &&
          ((e.$prevArrow = u(e.options.prevArrow).addClass("slick-arrow")),
          (e.$nextArrow = u(e.options.nextArrow).addClass("slick-arrow")),
          e.slideCount > e.options.slidesToShow
            ? (e.$prevArrow
                .removeClass("slick-hidden")
                .removeAttr("aria-hidden tabindex"),
              e.$nextArrow
                .removeClass("slick-hidden")
                .removeAttr("aria-hidden tabindex"),
              e.htmlExpr.test(e.options.prevArrow) &&
                e.$prevArrow.prependTo(e.options.appendArrows),
              e.htmlExpr.test(e.options.nextArrow) &&
                e.$nextArrow.appendTo(e.options.appendArrows),
              !0 !== e.options.infinite &&
                e.$prevArrow
                  .addClass("slick-disabled")
                  .attr("aria-disabled", "true"))
            : e.$prevArrow
                .add(e.$nextArrow)
                .addClass("slick-hidden")
                .attr({ "aria-disabled": "true", tabindex: "-1" }));
      }),
      (s.prototype.buildDots = function () {
        var e,
          t,
          n = this;
        if (!0 === n.options.dots) {
          for (
            n.$slider.addClass("slick-dotted"),
              t = u("<ul />").addClass(n.options.dotsClass),
              e = 0;
            e <= n.getDotCount();
            e += 1
          )
            t.append(
              u("<li />").append(n.options.customPaging.call(this, n, e))
            );
          (n.$dots = t.appendTo(n.options.appendDots)),
            n.$dots.find("li").first().addClass("slick-active");
        }
      }),
      (s.prototype.buildOut = function () {
        var e = this;
        (e.$slides = e.$slider
          .children(e.options.slide + ":not(.slick-cloned)")
          .addClass("slick-slide")),
          (e.slideCount = e.$slides.length),
          e.$slides.each(function (e, t) {
            u(t)
              .attr("data-slick-index", e)
              .data("originalStyling", u(t).attr("style") || "");
          }),
          e.$slider.addClass("slick-slider"),
          (e.$slideTrack =
            0 === e.slideCount
              ? u('<div class="slick-track"/>').appendTo(e.$slider)
              : e.$slides.wrapAll('<div class="slick-track"/>').parent()),
          (e.$list = e.$slideTrack.wrap('<div class="slick-list"/>').parent()),
          e.$slideTrack.css("opacity", 0),
          (!0 !== e.options.centerMode && !0 !== e.options.swipeToSlide) ||
            (e.options.slidesToScroll = 1),
          u("img[data-lazy]", e.$slider).not("[src]").addClass("slick-loading"),
          e.setupInfinite(),
          e.buildArrows(),
          e.buildDots(),
          e.updateDots(),
          e.setSlideClasses(
            "number" == typeof e.currentSlide ? e.currentSlide : 0
          ),
          !0 === e.options.draggable && e.$list.addClass("draggable");
      }),
      (s.prototype.buildRows = function () {
        var e,
          t,
          n,
          i,
          o,
          r,
          s,
          a = this;
        if (
          ((i = document.createDocumentFragment()),
          (r = a.$slider.children()),
          1 < a.options.rows)
        ) {
          for (
            s = a.options.slidesPerRow * a.options.rows,
              o = Math.ceil(r.length / s),
              e = 0;
            e < o;
            e++
          ) {
            var l = document.createElement("div");
            for (t = 0; t < a.options.rows; t++) {
              var u = document.createElement("div");
              for (n = 0; n < a.options.slidesPerRow; n++) {
                var c = e * s + (t * a.options.slidesPerRow + n);
                r.get(c) && u.appendChild(r.get(c));
              }
              l.appendChild(u);
            }
            i.appendChild(l);
          }
          a.$slider.empty().append(i),
            a.$slider
              .children()
              .children()
              .children()
              .css({
                width: 100 / a.options.slidesPerRow + "%",
                display: "inline-block",
              });
        }
      }),
      (s.prototype.checkResponsive = function (e, t) {
        var n,
          i,
          o,
          r = this,
          s = !1,
          a = r.$slider.width(),
          l = window.innerWidth || u(window).width();
        if (
          ("window" === r.respondTo
            ? (o = l)
            : "slider" === r.respondTo
            ? (o = a)
            : "min" === r.respondTo && (o = Math.min(l, a)),
          r.options.responsive &&
            r.options.responsive.length &&
            null !== r.options.responsive)
        ) {
          for (n in ((i = null), r.breakpoints))
            r.breakpoints.hasOwnProperty(n) &&
              (!1 === r.originalSettings.mobileFirst
                ? o < r.breakpoints[n] && (i = r.breakpoints[n])
                : o > r.breakpoints[n] && (i = r.breakpoints[n]));
          null !== i
            ? (null !== r.activeBreakpoint && i === r.activeBreakpoint && !t) ||
              ((r.activeBreakpoint = i),
              "unslick" === r.breakpointSettings[i]
                ? r.unslick(i)
                : ((r.options = u.extend(
                    {},
                    r.originalSettings,
                    r.breakpointSettings[i]
                  )),
                  !0 === e && (r.currentSlide = r.options.initialSlide),
                  r.refresh(e)),
              (s = i))
            : null !== r.activeBreakpoint &&
              ((r.activeBreakpoint = null),
              (r.options = r.originalSettings),
              !0 === e && (r.currentSlide = r.options.initialSlide),
              r.refresh(e),
              (s = i)),
            e || !1 === s || r.$slider.trigger("breakpoint", [r, s]);
        }
      }),
      (s.prototype.changeSlide = function (e, t) {
        var n,
          i,
          o = this,
          r = u(e.currentTarget);
        switch (
          (r.is("a") && e.preventDefault(),
          r.is("li") || (r = r.closest("li")),
          (n =
            o.slideCount % o.options.slidesToScroll != 0
              ? 0
              : (o.slideCount - o.currentSlide) % o.options.slidesToScroll),
          e.data.message)
        ) {
          case "previous":
            (i =
              0 == n ? o.options.slidesToScroll : o.options.slidesToShow - n),
              o.slideCount > o.options.slidesToShow &&
                o.slideHandler(o.currentSlide - i, !1, t);
            break;
          case "next":
            (i = 0 == n ? o.options.slidesToScroll : n),
              o.slideCount > o.options.slidesToShow &&
                o.slideHandler(o.currentSlide + i, !1, t);
            break;
          case "index":
            var s =
              0 === e.data.index
                ? 0
                : e.data.index || r.index() * o.options.slidesToScroll;
            o.slideHandler(o.checkNavigable(s), !1, t),
              r.children().trigger("focus");
            break;
          default:
            return;
        }
      }),
      (s.prototype.checkNavigable = function (e) {
        var t, n;
        if (((n = 0), e > (t = this.getNavigableIndexes())[t.length - 1]))
          e = t[t.length - 1];
        else
          for (var i in t) {
            if (e < t[i]) {
              e = n;
              break;
            }
            n = t[i];
          }
        return e;
      }),
      (s.prototype.cleanUpEvents = function () {
        var e = this;
        e.options.dots &&
          null !== e.$dots &&
          (u("li", e.$dots)
            .off("click.slick", e.changeSlide)
            .off("mouseenter.slick", u.proxy(e.interrupt, e, !0))
            .off("mouseleave.slick", u.proxy(e.interrupt, e, !1)),
          !0 === e.options.accessibility &&
            e.$dots.off("keydown.slick", e.keyHandler)),
          e.$slider.off("focus.slick blur.slick"),
          !0 === e.options.arrows &&
            e.slideCount > e.options.slidesToShow &&
            (e.$prevArrow && e.$prevArrow.off("click.slick", e.changeSlide),
            e.$nextArrow && e.$nextArrow.off("click.slick", e.changeSlide),
            !0 === e.options.accessibility &&
              (e.$prevArrow && e.$prevArrow.off("keydown.slick", e.keyHandler),
              e.$nextArrow && e.$nextArrow.off("keydown.slick", e.keyHandler))),
          e.$list.off("touchstart.slick mousedown.slick", e.swipeHandler),
          e.$list.off("touchmove.slick mousemove.slick", e.swipeHandler),
          e.$list.off("touchend.slick mouseup.slick", e.swipeHandler),
          e.$list.off("touchcancel.slick mouseleave.slick", e.swipeHandler),
          e.$list.off("click.slick", e.clickHandler),
          u(document).off(e.visibilityChange, e.visibility),
          e.cleanUpSlideEvents(),
          !0 === e.options.accessibility &&
            e.$list.off("keydown.slick", e.keyHandler),
          !0 === e.options.focusOnSelect &&
            u(e.$slideTrack).children().off("click.slick", e.selectHandler),
          u(window).off(
            "orientationchange.slick.slick-" + e.instanceUid,
            e.orientationChange
          ),
          u(window).off("resize.slick.slick-" + e.instanceUid, e.resize),
          u("[draggable!=true]", e.$slideTrack).off(
            "dragstart",
            e.preventDefault
          ),
          u(window).off("load.slick.slick-" + e.instanceUid, e.setPosition);
      }),
      (s.prototype.cleanUpSlideEvents = function () {
        var e = this;
        e.$list.off("mouseenter.slick", u.proxy(e.interrupt, e, !0)),
          e.$list.off("mouseleave.slick", u.proxy(e.interrupt, e, !1));
      }),
      (s.prototype.cleanUpRows = function () {
        var e;
        1 < this.options.rows &&
          ((e = this.$slides.children().children()).removeAttr("style"),
          this.$slider.empty().append(e));
      }),
      (s.prototype.clickHandler = function (e) {
        !1 === this.shouldClick &&
          (e.stopImmediatePropagation(),
          e.stopPropagation(),
          e.preventDefault());
      }),
      (s.prototype.destroy = function (e) {
        var t = this;
        t.autoPlayClear(),
          (t.touchObject = {}),
          t.cleanUpEvents(),
          u(".slick-cloned", t.$slider).detach(),
          t.$dots && t.$dots.remove(),
          t.$prevArrow &&
            t.$prevArrow.length &&
            (t.$prevArrow
              .removeClass("slick-disabled slick-arrow slick-hidden")
              .removeAttr("aria-hidden aria-disabled tabindex")
              .css("display", ""),
            t.htmlExpr.test(t.options.prevArrow) && t.$prevArrow.remove()),
          t.$nextArrow &&
            t.$nextArrow.length &&
            (t.$nextArrow
              .removeClass("slick-disabled slick-arrow slick-hidden")
              .removeAttr("aria-hidden aria-disabled tabindex")
              .css("display", ""),
            t.htmlExpr.test(t.options.nextArrow) && t.$nextArrow.remove()),
          t.$slides &&
            (t.$slides
              .removeClass(
                "slick-slide slick-active slick-center slick-visible slick-current"
              )
              .removeAttr("aria-hidden")
              .removeAttr("data-slick-index")
              .each(function () {
                u(this).attr("style", u(this).data("originalStyling"));
              }),
            t.$slideTrack.children(this.options.slide).detach(),
            t.$slideTrack.detach(),
            t.$list.detach(),
            t.$slider.append(t.$slides)),
          t.cleanUpRows(),
          t.$slider.removeClass("slick-slider"),
          t.$slider.removeClass("slick-initialized"),
          t.$slider.removeClass("slick-dotted"),
          (t.unslicked = !0),
          e || t.$slider.trigger("destroy", [t]);
      }),
      (s.prototype.disableTransition = function (e) {
        var t = {};
        (t[this.transitionType] = ""),
          !1 === this.options.fade
            ? this.$slideTrack.css(t)
            : this.$slides.eq(e).css(t);
      }),
      (s.prototype.fadeSlide = function (e, t) {
        var n = this;
        !1 === n.cssTransitions
          ? (n.$slides.eq(e).css({ zIndex: n.options.zIndex }),
            n.$slides
              .eq(e)
              .animate({ opacity: 1 }, n.options.speed, n.options.easing, t))
          : (n.applyTransition(e),
            n.$slides.eq(e).css({ opacity: 1, zIndex: n.options.zIndex }),
            t &&
              setTimeout(function () {
                n.disableTransition(e), t.call();
              }, n.options.speed));
      }),
      (s.prototype.fadeSlideOut = function (e) {
        var t = this;
        !1 === t.cssTransitions
          ? t.$slides
              .eq(e)
              .animate(
                { opacity: 0, zIndex: t.options.zIndex - 2 },
                t.options.speed,
                t.options.easing
              )
          : (t.applyTransition(e),
            t.$slides.eq(e).css({ opacity: 0, zIndex: t.options.zIndex - 2 }));
      }),
      (s.prototype.filterSlides = s.prototype.slickFilter = function (e) {
        var t = this;
        null !== e &&
          ((t.$slidesCache = t.$slides),
          t.unload(),
          t.$slideTrack.children(this.options.slide).detach(),
          t.$slidesCache.filter(e).appendTo(t.$slideTrack),
          t.reinit());
      }),
      (s.prototype.focusHandler = function () {
        var n = this;
        n.$slider
          .off("focus.slick blur.slick")
          .on("focus.slick blur.slick", "*", function (e) {
            e.stopImmediatePropagation();
            var t = u(this);
            setTimeout(function () {
              n.options.pauseOnFocus &&
                ((n.focussed = t.is(":focus")), n.autoPlay());
            }, 0);
          });
      }),
      (s.prototype.getCurrent = s.prototype.slickCurrentSlide = function () {
        return this.currentSlide;
      }),
      (s.prototype.getDotCount = function () {
        var e = this,
          t = 0,
          n = 0,
          i = 0;
        if (!0 === e.options.infinite)
          if (e.slideCount <= e.options.slidesToShow) ++i;
          else
            for (; t < e.slideCount; )
              ++i,
                (t = n + e.options.slidesToScroll),
                (n +=
                  e.options.slidesToScroll <= e.options.slidesToShow
                    ? e.options.slidesToScroll
                    : e.options.slidesToShow);
        else if (!0 === e.options.centerMode) i = e.slideCount;
        else if (e.options.asNavFor)
          for (; t < e.slideCount; )
            ++i,
              (t = n + e.options.slidesToScroll),
              (n +=
                e.options.slidesToScroll <= e.options.slidesToShow
                  ? e.options.slidesToScroll
                  : e.options.slidesToShow);
        else
          i =
            1 +
            Math.ceil(
              (e.slideCount - e.options.slidesToShow) / e.options.slidesToScroll
            );
        return i - 1;
      }),
      (s.prototype.getLeft = function (e) {
        var t,
          n,
          i,
          o,
          r = this,
          s = 0;
        return (
          (r.slideOffset = 0),
          (n = r.$slides.first().outerHeight(!0)),
          !0 === r.options.infinite
            ? (r.slideCount > r.options.slidesToShow &&
                ((r.slideOffset = r.slideWidth * r.options.slidesToShow * -1),
                (o = -1),
                !0 === r.options.vertical &&
                  !0 === r.options.centerMode &&
                  (2 === r.options.slidesToShow
                    ? (o = -1.5)
                    : 1 === r.options.slidesToShow && (o = -2)),
                (s = n * r.options.slidesToShow * o)),
              r.slideCount % r.options.slidesToScroll != 0 &&
                e + r.options.slidesToScroll > r.slideCount &&
                r.slideCount > r.options.slidesToShow &&
                (s =
                  e > r.slideCount
                    ? ((r.slideOffset =
                        (r.options.slidesToShow - (e - r.slideCount)) *
                        r.slideWidth *
                        -1),
                      (r.options.slidesToShow - (e - r.slideCount)) * n * -1)
                    : ((r.slideOffset =
                        (r.slideCount % r.options.slidesToScroll) *
                        r.slideWidth *
                        -1),
                      (r.slideCount % r.options.slidesToScroll) * n * -1)))
            : e + r.options.slidesToShow > r.slideCount &&
              ((r.slideOffset =
                (e + r.options.slidesToShow - r.slideCount) * r.slideWidth),
              (s = (e + r.options.slidesToShow - r.slideCount) * n)),
          r.slideCount <= r.options.slidesToShow && (s = r.slideOffset = 0),
          !0 === r.options.centerMode && r.slideCount <= r.options.slidesToShow
            ? (r.slideOffset =
                (r.slideWidth * Math.floor(r.options.slidesToShow)) / 2 -
                (r.slideWidth * r.slideCount) / 2)
            : !0 === r.options.centerMode && !0 === r.options.infinite
            ? (r.slideOffset +=
                r.slideWidth * Math.floor(r.options.slidesToShow / 2) -
                r.slideWidth)
            : !0 === r.options.centerMode &&
              ((r.slideOffset = 0),
              (r.slideOffset +=
                r.slideWidth * Math.floor(r.options.slidesToShow / 2))),
          (t =
            !1 === r.options.vertical
              ? e * r.slideWidth * -1 + r.slideOffset
              : e * n * -1 + s),
          !0 === r.options.variableWidth &&
            ((i =
              r.slideCount <= r.options.slidesToShow ||
              !1 === r.options.infinite
                ? r.$slideTrack.children(".slick-slide").eq(e)
                : r.$slideTrack
                    .children(".slick-slide")
                    .eq(e + r.options.slidesToShow)),
            (t =
              !0 === r.options.rtl
                ? i[0]
                  ? -1 * (r.$slideTrack.width() - i[0].offsetLeft - i.width())
                  : 0
                : i[0]
                ? -1 * i[0].offsetLeft
                : 0),
            !0 === r.options.centerMode &&
              ((i =
                r.slideCount <= r.options.slidesToShow ||
                !1 === r.options.infinite
                  ? r.$slideTrack.children(".slick-slide").eq(e)
                  : r.$slideTrack
                      .children(".slick-slide")
                      .eq(e + r.options.slidesToShow + 1)),
              (t =
                !0 === r.options.rtl
                  ? i[0]
                    ? -1 * (r.$slideTrack.width() - i[0].offsetLeft - i.width())
                    : 0
                  : i[0]
                  ? -1 * i[0].offsetLeft
                  : 0),
              (t += (r.$list.width() - i.outerWidth()) / 2))),
          t
        );
      }),
      (s.prototype.getOption = s.prototype.slickGetOption = function (e) {
        return this.options[e];
      }),
      (s.prototype.getNavigableIndexes = function () {
        var e,
          t = this,
          n = 0,
          i = 0,
          o = [];
        for (
          e =
            !1 === t.options.infinite
              ? t.slideCount
              : ((n = -1 * t.options.slidesToScroll),
                (i = -1 * t.options.slidesToScroll),
                2 * t.slideCount);
          n < e;

        )
          o.push(n),
            (n = i + t.options.slidesToScroll),
            (i +=
              t.options.slidesToScroll <= t.options.slidesToShow
                ? t.options.slidesToScroll
                : t.options.slidesToShow);
        return o;
      }),
      (s.prototype.getSlick = function () {
        return this;
      }),
      (s.prototype.getSlideCount = function () {
        var n,
          i,
          o = this;
        return (
          (i =
            !0 === o.options.centerMode
              ? o.slideWidth * Math.floor(o.options.slidesToShow / 2)
              : 0),
          !0 === o.options.swipeToSlide
            ? (o.$slideTrack.find(".slick-slide").each(function (e, t) {
                if (t.offsetLeft - i + u(t).outerWidth() / 2 > -1 * o.swipeLeft)
                  return (n = t), !1;
              }),
              Math.abs(u(n).attr("data-slick-index") - o.currentSlide) || 1)
            : o.options.slidesToScroll
        );
      }),
      (s.prototype.goTo = s.prototype.slickGoTo = function (e, t) {
        this.changeSlide({ data: { message: "index", index: parseInt(e) } }, t);
      }),
      (s.prototype.init = function (e) {
        var t = this;
        u(t.$slider).hasClass("slick-initialized") ||
          (u(t.$slider).addClass("slick-initialized"),
          t.buildRows(),
          t.buildOut(),
          t.setProps(),
          t.startLoad(),
          t.loadSlider(),
          t.initializeEvents(),
          t.updateArrows(),
          t.updateDots(),
          t.checkResponsive(!0),
          t.focusHandler()),
          e && t.$slider.trigger("init", [t]),
          !0 === t.options.accessibility && t.initADA(),
          t.options.autoplay && ((t.paused = !1), t.autoPlay());
      }),
      (s.prototype.initADA = function () {
        var n = this,
          i = Math.ceil(n.slideCount / n.options.slidesToShow),
          o = n.getNavigableIndexes().filter(function (e) {
            return 0 <= e && e < n.slideCount;
          });
        n.$slides
          .add(n.$slideTrack.find(".slick-cloned"))
          .attr({ "aria-hidden": "true", tabindex: "-1" })
          .find("a, input, button, select")
          .attr({ tabindex: "-1" }),
          null !== n.$dots &&
            (n.$slides
              .not(n.$slideTrack.find(".slick-cloned"))
              .each(function (e) {
                var t = o.indexOf(e);
                u(this).attr({
                  role: "tabpanel",
                  id: "slick-slide" + n.instanceUid + e,
                  tabindex: -1,
                }),
                  -1 !== t &&
                    u(this).attr({
                      "aria-describedby":
                        "slick-slide-control" + n.instanceUid + t,
                    });
              }),
            n.$dots
              .attr("role", "tablist")
              .find("li")
              .each(function (e) {
                var t = o[e];
                u(this).attr({ role: "presentation" }),
                  u(this)
                    .find("button")
                    .first()
                    .attr({
                      role: "tab",
                      id: "slick-slide-control" + n.instanceUid + e,
                      "aria-controls": "slick-slide" + n.instanceUid + t,
                      "aria-label": e + 1 + " of " + i,
                      "aria-selected": null,
                      tabindex: "-1",
                    });
              })
              .eq(n.currentSlide)
              .find("button")
              .attr({ "aria-selected": "true", tabindex: "0" })
              .end());
        for (var e = n.currentSlide, t = e + n.options.slidesToShow; e < t; e++)
          n.$slides.eq(e).attr("tabindex", 0);
        n.activateADA();
      }),
      (s.prototype.initArrowEvents = function () {
        var e = this;
        !0 === e.options.arrows &&
          e.slideCount > e.options.slidesToShow &&
          (e.$prevArrow
            .off("click.slick")
            .on("click.slick", { message: "previous" }, e.changeSlide),
          e.$nextArrow
            .off("click.slick")
            .on("click.slick", { message: "next" }, e.changeSlide),
          !0 === e.options.accessibility &&
            (e.$prevArrow.on("keydown.slick", e.keyHandler),
            e.$nextArrow.on("keydown.slick", e.keyHandler)));
      }),
      (s.prototype.initDotEvents = function () {
        var e = this;
        !0 === e.options.dots &&
          (u("li", e.$dots).on(
            "click.slick",
            { message: "index" },
            e.changeSlide
          ),
          !0 === e.options.accessibility &&
            e.$dots.on("keydown.slick", e.keyHandler)),
          !0 === e.options.dots &&
            !0 === e.options.pauseOnDotsHover &&
            u("li", e.$dots)
              .on("mouseenter.slick", u.proxy(e.interrupt, e, !0))
              .on("mouseleave.slick", u.proxy(e.interrupt, e, !1));
      }),
      (s.prototype.initSlideEvents = function () {
        var e = this;
        e.options.pauseOnHover &&
          (e.$list.on("mouseenter.slick", u.proxy(e.interrupt, e, !0)),
          e.$list.on("mouseleave.slick", u.proxy(e.interrupt, e, !1)));
      }),
      (s.prototype.initializeEvents = function () {
        var e = this;
        e.initArrowEvents(),
          e.initDotEvents(),
          e.initSlideEvents(),
          e.$list.on(
            "touchstart.slick mousedown.slick",
            { action: "start" },
            e.swipeHandler
          ),
          e.$list.on(
            "touchmove.slick mousemove.slick",
            { action: "move" },
            e.swipeHandler
          ),
          e.$list.on(
            "touchend.slick mouseup.slick",
            { action: "end" },
            e.swipeHandler
          ),
          e.$list.on(
            "touchcancel.slick mouseleave.slick",
            { action: "end" },
            e.swipeHandler
          ),
          e.$list.on("click.slick", e.clickHandler),
          u(document).on(e.visibilityChange, u.proxy(e.visibility, e)),
          !0 === e.options.accessibility &&
            e.$list.on("keydown.slick", e.keyHandler),
          !0 === e.options.focusOnSelect &&
            u(e.$slideTrack).children().on("click.slick", e.selectHandler),
          u(window).on(
            "orientationchange.slick.slick-" + e.instanceUid,
            u.proxy(e.orientationChange, e)
          ),
          u(window).on(
            "resize.slick.slick-" + e.instanceUid,
            u.proxy(e.resize, e)
          ),
          u("[draggable!=true]", e.$slideTrack).on(
            "dragstart",
            e.preventDefault
          ),
          u(window).on("load.slick.slick-" + e.instanceUid, e.setPosition),
          u(e.setPosition);
      }),
      (s.prototype.initUI = function () {
        var e = this;
        !0 === e.options.arrows &&
          e.slideCount > e.options.slidesToShow &&
          (e.$prevArrow.show(), e.$nextArrow.show()),
          !0 === e.options.dots &&
            e.slideCount > e.options.slidesToShow &&
            e.$dots.show();
      }),
      (s.prototype.keyHandler = function (e) {
        var t = this;
        e.target.tagName.match("TEXTAREA|INPUT|SELECT") ||
          (37 === e.keyCode && !0 === t.options.accessibility
            ? t.changeSlide({
                data: { message: !0 === t.options.rtl ? "next" : "previous" },
              })
            : 39 === e.keyCode &&
              !0 === t.options.accessibility &&
              t.changeSlide({
                data: { message: !0 === t.options.rtl ? "previous" : "next" },
              }));
      }),
      (s.prototype.lazyLoad = function () {
        function e(e) {
          u("img[data-lazy]", e).each(function () {
            var e = u(this),
              t = u(this).attr("data-lazy"),
              n = u(this).attr("data-srcset"),
              i = u(this).attr("data-sizes") || r.$slider.attr("data-sizes"),
              o = document.createElement("img");
            (o.onload = function () {
              e.animate({ opacity: 0 }, 100, function () {
                n && (e.attr("srcset", n), i && e.attr("sizes", i)),
                  e.attr("src", t).animate({ opacity: 1 }, 200, function () {
                    e.removeAttr(
                      "data-lazy data-srcset data-sizes"
                    ).removeClass("slick-loading");
                  }),
                  r.$slider.trigger("lazyLoaded", [r, e, t]);
              });
            }),
              (o.onerror = function () {
                e
                  .removeAttr("data-lazy")
                  .removeClass("slick-loading")
                  .addClass("slick-lazyload-error"),
                  r.$slider.trigger("lazyLoadError", [r, e, t]);
              }),
              (o.src = t);
          });
        }
        var t,
          n,
          i,
          r = this;
        if (
          (!0 === r.options.centerMode
            ? (i =
                !0 === r.options.infinite
                  ? (n = r.currentSlide + (r.options.slidesToShow / 2 + 1)) +
                    r.options.slidesToShow +
                    2
                  : ((n = Math.max(
                      0,
                      r.currentSlide - (r.options.slidesToShow / 2 + 1)
                    )),
                    r.options.slidesToShow / 2 + 1 + 2 + r.currentSlide))
            : ((n = r.options.infinite
                ? r.options.slidesToShow + r.currentSlide
                : r.currentSlide),
              (i = Math.ceil(n + r.options.slidesToShow)),
              !0 === r.options.fade &&
                (0 < n && n--, i <= r.slideCount && i++)),
          (t = r.$slider.find(".slick-slide").slice(n, i)),
          "anticipated" === r.options.lazyLoad)
        )
          for (
            var o = n - 1, s = i, a = r.$slider.find(".slick-slide"), l = 0;
            l < r.options.slidesToScroll;
            l++
          )
            o < 0 && (o = r.slideCount - 1),
              (t = (t = t.add(a.eq(o))).add(a.eq(s))),
              o--,
              s++;
        e(t),
          r.slideCount <= r.options.slidesToShow
            ? e(r.$slider.find(".slick-slide"))
            : r.currentSlide >= r.slideCount - r.options.slidesToShow
            ? e(
                r.$slider.find(".slick-cloned").slice(0, r.options.slidesToShow)
              )
            : 0 === r.currentSlide &&
              e(
                r.$slider
                  .find(".slick-cloned")
                  .slice(-1 * r.options.slidesToShow)
              );
      }),
      (s.prototype.loadSlider = function () {
        var e = this;
        e.setPosition(),
          e.$slideTrack.css({ opacity: 1 }),
          e.$slider.removeClass("slick-loading"),
          e.initUI(),
          "progressive" === e.options.lazyLoad && e.progressiveLazyLoad();
      }),
      (s.prototype.next = s.prototype.slickNext = function () {
        this.changeSlide({ data: { message: "next" } });
      }),
      (s.prototype.orientationChange = function () {
        this.checkResponsive(), this.setPosition();
      }),
      (s.prototype.pause = s.prototype.slickPause = function () {
        this.autoPlayClear(), (this.paused = !0);
      }),
      (s.prototype.play = s.prototype.slickPlay = function () {
        var e = this;
        e.autoPlay(),
          (e.options.autoplay = !0),
          (e.paused = !1),
          (e.focussed = !1),
          (e.interrupted = !1);
      }),
      (s.prototype.postSlide = function (e) {
        var t = this;
        t.unslicked ||
          (t.$slider.trigger("afterChange", [t, e]),
          (t.animating = !1),
          t.slideCount > t.options.slidesToShow && t.setPosition(),
          (t.swipeLeft = null),
          t.options.autoplay && t.autoPlay(),
          !0 === t.options.accessibility &&
            (t.initADA(),
            t.options.focusOnChange &&
              u(t.$slides.get(t.currentSlide)).attr("tabindex", 0).focus()));
      }),
      (s.prototype.prev = s.prototype.slickPrev = function () {
        this.changeSlide({ data: { message: "previous" } });
      }),
      (s.prototype.preventDefault = function (e) {
        e.preventDefault();
      }),
      (s.prototype.progressiveLazyLoad = function (e) {
        e = e || 1;
        var t,
          n,
          i,
          o,
          r,
          s = this,
          a = u("img[data-lazy]", s.$slider);
        a.length
          ? ((t = a.first()),
            (n = t.attr("data-lazy")),
            (i = t.attr("data-srcset")),
            (o = t.attr("data-sizes") || s.$slider.attr("data-sizes")),
            ((r = document.createElement("img")).onload = function () {
              i && (t.attr("srcset", i), o && t.attr("sizes", o)),
                t
                  .attr("src", n)
                  .removeAttr("data-lazy data-srcset data-sizes")
                  .removeClass("slick-loading"),
                !0 === s.options.adaptiveHeight && s.setPosition(),
                s.$slider.trigger("lazyLoaded", [s, t, n]),
                s.progressiveLazyLoad();
            }),
            (r.onerror = function () {
              e < 3
                ? setTimeout(function () {
                    s.progressiveLazyLoad(e + 1);
                  }, 500)
                : (t
                    .removeAttr("data-lazy")
                    .removeClass("slick-loading")
                    .addClass("slick-lazyload-error"),
                  s.$slider.trigger("lazyLoadError", [s, t, n]),
                  s.progressiveLazyLoad());
            }),
            (r.src = n))
          : s.$slider.trigger("allImagesLoaded", [s]);
      }),
      (s.prototype.refresh = function (e) {
        var t,
          n,
          i = this;
        (n = i.slideCount - i.options.slidesToShow),
          !i.options.infinite && i.currentSlide > n && (i.currentSlide = n),
          i.slideCount <= i.options.slidesToShow && (i.currentSlide = 0),
          (t = i.currentSlide),
          i.destroy(!0),
          u.extend(i, i.initials, { currentSlide: t }),
          i.init(),
          e || i.changeSlide({ data: { message: "index", index: t } }, !1);
      }),
      (s.prototype.registerBreakpoints = function () {
        var e,
          t,
          n,
          i = this,
          o = i.options.responsive || null;
        if ("array" === u.type(o) && o.length) {
          for (e in ((i.respondTo = i.options.respondTo || "window"), o))
            if (((n = i.breakpoints.length - 1), o.hasOwnProperty(e))) {
              for (t = o[e].breakpoint; 0 <= n; )
                i.breakpoints[n] &&
                  i.breakpoints[n] === t &&
                  i.breakpoints.splice(n, 1),
                  n--;
              i.breakpoints.push(t), (i.breakpointSettings[t] = o[e].settings);
            }
          i.breakpoints.sort(function (e, t) {
            return i.options.mobileFirst ? e - t : t - e;
          });
        }
      }),
      (s.prototype.reinit = function () {
        var e = this;
        (e.$slides = e.$slideTrack
          .children(e.options.slide)
          .addClass("slick-slide")),
          (e.slideCount = e.$slides.length),
          e.currentSlide >= e.slideCount &&
            0 !== e.currentSlide &&
            (e.currentSlide = e.currentSlide - e.options.slidesToScroll),
          e.slideCount <= e.options.slidesToShow && (e.currentSlide = 0),
          e.registerBreakpoints(),
          e.setProps(),
          e.setupInfinite(),
          e.buildArrows(),
          e.updateArrows(),
          e.initArrowEvents(),
          e.buildDots(),
          e.updateDots(),
          e.initDotEvents(),
          e.cleanUpSlideEvents(),
          e.initSlideEvents(),
          e.checkResponsive(!1, !0),
          !0 === e.options.focusOnSelect &&
            u(e.$slideTrack).children().on("click.slick", e.selectHandler),
          e.setSlideClasses(
            "number" == typeof e.currentSlide ? e.currentSlide : 0
          ),
          e.setPosition(),
          e.focusHandler(),
          (e.paused = !e.options.autoplay),
          e.autoPlay(),
          e.$slider.trigger("reInit", [e]);
      }),
      (s.prototype.resize = function () {
        var e = this;
        u(window).width() !== e.windowWidth &&
          (clearTimeout(e.windowDelay),
          (e.windowDelay = window.setTimeout(function () {
            (e.windowWidth = u(window).width()),
              e.checkResponsive(),
              e.unslicked || e.setPosition();
          }, 50)));
      }),
      (s.prototype.removeSlide = s.prototype.slickRemove = function (e, t, n) {
        var i = this;
        if (
          ((e =
            "boolean" == typeof e
              ? !0 === (t = e)
                ? 0
                : i.slideCount - 1
              : !0 === t
              ? --e
              : e),
          i.slideCount < 1 || e < 0 || e > i.slideCount - 1)
        )
          return !1;
        i.unload(),
          !0 === n
            ? i.$slideTrack.children().remove()
            : i.$slideTrack.children(this.options.slide).eq(e).remove(),
          (i.$slides = i.$slideTrack.children(this.options.slide)),
          i.$slideTrack.children(this.options.slide).detach(),
          i.$slideTrack.append(i.$slides),
          (i.$slidesCache = i.$slides),
          i.reinit();
      }),
      (s.prototype.setCSS = function (e) {
        var t,
          n,
          i = this,
          o = {};
        !0 === i.options.rtl && (e = -e),
          (t = "left" == i.positionProp ? Math.ceil(e) + "px" : "0px"),
          (n = "top" == i.positionProp ? Math.ceil(e) + "px" : "0px"),
          (o[i.positionProp] = e),
          !1 === i.transformsEnabled ||
            (!(o = {}) === i.cssTransitions
              ? (o[i.animType] = "translate(" + t + ", " + n + ")")
              : (o[i.animType] = "translate3d(" + t + ", " + n + ", 0px)")),
          i.$slideTrack.css(o);
      }),
      (s.prototype.setDimensions = function () {
        var e = this;
        !1 === e.options.vertical
          ? !0 === e.options.centerMode &&
            e.$list.css({ padding: "0px " + e.options.centerPadding })
          : (e.$list.height(
              e.$slides.first().outerHeight(!0) * e.options.slidesToShow
            ),
            !0 === e.options.centerMode &&
              e.$list.css({ padding: e.options.centerPadding + " 0px" })),
          (e.listWidth = e.$list.width()),
          (e.listHeight = e.$list.height()),
          !1 === e.options.vertical && !1 === e.options.variableWidth
            ? ((e.slideWidth = Math.ceil(e.listWidth / e.options.slidesToShow)),
              e.$slideTrack.width(
                Math.ceil(
                  e.slideWidth * e.$slideTrack.children(".slick-slide").length
                )
              ))
            : !0 === e.options.variableWidth
            ? e.$slideTrack.width(5e3 * e.slideCount)
            : ((e.slideWidth = Math.ceil(e.listWidth)),
              e.$slideTrack.height(
                Math.ceil(
                  e.$slides.first().outerHeight(!0) *
                    e.$slideTrack.children(".slick-slide").length
                )
              ));
        var t = e.$slides.first().outerWidth(!0) - e.$slides.first().width();
        !1 === e.options.variableWidth &&
          e.$slideTrack.children(".slick-slide").width(e.slideWidth - t);
      }),
      (s.prototype.setFade = function () {
        var n,
          i = this;
        i.$slides.each(function (e, t) {
          (n = i.slideWidth * e * -1),
            !0 === i.options.rtl
              ? u(t).css({
                  position: "relative",
                  right: n,
                  top: 0,
                  zIndex: i.options.zIndex - 2,
                  opacity: 0,
                })
              : u(t).css({
                  position: "relative",
                  left: n,
                  top: 0,
                  zIndex: i.options.zIndex - 2,
                  opacity: 0,
                });
        }),
          i.$slides
            .eq(i.currentSlide)
            .css({ zIndex: i.options.zIndex - 1, opacity: 1 });
      }),
      (s.prototype.setHeight = function () {
        var e = this;
        if (
          1 === e.options.slidesToShow &&
          !0 === e.options.adaptiveHeight &&
          !1 === e.options.vertical
        ) {
          var t = e.$slides.eq(e.currentSlide).outerHeight(!0);
          e.$list.css("height", t);
        }
      }),
      (s.prototype.setOption = s.prototype.slickSetOption = function () {
        var e,
          t,
          n,
          i,
          o,
          r = this,
          s = !1;
        if (
          ("object" === u.type(arguments[0])
            ? ((n = arguments[0]), (s = arguments[1]), (o = "multiple"))
            : "string" === u.type(arguments[0]) &&
              ((i = arguments[1]),
              (s = arguments[2]),
              "responsive" === (n = arguments[0]) &&
              "array" === u.type(arguments[1])
                ? (o = "responsive")
                : void 0 !== arguments[1] && (o = "single")),
          "single" === o)
        )
          r.options[n] = i;
        else if ("multiple" === o)
          u.each(n, function (e, t) {
            r.options[e] = t;
          });
        else if ("responsive" === o)
          for (t in i)
            if ("array" !== u.type(r.options.responsive))
              r.options.responsive = [i[t]];
            else {
              for (e = r.options.responsive.length - 1; 0 <= e; )
                r.options.responsive[e].breakpoint === i[t].breakpoint &&
                  r.options.responsive.splice(e, 1),
                  e--;
              r.options.responsive.push(i[t]);
            }
        s && (r.unload(), r.reinit());
      }),
      (s.prototype.setPosition = function () {
        var e = this;
        e.setDimensions(),
          e.setHeight(),
          !1 === e.options.fade
            ? e.setCSS(e.getLeft(e.currentSlide))
            : e.setFade(),
          e.$slider.trigger("setPosition", [e]);
      }),
      (s.prototype.setProps = function () {
        var e = this,
          t = document.body.style;
        (e.positionProp = !0 === e.options.vertical ? "top" : "left"),
          "top" === e.positionProp
            ? e.$slider.addClass("slick-vertical")
            : e.$slider.removeClass("slick-vertical"),
          (void 0 === t.WebkitTransition &&
            void 0 === t.MozTransition &&
            void 0 === t.msTransition) ||
            (!0 === e.options.useCSS && (e.cssTransitions = !0)),
          e.options.fade &&
            ("number" == typeof e.options.zIndex
              ? e.options.zIndex < 3 && (e.options.zIndex = 3)
              : (e.options.zIndex = e.defaults.zIndex)),
          void 0 !== t.OTransform &&
            ((e.animType = "OTransform"),
            (e.transformType = "-o-transform"),
            (e.transitionType = "OTransition"),
            void 0 === t.perspectiveProperty &&
              void 0 === t.webkitPerspective &&
              (e.animType = !1)),
          void 0 !== t.MozTransform &&
            ((e.animType = "MozTransform"),
            (e.transformType = "-moz-transform"),
            (e.transitionType = "MozTransition"),
            void 0 === t.perspectiveProperty &&
              void 0 === t.MozPerspective &&
              (e.animType = !1)),
          void 0 !== t.webkitTransform &&
            ((e.animType = "webkitTransform"),
            (e.transformType = "-webkit-transform"),
            (e.transitionType = "webkitTransition"),
            void 0 === t.perspectiveProperty &&
              void 0 === t.webkitPerspective &&
              (e.animType = !1)),
          void 0 !== t.msTransform &&
            ((e.animType = "msTransform"),
            (e.transformType = "-ms-transform"),
            (e.transitionType = "msTransition"),
            void 0 === t.msTransform && (e.animType = !1)),
          void 0 !== t.transform &&
            !1 !== e.animType &&
            ((e.animType = "transform"),
            (e.transformType = "transform"),
            (e.transitionType = "transition")),
          (e.transformsEnabled =
            e.options.useTransform && null !== e.animType && !1 !== e.animType);
      }),
      (s.prototype.setSlideClasses = function (e) {
        var t,
          n,
          i,
          o,
          r = this;
        if (
          ((n = r.$slider
            .find(".slick-slide")
            .removeClass("slick-active slick-center slick-current")
            .attr("aria-hidden", "true")),
          r.$slides.eq(e).addClass("slick-current"),
          !0 === r.options.centerMode)
        ) {
          var s = r.options.slidesToShow % 2 == 0 ? 1 : 0;
          (t = Math.floor(r.options.slidesToShow / 2)),
            !0 === r.options.infinite &&
              (t <= e && e <= r.slideCount - 1 - t
                ? r.$slides
                    .slice(e - t + s, e + t + 1)
                    .addClass("slick-active")
                    .attr("aria-hidden", "false")
                : ((i = r.options.slidesToShow + e),
                  n
                    .slice(i - t + 1 + s, i + t + 2)
                    .addClass("slick-active")
                    .attr("aria-hidden", "false")),
              0 === e
                ? n
                    .eq(n.length - 1 - r.options.slidesToShow)
                    .addClass("slick-center")
                : e === r.slideCount - 1 &&
                  n.eq(r.options.slidesToShow).addClass("slick-center")),
            r.$slides.eq(e).addClass("slick-center");
        } else
          0 <= e && e <= r.slideCount - r.options.slidesToShow
            ? r.$slides
                .slice(e, e + r.options.slidesToShow)
                .addClass("slick-active")
                .attr("aria-hidden", "false")
            : n.length <= r.options.slidesToShow
            ? n.addClass("slick-active").attr("aria-hidden", "false")
            : ((o = r.slideCount % r.options.slidesToShow),
              (i = !0 === r.options.infinite ? r.options.slidesToShow + e : e),
              r.options.slidesToShow == r.options.slidesToScroll &&
              r.slideCount - e < r.options.slidesToShow
                ? n
                    .slice(i - (r.options.slidesToShow - o), i + o)
                    .addClass("slick-active")
                    .attr("aria-hidden", "false")
                : n
                    .slice(i, i + r.options.slidesToShow)
                    .addClass("slick-active")
                    .attr("aria-hidden", "false"));
        ("ondemand" !== r.options.lazyLoad &&
          "anticipated" !== r.options.lazyLoad) ||
          r.lazyLoad();
      }),
      (s.prototype.setupInfinite = function () {
        var e,
          t,
          n,
          i = this;
        if (
          (!0 === i.options.fade && (i.options.centerMode = !1),
          !0 === i.options.infinite &&
            !1 === i.options.fade &&
            ((t = null), i.slideCount > i.options.slidesToShow))
        ) {
          for (
            n =
              !0 === i.options.centerMode
                ? i.options.slidesToShow + 1
                : i.options.slidesToShow,
              e = i.slideCount;
            e > i.slideCount - n;
            --e
          )
            (t = e - 1),
              u(i.$slides[t])
                .clone(!0)
                .attr("id", "")
                .attr("data-slick-index", t - i.slideCount)
                .prependTo(i.$slideTrack)
                .addClass("slick-cloned");
          for (e = 0; e < n + i.slideCount; e += 1)
            (t = e),
              u(i.$slides[t])
                .clone(!0)
                .attr("id", "")
                .attr("data-slick-index", t + i.slideCount)
                .appendTo(i.$slideTrack)
                .addClass("slick-cloned");
          i.$slideTrack
            .find(".slick-cloned")
            .find("[id]")
            .each(function () {
              u(this).attr("id", "");
            });
        }
      }),
      (s.prototype.interrupt = function (e) {
        e || this.autoPlay(), (this.interrupted = e);
      }),
      (s.prototype.selectHandler = function (e) {
        var t = u(e.target).is(".slick-slide")
            ? u(e.target)
            : u(e.target).parents(".slick-slide"),
          n = parseInt(t.attr("data-slick-index"));
        (n = n || 0),
          this.slideCount <= this.options.slidesToShow
            ? this.slideHandler(n, !1, !0)
            : this.slideHandler(n);
      }),
      (s.prototype.slideHandler = function (e, t, n) {
        var i,
          o,
          r,
          s,
          a,
          l = null,
          u = this;
        if (
          ((t = t || !1),
          !(
            (!0 === u.animating && !0 === u.options.waitForAnimate) ||
            (!0 === u.options.fade && u.currentSlide === e)
          ))
        )
          if (
            (!1 === t && u.asNavFor(e),
            (i = e),
            (l = u.getLeft(i)),
            (s = u.getLeft(u.currentSlide)),
            (u.currentLeft = null === u.swipeLeft ? s : u.swipeLeft),
            !1 === u.options.infinite &&
              !1 === u.options.centerMode &&
              (e < 0 || e > u.getDotCount() * u.options.slidesToScroll))
          )
            !1 === u.options.fade &&
              ((i = u.currentSlide),
              !0 !== n
                ? u.animateSlide(s, function () {
                    u.postSlide(i);
                  })
                : u.postSlide(i));
          else if (
            !1 === u.options.infinite &&
            !0 === u.options.centerMode &&
            (e < 0 || e > u.slideCount - u.options.slidesToScroll)
          )
            !1 === u.options.fade &&
              ((i = u.currentSlide),
              !0 !== n
                ? u.animateSlide(s, function () {
                    u.postSlide(i);
                  })
                : u.postSlide(i));
          else {
            if (
              (u.options.autoplay && clearInterval(u.autoPlayTimer),
              (o =
                i < 0
                  ? u.slideCount % u.options.slidesToScroll != 0
                    ? u.slideCount - (u.slideCount % u.options.slidesToScroll)
                    : u.slideCount + i
                  : i >= u.slideCount
                  ? u.slideCount % u.options.slidesToScroll != 0
                    ? 0
                    : i - u.slideCount
                  : i),
              (u.animating = !0),
              u.$slider.trigger("beforeChange", [u, u.currentSlide, o]),
              (r = u.currentSlide),
              (u.currentSlide = o),
              u.setSlideClasses(u.currentSlide),
              u.options.asNavFor &&
                (a = (a = u.getNavTarget()).slick("getSlick")).slideCount <=
                  a.options.slidesToShow &&
                a.setSlideClasses(u.currentSlide),
              u.updateDots(),
              u.updateArrows(),
              !0 === u.options.fade)
            )
              return (
                !0 !== n
                  ? (u.fadeSlideOut(r),
                    u.fadeSlide(o, function () {
                      u.postSlide(o);
                    }))
                  : u.postSlide(o),
                void u.animateHeight()
              );
            !0 !== n
              ? u.animateSlide(l, function () {
                  u.postSlide(o);
                })
              : u.postSlide(o);
          }
      }),
      (s.prototype.startLoad = function () {
        var e = this;
        !0 === e.options.arrows &&
          e.slideCount > e.options.slidesToShow &&
          (e.$prevArrow.hide(), e.$nextArrow.hide()),
          !0 === e.options.dots &&
            e.slideCount > e.options.slidesToShow &&
            e.$dots.hide(),
          e.$slider.addClass("slick-loading");
      }),
      (s.prototype.swipeDirection = function () {
        var e,
          t,
          n,
          i,
          o = this;
        return (
          (e = o.touchObject.startX - o.touchObject.curX),
          (t = o.touchObject.startY - o.touchObject.curY),
          (n = Math.atan2(t, e)),
          (i = Math.round((180 * n) / Math.PI)) < 0 && (i = 360 - Math.abs(i)),
          (i <= 45 && 0 <= i) || (i <= 360 && 315 <= i)
            ? !1 === o.options.rtl
              ? "left"
              : "right"
            : 135 <= i && i <= 225
            ? !1 === o.options.rtl
              ? "right"
              : "left"
            : !0 === o.options.verticalSwiping
            ? 35 <= i && i <= 135
              ? "down"
              : "up"
            : "vertical"
        );
      }),
      (s.prototype.swipeEnd = function (e) {
        var t,
          n,
          i = this;
        if (((i.dragging = !1), (i.swiping = !1), i.scrolling))
          return (i.scrolling = !1);
        if (
          ((i.interrupted = !1),
          (i.shouldClick = !(10 < i.touchObject.swipeLength)),
          void 0 === i.touchObject.curX)
        )
          return !1;
        if (
          (!0 === i.touchObject.edgeHit &&
            i.$slider.trigger("edge", [i, i.swipeDirection()]),
          i.touchObject.swipeLength >= i.touchObject.minSwipe)
        ) {
          switch ((n = i.swipeDirection())) {
            case "left":
            case "down":
              (t = i.options.swipeToSlide
                ? i.checkNavigable(i.currentSlide + i.getSlideCount())
                : i.currentSlide + i.getSlideCount()),
                (i.currentDirection = 0);
              break;
            case "right":
            case "up":
              (t = i.options.swipeToSlide
                ? i.checkNavigable(i.currentSlide - i.getSlideCount())
                : i.currentSlide - i.getSlideCount()),
                (i.currentDirection = 1);
          }
          "vertical" != n &&
            (i.slideHandler(t),
            (i.touchObject = {}),
            i.$slider.trigger("swipe", [i, n]));
        } else
          i.touchObject.startX !== i.touchObject.curX &&
            (i.slideHandler(i.currentSlide), (i.touchObject = {}));
      }),
      (s.prototype.swipeHandler = function (e) {
        var t = this;
        if (
          !(
            !1 === t.options.swipe ||
            ("ontouchend" in document && !1 === t.options.swipe) ||
            (!1 === t.options.draggable && -1 !== e.type.indexOf("mouse"))
          )
        )
          switch (
            ((t.touchObject.fingerCount =
              e.originalEvent && void 0 !== e.originalEvent.touches
                ? e.originalEvent.touches.length
                : 1),
            (t.touchObject.minSwipe = t.listWidth / t.options.touchThreshold),
            !0 === t.options.verticalSwiping &&
              (t.touchObject.minSwipe =
                t.listHeight / t.options.touchThreshold),
            e.data.action)
          ) {
            case "start":
              t.swipeStart(e);
              break;
            case "move":
              t.swipeMove(e);
              break;
            case "end":
              t.swipeEnd(e);
          }
      }),
      (s.prototype.swipeMove = function (e) {
        var t,
          n,
          i,
          o,
          r,
          s,
          a = this;
        return (
          (r = void 0 !== e.originalEvent ? e.originalEvent.touches : null),
          !(!a.dragging || a.scrolling || (r && 1 !== r.length)) &&
            ((t = a.getLeft(a.currentSlide)),
            (a.touchObject.curX = void 0 !== r ? r[0].pageX : e.clientX),
            (a.touchObject.curY = void 0 !== r ? r[0].pageY : e.clientY),
            (a.touchObject.swipeLength = Math.round(
              Math.sqrt(Math.pow(a.touchObject.curX - a.touchObject.startX, 2))
            )),
            (s = Math.round(
              Math.sqrt(Math.pow(a.touchObject.curY - a.touchObject.startY, 2))
            )),
            !a.options.verticalSwiping && !a.swiping && 4 < s
              ? !(a.scrolling = !0)
              : (!0 === a.options.verticalSwiping &&
                  (a.touchObject.swipeLength = s),
                (n = a.swipeDirection()),
                void 0 !== e.originalEvent &&
                  4 < a.touchObject.swipeLength &&
                  ((a.swiping = !0), e.preventDefault()),
                (o =
                  (!1 === a.options.rtl ? 1 : -1) *
                  (a.touchObject.curX > a.touchObject.startX ? 1 : -1)),
                !0 === a.options.verticalSwiping &&
                  (o = a.touchObject.curY > a.touchObject.startY ? 1 : -1),
                (i = a.touchObject.swipeLength),
                (a.touchObject.edgeHit = !1) === a.options.infinite &&
                  ((0 === a.currentSlide && "right" === n) ||
                    (a.currentSlide >= a.getDotCount() && "left" === n)) &&
                  ((i = a.touchObject.swipeLength * a.options.edgeFriction),
                  (a.touchObject.edgeHit = !0)),
                !1 === a.options.vertical
                  ? (a.swipeLeft = t + i * o)
                  : (a.swipeLeft =
                      t + i * (a.$list.height() / a.listWidth) * o),
                !0 === a.options.verticalSwiping && (a.swipeLeft = t + i * o),
                !0 !== a.options.fade &&
                  !1 !== a.options.touchMove &&
                  (!0 === a.animating
                    ? ((a.swipeLeft = null), !1)
                    : void a.setCSS(a.swipeLeft))))
        );
      }),
      (s.prototype.swipeStart = function (e) {
        var t,
          n = this;
        if (
          ((n.interrupted = !0),
          1 !== n.touchObject.fingerCount ||
            n.slideCount <= n.options.slidesToShow)
        )
          return !(n.touchObject = {});
        void 0 !== e.originalEvent &&
          void 0 !== e.originalEvent.touches &&
          (t = e.originalEvent.touches[0]),
          (n.touchObject.startX = n.touchObject.curX =
            void 0 !== t ? t.pageX : e.clientX),
          (n.touchObject.startY = n.touchObject.curY =
            void 0 !== t ? t.pageY : e.clientY),
          (n.dragging = !0);
      }),
      (s.prototype.unfilterSlides = s.prototype.slickUnfilter = function () {
        var e = this;
        null !== e.$slidesCache &&
          (e.unload(),
          e.$slideTrack.children(this.options.slide).detach(),
          e.$slidesCache.appendTo(e.$slideTrack),
          e.reinit());
      }),
      (s.prototype.unload = function () {
        var e = this;
        u(".slick-cloned", e.$slider).remove(),
          e.$dots && e.$dots.remove(),
          e.$prevArrow &&
            e.htmlExpr.test(e.options.prevArrow) &&
            e.$prevArrow.remove(),
          e.$nextArrow &&
            e.htmlExpr.test(e.options.nextArrow) &&
            e.$nextArrow.remove(),
          e.$slides
            .removeClass("slick-slide slick-active slick-visible slick-current")
            .attr("aria-hidden", "true")
            .css("width", "");
      }),
      (s.prototype.unslick = function (e) {
        this.$slider.trigger("unslick", [this, e]), this.destroy();
      }),
      (s.prototype.updateArrows = function () {
        var e = this;
        Math.floor(e.options.slidesToShow / 2),
          !0 === e.options.arrows &&
            e.slideCount > e.options.slidesToShow &&
            !e.options.infinite &&
            (e.$prevArrow
              .removeClass("slick-disabled")
              .attr("aria-disabled", "false"),
            e.$nextArrow
              .removeClass("slick-disabled")
              .attr("aria-disabled", "false"),
            0 === e.currentSlide
              ? (e.$prevArrow
                  .addClass("slick-disabled")
                  .attr("aria-disabled", "true"),
                e.$nextArrow
                  .removeClass("slick-disabled")
                  .attr("aria-disabled", "false"))
              : ((e.currentSlide >= e.slideCount - e.options.slidesToShow &&
                  !1 === e.options.centerMode) ||
                  (e.currentSlide >= e.slideCount - 1 &&
                    !0 === e.options.centerMode)) &&
                (e.$nextArrow
                  .addClass("slick-disabled")
                  .attr("aria-disabled", "true"),
                e.$prevArrow
                  .removeClass("slick-disabled")
                  .attr("aria-disabled", "false")));
      }),
      (s.prototype.updateDots = function () {
        var e = this;
        null !== e.$dots &&
          (e.$dots.find("li").removeClass("slick-active").end(),
          e.$dots
            .find("li")
            .eq(Math.floor(e.currentSlide / e.options.slidesToScroll))
            .addClass("slick-active"));
      }),
      (s.prototype.visibility = function () {
        this.options.autoplay &&
          (document[this.hidden]
            ? (this.interrupted = !0)
            : (this.interrupted = !1));
      }),
      (u.fn.slick = function () {
        var e,
          t,
          n = this,
          i = arguments[0],
          o = Array.prototype.slice.call(arguments, 1),
          r = n.length;
        for (e = 0; e < r; e++)
          if (
            ("object" == typeof i || void 0 === i
              ? (n[e].slick = new s(n[e], i))
              : (t = n[e].slick[i].apply(n[e].slick, o)),
            void 0 !== t)
          )
            return t;
        return n;
      });
  }),
  (function (e, t) {
    "object" == typeof exports && "undefined" != typeof module
      ? t(exports)
      : "function" == typeof define && define.amd
      ? define(["exports"], t)
      : t(((e = e || self).IMask = {}));
  })(this, function (e) {
    "use strict";
    var t =
      "undefined" != typeof globalThis
        ? globalThis
        : "undefined" != typeof window
        ? window
        : "undefined" != typeof global
        ? global
        : "undefined" != typeof self
        ? self
        : {};
    function n(e, t) {
      return e((t = { exports: {} }), t.exports), t.exports;
    }
    function i(e) {
      return e && e.Math == Math && e;
    }
    function o(e) {
      try {
        return !!e();
      } catch (e) {
        return !0;
      }
    }
    function r(e, t) {
      return {
        enumerable: !(1 & e),
        configurable: !(2 & e),
        writable: !(4 & e),
        value: t,
      };
    }
    function p(e) {
      if (null == e) throw TypeError("Can't call method on " + e);
      return e;
    }
    function c(e) {
      return b(p(e));
    }
    function s(e) {
      return "object" == typeof e ? null !== e : "function" == typeof e;
    }
    function a(e, t) {
      if (!s(e)) return e;
      var n, i;
      if (t && "function" == typeof (n = e.toString) && !s((i = n.call(e))))
        return i;
      if ("function" == typeof (n = e.valueOf) && !s((i = n.call(e)))) return i;
      if (!t && "function" == typeof (n = e.toString) && !s((i = n.call(e))))
        return i;
      throw TypeError("Can't convert object to primitive value");
    }
    function u(e, t) {
      return w.call(e, t);
    }
    function l(e) {
      if (!s(e)) throw TypeError(String(e) + " is not an object");
      return e;
    }
    function d(t, n) {
      try {
        _(h, t, n);
      } catch (e) {
        h[t] = n;
      }
      return n;
    }
    var h =
        i("object" == typeof globalThis && globalThis) ||
        i("object" == typeof window && window) ||
        i("object" == typeof self && self) ||
        i("object" == typeof t && t) ||
        Function("return this")(),
      f = !o(function () {
        return (
          7 !=
          Object.defineProperty({}, 1, {
            get: function () {
              return 7;
            },
          })[1]
        );
      }),
      g = {}.propertyIsEnumerable,
      v = Object.getOwnPropertyDescriptor,
      m = {
        f:
          v && !g.call({ 1: 2 }, 1)
            ? function (e) {
                var t = v(this, e);
                return !!t && t.enumerable;
              }
            : g,
      },
      y = {}.toString,
      k = "".split,
      b = o(function () {
        return !Object("z").propertyIsEnumerable(0);
      })
        ? function (e) {
            return "String" == ((t = e), y.call(t).slice(8, -1))
              ? k.call(e, "")
              : Object(e);
            var t;
          }
        : Object,
      w = {}.hasOwnProperty,
      C = h.document,
      x = s(C) && s(C.createElement),
      S =
        !f &&
        !o(function () {
          return (
            7 !=
            Object.defineProperty(x ? C.createElement("div") : {}, "a", {
              get: function () {
                return 7;
              },
            }).a
          );
        }),
      T = Object.getOwnPropertyDescriptor,
      A = {
        f: f
          ? T
          : function (e, t) {
              if (((e = c(e)), (t = a(t, !0)), S))
                try {
                  return T(e, t);
                } catch (e) {}
              if (u(e, t)) return r(!m.f.call(e, t), e[t]);
            },
      },
      E = Object.defineProperty,
      $ = {
        f: f
          ? E
          : function (e, t, n) {
              if ((l(e), (t = a(t, !0)), l(n), S))
                try {
                  return E(e, t, n);
                } catch (e) {}
              if ("get" in n || "set" in n)
                throw TypeError("Accessors not supported");
              return "value" in n && (e[t] = n.value), e;
            },
      },
      _ = f
        ? function (e, t, n) {
            return $.f(e, t, r(1, n));
          }
        : function (e, t, n) {
            return (e[t] = n), e;
          },
      D = h["__core-js_shared__"] || d("__core-js_shared__", {}),
      F = Function.toString;
    "function" != typeof D.inspectSource &&
      (D.inspectSource = function (e) {
        return F.call(e);
      });
    var P,
      j,
      O,
      M = D.inspectSource,
      B = h.WeakMap,
      L = "function" == typeof B && /native code/.test(M(B)),
      I = n(function (e) {
        (e.exports = function (e, t) {
          return D[e] || (D[e] = void 0 !== t ? t : {});
        })("versions", []).push({
          version: "3.6.4",
          mode: "global",
          copyright: "© 2020 Denis Pushkarev (zloirock.ru)",
        });
      }),
      N = 0,
      H = Math.random(),
      q = I("keys"),
      R = {},
      z = h.WeakMap;
    if (L) {
      var V = new z(),
        W = V.get,
        X = V.has,
        Y = V.set;
      (P = function (e, t) {
        return Y.call(V, e, t), t;
      }),
        (j = function (e) {
          return W.call(V, e) || {};
        }),
        (O = function (e) {
          return X.call(V, e);
        });
    } else {
      var U =
        q["state"] ||
        (q.state = "Symbol(" + String("state") + ")_" + (++N + H).toString(36));
      (R[U] = !0),
        (P = function (e, t) {
          return _(e, U, t), t;
        }),
        (j = function (e) {
          return u(e, U) ? e[U] : {};
        }),
        (O = function (e) {
          return u(e, U);
        });
    }
    function G(e) {
      return "function" == typeof e ? e : void 0;
    }
    function K(e, t) {
      return arguments.length < 2
        ? G(se[e]) || G(h[e])
        : (se[e] && se[e][t]) || (h[e] && h[e][t]);
    }
    function Q(e) {
      return isNaN((e = +e)) ? 0 : (0 < e ? le : ae)(e);
    }
    function Z(e) {
      return 0 < e ? ue(Q(e), 9007199254740991) : 0;
    }
    function J(u) {
      return function (e, t, n) {
        var i,
          o,
          r,
          s = c(e),
          a = Z(s.length),
          l = ((o = a), (r = Q(n)) < 0 ? ce(r + o, 0) : de(r, o));
        if (u && t != t) {
          for (; l < a; ) if ((i = s[l++]) != i) return !0;
        } else for (; l < a; l++) if ((u || l in s) && s[l] === t) return u || l || 0;
        return !u && -1;
      };
    }
    function ee(e, t) {
      var n,
        i = c(e),
        o = 0,
        r = [];
      for (n in i) !u(R, n) && u(i, n) && r.push(n);
      for (; t.length > o; ) u(i, (n = t[o++])) && (~pe(r, n) || r.push(n));
      return r;
    }
    function te(e, t) {
      for (var n = me(t), i = $.f, o = A.f, r = 0; r < n.length; r++) {
        var s = n[r];
        u(e, s) || i(e, s, o(t, s));
      }
    }
    function ne(e, t) {
      var n = be[ke(e)];
      return n == Ce || (n != we && ("function" == typeof t ? o(t) : !!t));
    }
    function ie(e, t) {
      var n,
        i,
        o,
        r,
        s,
        a = e.target,
        l = e.global,
        u = e.stat;
      if ((n = l ? h : u ? h[a] || d(a, {}) : (h[a] || {}).prototype))
        for (i in t) {
          if (
            ((r = t[i]),
            (o = e.noTargetGet ? (s = Se(n, i)) && s.value : n[i]),
            !xe(l ? i : a + (u ? "." : "#") + i, e.forced) && void 0 !== o)
          ) {
            if (typeof r == typeof o) continue;
            te(r, o);
          }
          (e.sham || (o && o.sham)) && _(r, "sham", !0), re(n, i, r, e);
        }
    }
    var oe = {
        set: P,
        get: j,
        has: O,
        enforce: function (e) {
          return O(e) ? j(e) : P(e, {});
        },
        getterFor: function (n) {
          return function (e) {
            var t;
            if (!s(e) || (t = j(e)).type !== n)
              throw TypeError("Incompatible receiver, " + n + " required");
            return t;
          };
        },
      },
      re = n(function (e) {
        var t = oe.get,
          a = oe.enforce,
          l = String(String).split("String");
        (e.exports = function (e, t, n, i) {
          var o = !!i && !!i.unsafe,
            r = !!i && !!i.enumerable,
            s = !!i && !!i.noTargetGet;
          "function" == typeof n &&
            ("string" != typeof t || u(n, "name") || _(n, "name", t),
            (a(n).source = l.join("string" == typeof t ? t : ""))),
            e !== h
              ? (o ? !s && e[t] && (r = !0) : delete e[t],
                r ? (e[t] = n) : _(e, t, n))
              : r
              ? (e[t] = n)
              : d(t, n);
        })(Function.prototype, "toString", function () {
          return ("function" == typeof this && t(this).source) || M(this);
        });
      }),
      se = h,
      ae = Math.ceil,
      le = Math.floor,
      ue = Math.min,
      ce = Math.max,
      de = Math.min,
      pe = (J(!0), J(!1)),
      he = [
        "constructor",
        "hasOwnProperty",
        "isPrototypeOf",
        "propertyIsEnumerable",
        "toLocaleString",
        "toString",
        "valueOf",
      ],
      fe = he.concat("length", "prototype"),
      ge = {
        f:
          Object.getOwnPropertyNames ||
          function (e) {
            return ee(e, fe);
          },
      },
      ve = { f: Object.getOwnPropertySymbols },
      me =
        K("Reflect", "ownKeys") ||
        function (e) {
          var t = ge.f(l(e)),
            n = ve.f;
          return n ? t.concat(n(e)) : t;
        },
      ye = /#|\.prototype\./,
      ke = (ne.normalize = function (e) {
        return String(e).replace(ye, ".").toLowerCase();
      }),
      be = (ne.data = {}),
      we = (ne.NATIVE = "N"),
      Ce = (ne.POLYFILL = "P"),
      xe = ne,
      Se = A.f,
      Te =
        Object.keys ||
        function (e) {
          return ee(e, he);
        },
      Ae = Object.assign,
      Ee = Object.defineProperty,
      $e =
        !Ae ||
        o(function () {
          if (
            f &&
            1 !==
              Ae(
                { b: 1 },
                Ae(
                  Ee({}, "a", {
                    enumerable: !0,
                    get: function () {
                      Ee(this, "b", { value: 3, enumerable: !1 });
                    },
                  }),
                  { b: 2 }
                )
              ).b
          )
            return 1;
          var e = {},
            t = {},
            n = Symbol();
          return (
            (e[n] = 7),
            "abcdefghijklmnopqrst".split("").forEach(function (e) {
              t[e] = e;
            }),
            7 != Ae({}, e)[n] ||
              "abcdefghijklmnopqrst" != Te(Ae({}, t)).join("")
          );
        })
          ? function (e, t) {
              for (
                var n = Object(p(e)),
                  i = arguments.length,
                  o = 1,
                  r = ve.f,
                  s = m.f;
                o < i;

              )
                for (
                  var a,
                    l = b(arguments[o++]),
                    u = r ? Te(l).concat(r(l)) : Te(l),
                    c = u.length,
                    d = 0;
                  d < c;

                )
                  (a = u[d++]), (f && !s.call(l, a)) || (n[a] = l[a]);
              return n;
            }
          : Ae;
    ie(
      { target: "Object", stat: !0, forced: Object.assign !== $e },
      { assign: $e }
    );
    function _e(u) {
      return function (e, t, n) {
        var i,
          o,
          r = String(p(e)),
          s = r.length,
          a = void 0 === n ? " " : String(n),
          l = Z(t);
        return l <= s || "" == a
          ? r
          : ((i = l - s),
            (o = De.call(a, Fe(i / a.length))).length > i &&
              (o = o.slice(0, i)),
            u ? r + o : o + r);
      };
    }
    var De =
        "".repeat ||
        function (e) {
          var t = String(p(this)),
            n = "",
            i = Q(e);
          if (i < 0 || i == 1 / 0)
            throw RangeError("Wrong number of repetitions");
          for (; 0 < i; (i >>>= 1) && (t += t)) 1 & i && (n += t);
          return n;
        },
      Fe = Math.ceil,
      Pe = { start: _e(!1), end: _e(!0) },
      je = K("navigator", "userAgent") || "",
      Oe = /Version\/10\.\d+(\.\d+)?( Mobile\/\w+)? Safari\//.test(je),
      Me = Pe.end;
    ie(
      { target: "String", proto: !0, forced: Oe },
      {
        padEnd: function (e) {
          return Me(this, e, 1 < arguments.length ? arguments[1] : void 0);
        },
      }
    );
    var Be = Pe.start;
    function Le(e) {
      return (Le =
        "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
          ? function (e) {
              return typeof e;
            }
          : function (e) {
              return e &&
                "function" == typeof Symbol &&
                e.constructor === Symbol &&
                e !== Symbol.prototype
                ? "symbol"
                : typeof e;
            })(e);
    }
    function Ie(e, t) {
      if (!(e instanceof t))
        throw new TypeError("Cannot call a class as a function");
    }
    function Ne(e, t) {
      for (var n = 0; n < t.length; n++) {
        var i = t[n];
        (i.enumerable = i.enumerable || !1),
          (i.configurable = !0),
          "value" in i && (i.writable = !0),
          Object.defineProperty(e, i.key, i);
      }
    }
    function He(e, t, n) {
      return t && Ne(e.prototype, t), n && Ne(e, n), e;
    }
    function qe(e, t) {
      if ("function" != typeof t && null !== t)
        throw new TypeError(
          "Super expression must either be null or a function"
        );
      (e.prototype = Object.create(t && t.prototype, {
        constructor: { value: e, writable: !0, configurable: !0 },
      })),
        t && ze(e, t);
    }
    function Re(e) {
      return (Re = Object.setPrototypeOf
        ? Object.getPrototypeOf
        : function (e) {
            return e.__proto__ || Object.getPrototypeOf(e);
          })(e);
    }
    function ze(e, t) {
      return (ze =
        Object.setPrototypeOf ||
        function (e, t) {
          return (e.__proto__ = t), e;
        })(e, t);
    }
    function Ve(e, t) {
      if (null == e) return {};
      var n,
        i,
        o = (function (e, t) {
          if (null == e) return {};
          var n,
            i,
            o = {},
            r = Object.keys(e);
          for (i = 0; i < r.length; i++)
            (n = r[i]), 0 <= t.indexOf(n) || (o[n] = e[n]);
          return o;
        })(e, t);
      if (Object.getOwnPropertySymbols) {
        var r = Object.getOwnPropertySymbols(e);
        for (i = 0; i < r.length; i++)
          (n = r[i]),
            0 <= t.indexOf(n) ||
              (Object.prototype.propertyIsEnumerable.call(e, n) &&
                (o[n] = e[n]));
      }
      return o;
    }
    function We(e, t) {
      return !t || ("object" != typeof t && "function" != typeof t)
        ? (function (e) {
            if (void 0 === e)
              throw new ReferenceError(
                "this hasn't been initialised - super() hasn't been called"
              );
            return e;
          })(e)
        : t;
    }
    function Xe(e, t) {
      for (
        ;
        !Object.prototype.hasOwnProperty.call(e, t) && null !== (e = Re(e));

      );
      return e;
    }
    function Ye(e, t, n) {
      return (Ye =
        "undefined" != typeof Reflect && Reflect.get
          ? Reflect.get
          : function (e, t, n) {
              var i = Xe(e, t);
              if (i) {
                var o = Object.getOwnPropertyDescriptor(i, t);
                return o.get ? o.get.call(n) : o.value;
              }
            })(e, t, n || e);
    }
    function Ue(e, t, n, i) {
      return (Ue =
        "undefined" != typeof Reflect && Reflect.set
          ? Reflect.set
          : function (e, t, n, i) {
              var o,
                r,
                s,
                a,
                l = Xe(e, t);
              if (l) {
                if ((o = Object.getOwnPropertyDescriptor(l, t)).set)
                  return o.set.call(i, n), !0;
                if (!o.writable) return !1;
              }
              if ((o = Object.getOwnPropertyDescriptor(i, t))) {
                if (!o.writable) return !1;
                (o.value = n), Object.defineProperty(i, t, o);
              } else
                (a = n),
                  (s = t) in (r = i)
                    ? Object.defineProperty(r, s, {
                        value: a,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0,
                      })
                    : (r[s] = a);
              return !0;
            })(e, t, n, i);
    }
    function Ge(e, t, n, i, o) {
      if (!Ue(e, t, n, i || e) && o) throw new Error("failed to set property");
      return n;
    }
    function Ke(e, t) {
      return (
        (function (e) {
          if (Array.isArray(e)) return e;
        })(e) ||
        (function (e, t) {
          if (
            Symbol.iterator in Object(e) ||
            "[object Arguments]" === Object.prototype.toString.call(e)
          ) {
            var n = [],
              i = !0,
              o = !1,
              r = void 0;
            try {
              for (
                var s, a = e[Symbol.iterator]();
                !(i = (s = a.next()).done) &&
                (n.push(s.value), !t || n.length !== t);
                i = !0
              );
            } catch (e) {
              (o = !0), (r = e);
            } finally {
              try {
                i || null == a.return || a.return();
              } finally {
                if (o) throw r;
              }
            }
            return n;
          }
        })(e, t) ||
        (function () {
          throw new TypeError(
            "Invalid attempt to destructure non-iterable instance"
          );
        })()
      );
    }
    function Qe(e) {
      return "string" == typeof e || e instanceof String;
    }
    ie(
      { target: "String", proto: !0, forced: Oe },
      {
        padStart: function (e) {
          return Be(this, e, 1 < arguments.length ? arguments[1] : void 0);
        },
      }
    ),
      ie({ target: "String", proto: !0 }, { repeat: De }),
      ie({ global: !0 }, { globalThis: h });
    var Ze = "NONE",
      Je = "LEFT",
      et = "FORCE_LEFT",
      tt = "RIGHT",
      nt = "FORCE_RIGHT";
    function it(e) {
      return e.replace(/([.*+?^=!:${}()|[\]/\\])/g, "\\$1");
    }
    var ot =
        (He(ut, [
          {
            key: "startChangePos",
            get: function () {
              return Math.min(this.cursorPos, this.oldSelection.start);
            },
          },
          {
            key: "insertedCount",
            get: function () {
              return this.cursorPos - this.startChangePos;
            },
          },
          {
            key: "inserted",
            get: function () {
              return this.value.substr(this.startChangePos, this.insertedCount);
            },
          },
          {
            key: "removedCount",
            get: function () {
              return Math.max(
                this.oldSelection.end - this.startChangePos ||
                  this.oldValue.length - this.value.length,
                0
              );
            },
          },
          {
            key: "removed",
            get: function () {
              return this.oldValue.substr(
                this.startChangePos,
                this.removedCount
              );
            },
          },
          {
            key: "head",
            get: function () {
              return this.value.substring(0, this.startChangePos);
            },
          },
          {
            key: "tail",
            get: function () {
              return this.value.substring(
                this.startChangePos + this.insertedCount
              );
            },
          },
          {
            key: "removeDirection",
            get: function () {
              return !this.removedCount || this.insertedCount
                ? Ze
                : this.oldSelection.end === this.cursorPos ||
                  this.oldSelection.start === this.cursorPos
                ? tt
                : Je;
            },
          },
        ]),
        ut),
      rt =
        (He(lt, [
          {
            key: "aggregate",
            value: function (e) {
              return (
                (this.rawInserted += e.rawInserted),
                (this.skip = this.skip || e.skip),
                (this.inserted += e.inserted),
                (this.tailShift += e.tailShift),
                this
              );
            },
          },
          {
            key: "offset",
            get: function () {
              return this.tailShift + this.inserted.length;
            },
          },
        ]),
        lt),
      st =
        (He(at, [
          {
            key: "toString",
            value: function () {
              return this.value;
            },
          },
          {
            key: "extend",
            value: function (e) {
              this.value += String(e);
            },
          },
          {
            key: "appendTo",
            value: function (e) {
              return e
                .append(this.toString(), { tail: !0 })
                .aggregate(e._appendPlaceholder());
            },
          },
          {
            key: "shiftBefore",
            value: function (e) {
              if (this.from >= e || !this.value.length) return "";
              var t = this.value[0];
              return (this.value = this.value.slice(1)), t;
            },
          },
          {
            key: "state",
            get: function () {
              return { value: this.value, from: this.from, stop: this.stop };
            },
            set: function (e) {
              Object.assign(this, e);
            },
          },
        ]),
        at);
    function at() {
      var e =
          0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : "",
        t = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : 0,
        n = 2 < arguments.length ? arguments[2] : void 0;
      Ie(this, at), (this.value = e), (this.from = t), (this.stop = n);
    }
    function lt(e) {
      Ie(this, lt),
        Object.assign(
          this,
          { inserted: "", rawInserted: "", skip: !1, tailShift: 0 },
          e
        );
    }
    function ut(e, t, n, i) {
      for (
        Ie(this, ut),
          this.value = e,
          this.cursorPos = t,
          this.oldValue = n,
          this.oldSelection = i;
        this.value.slice(0, this.startChangePos) !==
        this.oldValue.slice(0, this.startChangePos);

      )
        --this.oldSelection.start;
    }
    function ct(e) {
      return new ct.InputMask(
        e,
        1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : {}
      );
    }
    var dt =
      (He(pt, [
        {
          key: "updateOptions",
          value: function (e) {
            Object.keys(e).length &&
              this.withValueRefresh(this._update.bind(this, e));
          },
        },
        {
          key: "_update",
          value: function (e) {
            Object.assign(this, e);
          },
        },
        {
          key: "reset",
          value: function () {
            this._value = "";
          },
        },
        {
          key: "resolve",
          value: function (e) {
            return (
              this.reset(),
              this.append(e, { input: !0 }, ""),
              this.doCommit(),
              this.value
            );
          },
        },
        {
          key: "nearestInputPos",
          value: function (e, t) {
            return e;
          },
        },
        {
          key: "extractInput",
          value: function () {
            var e =
                0 < arguments.length && void 0 !== arguments[0]
                  ? arguments[0]
                  : 0,
              t =
                1 < arguments.length && void 0 !== arguments[1]
                  ? arguments[1]
                  : this.value.length;
            return this.value.slice(e, t);
          },
        },
        {
          key: "extractTail",
          value: function () {
            var e =
                0 < arguments.length && void 0 !== arguments[0]
                  ? arguments[0]
                  : 0,
              t =
                1 < arguments.length && void 0 !== arguments[1]
                  ? arguments[1]
                  : this.value.length;
            return new st(this.extractInput(e, t), e);
          },
        },
        {
          key: "appendTail",
          value: function (e) {
            return Qe(e) && (e = new st(String(e))), e.appendTo(this);
          },
        },
        {
          key: "_appendCharRaw",
          value: function (e) {
            var t =
              1 < arguments.length && void 0 !== arguments[1]
                ? arguments[1]
                : {};
            return (e = this.doPrepare(e, t))
              ? ((this._value += e), new rt({ inserted: e, rawInserted: e }))
              : new rt();
          },
        },
        {
          key: "_appendChar",
          value: function (e) {
            var t =
                1 < arguments.length && void 0 !== arguments[1]
                  ? arguments[1]
                  : {},
              n = 2 < arguments.length ? arguments[2] : void 0,
              i = this.state,
              o = this._appendCharRaw(e, t);
            if (o.inserted) {
              var r,
                s = !1 !== this.doValidate(t);
              if (s && null != n) {
                var a = this.state;
                this.overwrite &&
                  ((r = n.state), n.shiftBefore(this.value.length));
                var l = this.appendTail(n);
                (s = l.rawInserted === n.toString()) &&
                  l.inserted &&
                  (this.state = a);
              }
              s || ((o = new rt()), (this.state = i), n && r && (n.state = r));
            }
            return o;
          },
        },
        {
          key: "_appendPlaceholder",
          value: function () {
            return new rt();
          },
        },
        {
          key: "append",
          value: function (e, t, n) {
            if (!Qe(e)) throw new Error("value should be string");
            var i = new rt(),
              o = Qe(n) ? new st(String(n)) : n;
            t.tail && (t._beforeTailState = this.state);
            for (var r = 0; r < e.length; ++r)
              i.aggregate(this._appendChar(e[r], t, o));
            return (
              null != o && (i.tailShift += this.appendTail(o).tailShift), i
            );
          },
        },
        {
          key: "remove",
          value: function () {
            var e =
                0 < arguments.length && void 0 !== arguments[0]
                  ? arguments[0]
                  : 0,
              t =
                1 < arguments.length && void 0 !== arguments[1]
                  ? arguments[1]
                  : this.value.length;
            return (
              (this._value = this.value.slice(0, e) + this.value.slice(t)),
              new rt()
            );
          },
        },
        {
          key: "withValueRefresh",
          value: function (e) {
            if (this._refreshing || !this.isInitialized) return e();
            this._refreshing = !0;
            var t = this.rawInputValue,
              n = this.value,
              i = e();
            return (
              (this.rawInputValue = t),
              this.value !== n &&
                0 === n.indexOf(this._value) &&
                this.append(n.slice(this._value.length), {}, ""),
              delete this._refreshing,
              i
            );
          },
        },
        {
          key: "runIsolated",
          value: function (e) {
            if (this._isolated || !this.isInitialized) return e(this);
            this._isolated = !0;
            var t = this.state,
              n = e(this);
            return (this.state = t), delete this._isolated, n;
          },
        },
        {
          key: "doPrepare",
          value: function (e) {
            var t =
              1 < arguments.length && void 0 !== arguments[1]
                ? arguments[1]
                : {};
            return this.prepare ? this.prepare(e, this, t) : e;
          },
        },
        {
          key: "doValidate",
          value: function (e) {
            return (
              (!this.validate || this.validate(this.value, this, e)) &&
              (!this.parent || this.parent.doValidate(e))
            );
          },
        },
        {
          key: "doCommit",
          value: function () {
            this.commit && this.commit(this.value, this);
          },
        },
        {
          key: "doFormat",
          value: function (e) {
            return this.format ? this.format(e, this) : e;
          },
        },
        {
          key: "doParse",
          value: function (e) {
            return this.parse ? this.parse(e, this) : e;
          },
        },
        {
          key: "splice",
          value: function (e, t, n, i) {
            var o = e + t,
              r = this.extractTail(o),
              s = this.nearestInputPos(e, i);
            return new rt({ tailShift: s - e })
              .aggregate(this.remove(s))
              .aggregate(this.append(n, { input: !0 }, r));
          },
        },
        {
          key: "state",
          get: function () {
            return { _value: this.value };
          },
          set: function (e) {
            this._value = e._value;
          },
        },
        {
          key: "value",
          get: function () {
            return this._value;
          },
          set: function (e) {
            this.resolve(e);
          },
        },
        {
          key: "unmaskedValue",
          get: function () {
            return this.value;
          },
          set: function (e) {
            this.reset(), this.append(e, {}, ""), this.doCommit();
          },
        },
        {
          key: "typedValue",
          get: function () {
            return this.doParse(this.value);
          },
          set: function (e) {
            this.value = this.doFormat(e);
          },
        },
        {
          key: "rawInputValue",
          get: function () {
            return this.extractInput(0, this.value.length, { raw: !0 });
          },
          set: function (e) {
            this.reset(), this.append(e, { raw: !0 }, ""), this.doCommit();
          },
        },
        {
          key: "isComplete",
          get: function () {
            return !0;
          },
        },
      ]),
      pt);
    function pt(e) {
      Ie(this, pt),
        (this._value = ""),
        this._update(Object.assign({}, pt.DEFAULTS, {}, e)),
        (this.isInitialized = !0);
    }
    function ht(e) {
      if (null == e) throw new Error("mask property should be defined");
      return e instanceof RegExp
        ? ct.MaskedRegExp
        : Qe(e)
        ? ct.MaskedPattern
        : e instanceof Date || e === Date
        ? ct.MaskedDate
        : e instanceof Number || "number" == typeof e || e === Number
        ? ct.MaskedNumber
        : Array.isArray(e) || e === Array
        ? ct.MaskedDynamic
        : ct.Masked && e.prototype instanceof ct.Masked
        ? e
        : e instanceof Function
        ? ct.MaskedFunction
        : (console.warn("Mask not found for mask", e), ct.Masked);
    }
    function ft(e) {
      if (ct.Masked && e instanceof ct.Masked) return e;
      var t = (e = Object.assign({}, e)).mask;
      if (ct.Masked && t instanceof ct.Masked) return t;
      var n = ht(t);
      if (!n)
        throw new Error(
          "Masked class is not found for provided mask, appropriate module needs to be import manually before creating mask."
        );
      return new n(e);
    }
    (dt.DEFAULTS = {
      format: function (e) {
        return e;
      },
      parse: function (e) {
        return e;
      },
    }),
      (ct.Masked = dt),
      (ct.createMask = ft);
    var gt = {
        0: /\d/,
        a: /[\u0041-\u005A\u0061-\u007A\u00AA\u00B5\u00BA\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02C1\u02C6-\u02D1\u02E0-\u02E4\u02EC\u02EE\u0370-\u0374\u0376\u0377\u037A-\u037D\u0386\u0388-\u038A\u038C\u038E-\u03A1\u03A3-\u03F5\u03F7-\u0481\u048A-\u0527\u0531-\u0556\u0559\u0561-\u0587\u05D0-\u05EA\u05F0-\u05F2\u0620-\u064A\u066E\u066F\u0671-\u06D3\u06D5\u06E5\u06E6\u06EE\u06EF\u06FA-\u06FC\u06FF\u0710\u0712-\u072F\u074D-\u07A5\u07B1\u07CA-\u07EA\u07F4\u07F5\u07FA\u0800-\u0815\u081A\u0824\u0828\u0840-\u0858\u08A0\u08A2-\u08AC\u0904-\u0939\u093D\u0950\u0958-\u0961\u0971-\u0977\u0979-\u097F\u0985-\u098C\u098F\u0990\u0993-\u09A8\u09AA-\u09B0\u09B2\u09B6-\u09B9\u09BD\u09CE\u09DC\u09DD\u09DF-\u09E1\u09F0\u09F1\u0A05-\u0A0A\u0A0F\u0A10\u0A13-\u0A28\u0A2A-\u0A30\u0A32\u0A33\u0A35\u0A36\u0A38\u0A39\u0A59-\u0A5C\u0A5E\u0A72-\u0A74\u0A85-\u0A8D\u0A8F-\u0A91\u0A93-\u0AA8\u0AAA-\u0AB0\u0AB2\u0AB3\u0AB5-\u0AB9\u0ABD\u0AD0\u0AE0\u0AE1\u0B05-\u0B0C\u0B0F\u0B10\u0B13-\u0B28\u0B2A-\u0B30\u0B32\u0B33\u0B35-\u0B39\u0B3D\u0B5C\u0B5D\u0B5F-\u0B61\u0B71\u0B83\u0B85-\u0B8A\u0B8E-\u0B90\u0B92-\u0B95\u0B99\u0B9A\u0B9C\u0B9E\u0B9F\u0BA3\u0BA4\u0BA8-\u0BAA\u0BAE-\u0BB9\u0BD0\u0C05-\u0C0C\u0C0E-\u0C10\u0C12-\u0C28\u0C2A-\u0C33\u0C35-\u0C39\u0C3D\u0C58\u0C59\u0C60\u0C61\u0C85-\u0C8C\u0C8E-\u0C90\u0C92-\u0CA8\u0CAA-\u0CB3\u0CB5-\u0CB9\u0CBD\u0CDE\u0CE0\u0CE1\u0CF1\u0CF2\u0D05-\u0D0C\u0D0E-\u0D10\u0D12-\u0D3A\u0D3D\u0D4E\u0D60\u0D61\u0D7A-\u0D7F\u0D85-\u0D96\u0D9A-\u0DB1\u0DB3-\u0DBB\u0DBD\u0DC0-\u0DC6\u0E01-\u0E30\u0E32\u0E33\u0E40-\u0E46\u0E81\u0E82\u0E84\u0E87\u0E88\u0E8A\u0E8D\u0E94-\u0E97\u0E99-\u0E9F\u0EA1-\u0EA3\u0EA5\u0EA7\u0EAA\u0EAB\u0EAD-\u0EB0\u0EB2\u0EB3\u0EBD\u0EC0-\u0EC4\u0EC6\u0EDC-\u0EDF\u0F00\u0F40-\u0F47\u0F49-\u0F6C\u0F88-\u0F8C\u1000-\u102A\u103F\u1050-\u1055\u105A-\u105D\u1061\u1065\u1066\u106E-\u1070\u1075-\u1081\u108E\u10A0-\u10C5\u10C7\u10CD\u10D0-\u10FA\u10FC-\u1248\u124A-\u124D\u1250-\u1256\u1258\u125A-\u125D\u1260-\u1288\u128A-\u128D\u1290-\u12B0\u12B2-\u12B5\u12B8-\u12BE\u12C0\u12C2-\u12C5\u12C8-\u12D6\u12D8-\u1310\u1312-\u1315\u1318-\u135A\u1380-\u138F\u13A0-\u13F4\u1401-\u166C\u166F-\u167F\u1681-\u169A\u16A0-\u16EA\u1700-\u170C\u170E-\u1711\u1720-\u1731\u1740-\u1751\u1760-\u176C\u176E-\u1770\u1780-\u17B3\u17D7\u17DC\u1820-\u1877\u1880-\u18A8\u18AA\u18B0-\u18F5\u1900-\u191C\u1950-\u196D\u1970-\u1974\u1980-\u19AB\u19C1-\u19C7\u1A00-\u1A16\u1A20-\u1A54\u1AA7\u1B05-\u1B33\u1B45-\u1B4B\u1B83-\u1BA0\u1BAE\u1BAF\u1BBA-\u1BE5\u1C00-\u1C23\u1C4D-\u1C4F\u1C5A-\u1C7D\u1CE9-\u1CEC\u1CEE-\u1CF1\u1CF5\u1CF6\u1D00-\u1DBF\u1E00-\u1F15\u1F18-\u1F1D\u1F20-\u1F45\u1F48-\u1F4D\u1F50-\u1F57\u1F59\u1F5B\u1F5D\u1F5F-\u1F7D\u1F80-\u1FB4\u1FB6-\u1FBC\u1FBE\u1FC2-\u1FC4\u1FC6-\u1FCC\u1FD0-\u1FD3\u1FD6-\u1FDB\u1FE0-\u1FEC\u1FF2-\u1FF4\u1FF6-\u1FFC\u2071\u207F\u2090-\u209C\u2102\u2107\u210A-\u2113\u2115\u2119-\u211D\u2124\u2126\u2128\u212A-\u212D\u212F-\u2139\u213C-\u213F\u2145-\u2149\u214E\u2183\u2184\u2C00-\u2C2E\u2C30-\u2C5E\u2C60-\u2CE4\u2CEB-\u2CEE\u2CF2\u2CF3\u2D00-\u2D25\u2D27\u2D2D\u2D30-\u2D67\u2D6F\u2D80-\u2D96\u2DA0-\u2DA6\u2DA8-\u2DAE\u2DB0-\u2DB6\u2DB8-\u2DBE\u2DC0-\u2DC6\u2DC8-\u2DCE\u2DD0-\u2DD6\u2DD8-\u2DDE\u2E2F\u3005\u3006\u3031-\u3035\u303B\u303C\u3041-\u3096\u309D-\u309F\u30A1-\u30FA\u30FC-\u30FF\u3105-\u312D\u3131-\u318E\u31A0-\u31BA\u31F0-\u31FF\u3400-\u4DB5\u4E00-\u9FCC\uA000-\uA48C\uA4D0-\uA4FD\uA500-\uA60C\uA610-\uA61F\uA62A\uA62B\uA640-\uA66E\uA67F-\uA697\uA6A0-\uA6E5\uA717-\uA71F\uA722-\uA788\uA78B-\uA78E\uA790-\uA793\uA7A0-\uA7AA\uA7F8-\uA801\uA803-\uA805\uA807-\uA80A\uA80C-\uA822\uA840-\uA873\uA882-\uA8B3\uA8F2-\uA8F7\uA8FB\uA90A-\uA925\uA930-\uA946\uA960-\uA97C\uA984-\uA9B2\uA9CF\uAA00-\uAA28\uAA40-\uAA42\uAA44-\uAA4B\uAA60-\uAA76\uAA7A\uAA80-\uAAAF\uAAB1\uAAB5\uAAB6\uAAB9-\uAABD\uAAC0\uAAC2\uAADB-\uAADD\uAAE0-\uAAEA\uAAF2-\uAAF4\uAB01-\uAB06\uAB09-\uAB0E\uAB11-\uAB16\uAB20-\uAB26\uAB28-\uAB2E\uABC0-\uABE2\uAC00-\uD7A3\uD7B0-\uD7C6\uD7CB-\uD7FB\uF900-\uFA6D\uFA70-\uFAD9\uFB00-\uFB06\uFB13-\uFB17\uFB1D\uFB1F-\uFB28\uFB2A-\uFB36\uFB38-\uFB3C\uFB3E\uFB40\uFB41\uFB43\uFB44\uFB46-\uFBB1\uFBD3-\uFD3D\uFD50-\uFD8F\uFD92-\uFDC7\uFDF0-\uFDFB\uFE70-\uFE74\uFE76-\uFEFC\uFF21-\uFF3A\uFF41-\uFF5A\uFF66-\uFFBE\uFFC2-\uFFC7\uFFCA-\uFFCF\uFFD2-\uFFD7\uFFDA-\uFFDC]/,
        "*": /./,
      },
      vt =
        (He(xt, [
          {
            key: "reset",
            value: function () {
              (this._isFilled = !1), this.masked.reset();
            },
          },
          {
            key: "remove",
            value: function () {
              var e =
                  0 < arguments.length && void 0 !== arguments[0]
                    ? arguments[0]
                    : 0,
                t =
                  1 < arguments.length && void 0 !== arguments[1]
                    ? arguments[1]
                    : this.value.length;
              return 0 === e && 1 <= t
                ? ((this._isFilled = !1), this.masked.remove(e, t))
                : new rt();
            },
          },
          {
            key: "_appendChar",
            value: function (e) {
              var t =
                1 < arguments.length && void 0 !== arguments[1]
                  ? arguments[1]
                  : {};
              if (this._isFilled) return new rt();
              var n = this.masked.state,
                i = this.masked._appendChar(e, t);
              return (
                i.inserted &&
                  !1 === this.doValidate(t) &&
                  ((i.inserted = i.rawInserted = ""), (this.masked.state = n)),
                i.inserted ||
                  this.isOptional ||
                  this.lazy ||
                  t.input ||
                  (i.inserted = this.placeholderChar),
                (i.skip = !i.inserted && !this.isOptional),
                (this._isFilled = Boolean(i.inserted)),
                i
              );
            },
          },
          {
            key: "append",
            value: function () {
              var e;
              return (e = this.masked).append.apply(e, arguments);
            },
          },
          {
            key: "_appendPlaceholder",
            value: function () {
              var e = new rt();
              return (
                this._isFilled ||
                  this.isOptional ||
                  ((this._isFilled = !0), (e.inserted = this.placeholderChar)),
                e
              );
            },
          },
          {
            key: "extractTail",
            value: function () {
              var e;
              return (e = this.masked).extractTail.apply(e, arguments);
            },
          },
          {
            key: "appendTail",
            value: function () {
              var e;
              return (e = this.masked).appendTail.apply(e, arguments);
            },
          },
          {
            key: "extractInput",
            value: function () {
              var e =
                  0 < arguments.length && void 0 !== arguments[0]
                    ? arguments[0]
                    : 0,
                t =
                  1 < arguments.length && void 0 !== arguments[1]
                    ? arguments[1]
                    : this.value.length,
                n = 2 < arguments.length ? arguments[2] : void 0;
              return this.masked.extractInput(e, t, n);
            },
          },
          {
            key: "nearestInputPos",
            value: function (e) {
              var t =
                  1 < arguments.length && void 0 !== arguments[1]
                    ? arguments[1]
                    : Ze,
                n = this.value.length,
                i = Math.min(Math.max(e, 0), n);
              switch (t) {
                case Je:
                case et:
                  return this.isComplete ? i : 0;
                case tt:
                case nt:
                  return this.isComplete ? i : n;
                case Ze:
                default:
                  return i;
              }
            },
          },
          {
            key: "doValidate",
            value: function () {
              var e, t;
              return (
                (e = this.masked).doValidate.apply(e, arguments) &&
                (!this.parent ||
                  (t = this.parent).doValidate.apply(t, arguments))
              );
            },
          },
          {
            key: "doCommit",
            value: function () {
              this.masked.doCommit();
            },
          },
          {
            key: "value",
            get: function () {
              return (
                this.masked.value ||
                (this._isFilled && !this.isOptional ? this.placeholderChar : "")
              );
            },
          },
          {
            key: "unmaskedValue",
            get: function () {
              return this.masked.unmaskedValue;
            },
          },
          {
            key: "isComplete",
            get: function () {
              return Boolean(this.masked.value) || this.isOptional;
            },
          },
          {
            key: "state",
            get: function () {
              return { masked: this.masked.state, _isFilled: this._isFilled };
            },
            set: function (e) {
              (this.masked.state = e.masked), (this._isFilled = e._isFilled);
            },
          },
        ]),
        xt),
      mt =
        (He(Ct, [
          {
            key: "reset",
            value: function () {
              (this._isRawInput = !1), (this._value = "");
            },
          },
          {
            key: "remove",
            value: function () {
              var e =
                  0 < arguments.length && void 0 !== arguments[0]
                    ? arguments[0]
                    : 0,
                t =
                  1 < arguments.length && void 0 !== arguments[1]
                    ? arguments[1]
                    : this._value.length;
              return (
                (this._value = this._value.slice(0, e) + this._value.slice(t)),
                this._value || (this._isRawInput = !1),
                new rt()
              );
            },
          },
          {
            key: "nearestInputPos",
            value: function (e) {
              var t =
                  1 < arguments.length && void 0 !== arguments[1]
                    ? arguments[1]
                    : Ze,
                n = this._value.length;
              switch (t) {
                case Je:
                case et:
                  return 0;
                case Ze:
                case tt:
                case nt:
                default:
                  return n;
              }
            },
          },
          {
            key: "extractInput",
            value: function () {
              var e =
                  0 < arguments.length && void 0 !== arguments[0]
                    ? arguments[0]
                    : 0,
                t =
                  1 < arguments.length && void 0 !== arguments[1]
                    ? arguments[1]
                    : this._value.length;
              return (
                ((2 < arguments.length && void 0 !== arguments[2]
                  ? arguments[2]
                  : {}
                ).raw &&
                  this._isRawInput &&
                  this._value.slice(e, t)) ||
                ""
              );
            },
          },
          {
            key: "_appendChar",
            value: function (e) {
              var t =
                  1 < arguments.length && void 0 !== arguments[1]
                    ? arguments[1]
                    : {},
                n = new rt();
              if (this._value) return n;
              var i =
                this.char === e[0] &&
                (this.isUnmasking || t.input || t.raw) &&
                !t.tail;
              return (
                i && (n.rawInserted = this.char),
                (this._value = n.inserted = this.char),
                (this._isRawInput = i && (t.raw || t.input)),
                n
              );
            },
          },
          {
            key: "_appendPlaceholder",
            value: function () {
              var e = new rt();
              return this._value || (this._value = e.inserted = this.char), e;
            },
          },
          {
            key: "extractTail",
            value: function () {
              return (
                (1 < arguments.length && void 0 !== arguments[1]) ||
                  this.value.length,
                new st("")
              );
            },
          },
          {
            key: "appendTail",
            value: function (e) {
              return Qe(e) && (e = new st(String(e))), e.appendTo(this);
            },
          },
          {
            key: "append",
            value: function (e, t, n) {
              var i = this._appendChar(e, t);
              return (
                null != n && (i.tailShift += this.appendTail(n).tailShift), i
              );
            },
          },
          { key: "doCommit", value: function () {} },
          {
            key: "value",
            get: function () {
              return this._value;
            },
          },
          {
            key: "unmaskedValue",
            get: function () {
              return this.isUnmasking ? this.value : "";
            },
          },
          {
            key: "isComplete",
            get: function () {
              return !0;
            },
          },
          {
            key: "state",
            get: function () {
              return { _value: this._value, _isRawInput: this._isRawInput };
            },
            set: function (e) {
              Object.assign(this, e);
            },
          },
        ]),
        Ct),
      yt =
        (He(wt, [
          {
            key: "toString",
            value: function () {
              return this.chunks.map(String).join("");
            },
          },
          {
            key: "extend",
            value: function (e) {
              if (String(e)) {
                Qe(e) && (e = new st(String(e)));
                var t = this.chunks[this.chunks.length - 1],
                  n =
                    t &&
                    (t.stop === e.stop || null == e.stop) &&
                    e.from === t.from + t.toString().length;
                if (e instanceof st)
                  n ? t.extend(e.toString()) : this.chunks.push(e);
                else if (e instanceof wt) {
                  if (null == e.stop)
                    for (var i; e.chunks.length && null == e.chunks[0].stop; )
                      ((i = e.chunks.shift()).from += e.from), this.extend(i);
                  e.toString() &&
                    ((e.stop = e.blockIndex), this.chunks.push(e));
                }
              }
            },
          },
          {
            key: "appendTo",
            value: function (e) {
              if (!(e instanceof ct.MaskedPattern))
                return new st(this.toString()).appendTo(e);
              for (
                var t = new rt(), n = 0;
                n < this.chunks.length && !t.skip;
                ++n
              ) {
                var i = this.chunks[n],
                  o = e._mapPosToBlock(e.value.length),
                  r = i.stop,
                  s = void 0;
                if (
                  (r &&
                    (!o || o.index <= r) &&
                    ((i instanceof wt || 0 <= e._stops.indexOf(r)) &&
                      t.aggregate(e._appendPlaceholder(r)),
                    (s = i instanceof wt && e._blocks[r])),
                  s)
                ) {
                  var a = s.appendTail(i);
                  (a.skip = !1), t.aggregate(a), (e._value += a.inserted);
                  var l = i.toString().slice(a.rawInserted.length);
                  l && t.aggregate(e.append(l, { tail: !0 }));
                } else t.aggregate(e.append(i.toString(), { tail: !0 }));
              }
              return t;
            },
          },
          {
            key: "shiftBefore",
            value: function (e) {
              if (this.from >= e || !this.chunks.length) return "";
              for (var t = e - this.from, n = 0; n < this.chunks.length; ) {
                var i = this.chunks[n],
                  o = i.shiftBefore(t);
                if (i.toString()) {
                  if (!o) break;
                  ++n;
                } else this.chunks.splice(n, 1);
                if (o) return o;
              }
              return "";
            },
          },
          {
            key: "state",
            get: function () {
              return {
                chunks: this.chunks.map(function (e) {
                  return e.state;
                }),
                from: this.from,
                stop: this.stop,
                blockIndex: this.blockIndex,
              };
            },
            set: function (e) {
              var t = e.chunks,
                n = Ve(e, ["chunks"]);
              Object.assign(this, n),
                (this.chunks = t.map(function (e) {
                  var t = new ("chunks" in e ? wt : st)();
                  return (t.state = e), t;
                }));
            },
          },
        ]),
        wt),
      kt =
        (qe(bt, dt),
        He(bt, [
          {
            key: "_update",
            value: function () {
              var e =
                0 < arguments.length && void 0 !== arguments[0]
                  ? arguments[0]
                  : {};
              (e.definitions = Object.assign(
                {},
                this.definitions,
                e.definitions
              )),
                Ye(Re(bt.prototype), "_update", this).call(this, e),
                this._rebuildMask();
            },
          },
          {
            key: "_rebuildMask",
            value: function () {
              var o = this,
                e = this.definitions;
              (this._blocks = []),
                (this._stops = []),
                (this._maskedBlocks = {});
              var r = this.mask;
              if (r && e)
                for (var t = !1, n = !1, s = 0; s < r.length; ++s)
                  if (
                    !this.blocks ||
                    "continue" !==
                      (function () {
                        var t = r.slice(s),
                          e = Object.keys(o.blocks).filter(function (e) {
                            return 0 === t.indexOf(e);
                          });
                        e.sort(function (e, t) {
                          return t.length - e.length;
                        });
                        var n = e[0];
                        if (n) {
                          var i = ft(
                            Object.assign(
                              {
                                parent: o,
                                lazy: o.lazy,
                                placeholderChar: o.placeholderChar,
                                overwrite: o.overwrite,
                              },
                              o.blocks[n]
                            )
                          );
                          return (
                            i &&
                              (o._blocks.push(i),
                              o._maskedBlocks[n] || (o._maskedBlocks[n] = []),
                              o._maskedBlocks[n].push(o._blocks.length - 1)),
                            (s += n.length - 1),
                            "continue"
                          );
                        }
                      })()
                  ) {
                    var i = r[s],
                      a = i in e;
                    if (i !== bt.STOP_CHAR)
                      if ("{" !== i && "}" !== i)
                        if ("[" !== i && "]" !== i) {
                          if (i === bt.ESCAPE_CHAR) {
                            if (!(i = r[++s])) break;
                            a = !1;
                          }
                          var l = a
                            ? new vt({
                                parent: this,
                                lazy: this.lazy,
                                placeholderChar: this.placeholderChar,
                                mask: e[i],
                                isOptional: n,
                              })
                            : new mt({ char: i, isUnmasking: t });
                          this._blocks.push(l);
                        } else n = !n;
                      else t = !t;
                    else this._stops.push(this._blocks.length);
                  }
            },
          },
          {
            key: "reset",
            value: function () {
              Ye(Re(bt.prototype), "reset", this).call(this),
                this._blocks.forEach(function (e) {
                  return e.reset();
                });
            },
          },
          {
            key: "doCommit",
            value: function () {
              this._blocks.forEach(function (e) {
                return e.doCommit();
              }),
                Ye(Re(bt.prototype), "doCommit", this).call(this);
            },
          },
          {
            key: "appendTail",
            value: function (e) {
              return Ye(Re(bt.prototype), "appendTail", this)
                .call(this, e)
                .aggregate(this._appendPlaceholder());
            },
          },
          {
            key: "_appendCharRaw",
            value: function (e) {
              var t =
                1 < arguments.length && void 0 !== arguments[1]
                  ? arguments[1]
                  : {};
              e = this.doPrepare(e, t);
              var n = this._mapPosToBlock(this.value.length),
                i = new rt();
              if (!n) return i;
              for (var o = n.index; ; ++o) {
                var r = this._blocks[o];
                if (!r) break;
                var s = r._appendChar(e, t),
                  a = s.skip;
                if ((i.aggregate(s), a || s.rawInserted)) break;
              }
              return i;
            },
          },
          {
            key: "extractTail",
            value: function () {
              var r = this,
                e =
                  0 < arguments.length && void 0 !== arguments[0]
                    ? arguments[0]
                    : 0,
                t =
                  1 < arguments.length && void 0 !== arguments[1]
                    ? arguments[1]
                    : this.value.length,
                s = new yt();
              return (
                e === t ||
                  this._forEachBlocksInRange(e, t, function (e, t, n, i) {
                    var o = e.extractTail(n, i);
                    (o.stop = r._findStopBefore(t)),
                      (o.from = r._blockStartPos(t)),
                      o instanceof yt && (o.blockIndex = t),
                      s.extend(o);
                  }),
                s
              );
            },
          },
          {
            key: "extractInput",
            value: function () {
              var e =
                  0 < arguments.length && void 0 !== arguments[0]
                    ? arguments[0]
                    : 0,
                t =
                  1 < arguments.length && void 0 !== arguments[1]
                    ? arguments[1]
                    : this.value.length,
                o =
                  2 < arguments.length && void 0 !== arguments[2]
                    ? arguments[2]
                    : {};
              if (e === t) return "";
              var r = "";
              return (
                this._forEachBlocksInRange(e, t, function (e, t, n, i) {
                  r += e.extractInput(n, i, o);
                }),
                r
              );
            },
          },
          {
            key: "_findStopBefore",
            value: function (e) {
              for (var t, n = 0; n < this._stops.length; ++n) {
                var i = this._stops[n];
                if (!(i <= e)) break;
                t = i;
              }
              return t;
            },
          },
          {
            key: "_appendPlaceholder",
            value: function (i) {
              var o = this,
                r = new rt();
              if (this.lazy && null == i) return r;
              var e = this._mapPosToBlock(this.value.length);
              if (!e) return r;
              var t = e.index,
                n = null != i ? i : this._blocks.length;
              return (
                this._blocks.slice(t, n).forEach(function (e) {
                  if (!e.lazy || null != i) {
                    var t = null != e._blocks ? [e._blocks.length] : [],
                      n = e._appendPlaceholder.apply(e, t);
                    (o._value += n.inserted), r.aggregate(n);
                  }
                }),
                r
              );
            },
          },
          {
            key: "_mapPosToBlock",
            value: function (e) {
              for (var t = "", n = 0; n < this._blocks.length; ++n) {
                var i = this._blocks[n],
                  o = t.length;
                if (e <= (t += i.value).length)
                  return { index: n, offset: e - o };
              }
            },
          },
          {
            key: "_blockStartPos",
            value: function (e) {
              return this._blocks.slice(0, e).reduce(function (e, t) {
                return e + t.value.length;
              }, 0);
            },
          },
          {
            key: "_forEachBlocksInRange",
            value: function (e) {
              var t =
                  1 < arguments.length && void 0 !== arguments[1]
                    ? arguments[1]
                    : this.value.length,
                n = 2 < arguments.length ? arguments[2] : void 0,
                i = this._mapPosToBlock(e);
              if (i) {
                var o = this._mapPosToBlock(t),
                  r = o && i.index === o.index,
                  s = i.offset,
                  a = o && r ? o.offset : this._blocks[i.index].value.length;
                if ((n(this._blocks[i.index], i.index, s, a), o && !r)) {
                  for (var l = i.index + 1; l < o.index; ++l)
                    n(this._blocks[l], l, 0, this._blocks[l].value.length);
                  n(this._blocks[o.index], o.index, 0, o.offset);
                }
              }
            },
          },
          {
            key: "remove",
            value: function () {
              var e =
                  0 < arguments.length && void 0 !== arguments[0]
                    ? arguments[0]
                    : 0,
                t =
                  1 < arguments.length && void 0 !== arguments[1]
                    ? arguments[1]
                    : this.value.length,
                o = Ye(Re(bt.prototype), "remove", this).call(this, e, t);
              return (
                this._forEachBlocksInRange(e, t, function (e, t, n, i) {
                  o.aggregate(e.remove(n, i));
                }),
                o
              );
            },
          },
          {
            key: "nearestInputPos",
            value: function (e) {
              var t =
                  1 < arguments.length && void 0 !== arguments[1]
                    ? arguments[1]
                    : Ze,
                n = this._mapPosToBlock(e) || { index: 0, offset: 0 },
                i = n.offset,
                o = n.index,
                r = this._blocks[o];
              if (!r) return e;
              var s = i;
              0 !== s &&
                s < r.value.length &&
                (s = r.nearestInputPos(
                  i,
                  (function (e) {
                    switch (e) {
                      case Je:
                        return et;
                      case tt:
                        return nt;
                      default:
                        return e;
                    }
                  })(t)
                ));
              var a = s === r.value.length;
              if (0 !== s && !a) return this._blockStartPos(o) + s;
              var l = a ? o + 1 : o;
              if (t === Ze) {
                if (0 < l) {
                  var u = l - 1,
                    c = this._blocks[u],
                    d = c.nearestInputPos(0, Ze);
                  if (!c.value.length || d !== c.value.length)
                    return this._blockStartPos(l);
                }
                for (var p = l; p < this._blocks.length; ++p) {
                  var h = this._blocks[p],
                    f = h.nearestInputPos(0, Ze);
                  if (!h.value.length || f !== h.value.length)
                    return this._blockStartPos(p) + f;
                }
                for (var g = l - 1; 0 <= g; --g) {
                  var v = this._blocks[g],
                    m = v.nearestInputPos(0, Ze);
                  if (!v.value.length || m !== v.value.length)
                    return this._blockStartPos(g) + v.value.length;
                }
                return e;
              }
              if (t === Je || t === et) {
                for (var y, k = l; k < this._blocks.length; ++k)
                  if (this._blocks[k].value) {
                    y = k;
                    break;
                  }
                if (null != y) {
                  var b = this._blocks[y],
                    w = b.nearestInputPos(0, tt);
                  if (0 === w && b.unmaskedValue.length)
                    return this._blockStartPos(y) + w;
                }
                for (var C, x = -1, S = l - 1; 0 <= S; --S) {
                  var T = this._blocks[S],
                    A = T.nearestInputPos(T.value.length, et);
                  if (((T.value && 0 === A) || (C = S), 0 !== A)) {
                    if (A !== T.value.length) return this._blockStartPos(S) + A;
                    x = S;
                    break;
                  }
                }
                if (t === Je)
                  for (
                    var E = x + 1;
                    E <= Math.min(l, this._blocks.length - 1);
                    ++E
                  ) {
                    var $ = this._blocks[E],
                      _ = $.nearestInputPos(0, Ze),
                      D = this._blockStartPos(E) + _;
                    if (e < D) break;
                    if (_ !== $.value.length) return D;
                  }
                if (0 <= x)
                  return this._blockStartPos(x) + this._blocks[x].value.length;
                if (
                  t === et ||
                  (this.lazy &&
                    !this.extractInput() &&
                    !(function (e) {
                      if (e) {
                        var t = e.value;
                        return !t || e.nearestInputPos(0, Ze) !== t.length;
                      }
                    })(this._blocks[l]))
                )
                  return 0;
                if (null != C) return this._blockStartPos(C);
                for (var F = l; F < this._blocks.length; ++F) {
                  var P = this._blocks[F],
                    j = P.nearestInputPos(0, Ze);
                  if (!P.value.length || j !== P.value.length)
                    return this._blockStartPos(F) + j;
                }
                return 0;
              }
              if (t === tt || t === nt) {
                for (var O, M, B = l; B < this._blocks.length; ++B) {
                  var L = this._blocks[B],
                    I = L.nearestInputPos(0, Ze);
                  if (I !== L.value.length) {
                    (M = this._blockStartPos(B) + I), (O = B);
                    break;
                  }
                }
                if (null != O && null != M) {
                  for (var N = O; N < this._blocks.length; ++N) {
                    var H = this._blocks[N],
                      q = H.nearestInputPos(0, nt);
                    if (q !== H.value.length) return this._blockStartPos(N) + q;
                  }
                  return t === nt ? this.value.length : M;
                }
                for (
                  var R = Math.min(l, this._blocks.length - 1);
                  0 <= R;
                  --R
                ) {
                  var z = this._blocks[R],
                    V = z.nearestInputPos(z.value.length, Je);
                  if (0 !== V) {
                    var W = this._blockStartPos(R) + V;
                    if (e <= W) return W;
                    break;
                  }
                }
              }
              return e;
            },
          },
          {
            key: "maskedBlock",
            value: function (e) {
              return this.maskedBlocks(e)[0];
            },
          },
          {
            key: "maskedBlocks",
            value: function (e) {
              var t = this,
                n = this._maskedBlocks[e];
              return n
                ? n.map(function (e) {
                    return t._blocks[e];
                  })
                : [];
            },
          },
          {
            key: "state",
            get: function () {
              return Object.assign({}, Ye(Re(bt.prototype), "state", this), {
                _blocks: this._blocks.map(function (e) {
                  return e.state;
                }),
              });
            },
            set: function (e) {
              var n = e._blocks,
                t = Ve(e, ["_blocks"]);
              this._blocks.forEach(function (e, t) {
                return (e.state = n[t]);
              }),
                Ge(Re(bt.prototype), "state", t, this, !0);
            },
          },
          {
            key: "isComplete",
            get: function () {
              return this._blocks.every(function (e) {
                return e.isComplete;
              });
            },
          },
          {
            key: "unmaskedValue",
            get: function () {
              return this._blocks.reduce(function (e, t) {
                return e + t.unmaskedValue;
              }, "");
            },
            set: function (e) {
              Ge(Re(bt.prototype), "unmaskedValue", e, this, !0);
            },
          },
          {
            key: "value",
            get: function () {
              return this._blocks.reduce(function (e, t) {
                return e + t.value;
              }, "");
            },
            set: function (e) {
              Ge(Re(bt.prototype), "value", e, this, !0);
            },
          },
        ]),
        bt);
    function bt() {
      var e =
        0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : {};
      return (
        Ie(this, bt),
        (e.definitions = Object.assign({}, gt, e.definitions)),
        We(this, Re(bt).call(this, Object.assign({}, bt.DEFAULTS, {}, e)))
      );
    }
    function wt() {
      var e =
          0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : [],
        t = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : 0;
      Ie(this, wt), (this.chunks = e), (this.from = t);
    }
    function Ct(e) {
      Ie(this, Ct), Object.assign(this, e), (this._value = "");
    }
    function xt(e) {
      Ie(this, xt);
      var t = e.mask,
        n = Ve(e, ["mask"]);
      (this.masked = ft({ mask: t })), Object.assign(this, n);
    }
    (kt.DEFAULTS = { lazy: !0, placeholderChar: "_" }),
      (kt.STOP_CHAR = "`"),
      (kt.ESCAPE_CHAR = "\\"),
      (kt.InputDefinition = vt),
      (kt.FixedDefinition = mt);
    var St =
      (qe(Tt, (ct.MaskedPattern = kt)),
      He(Tt, [
        {
          key: "_update",
          value: function (e) {
            e = Object.assign({ to: this.to || 0, from: this.from || 0 }, e);
            var t = String(e.to).length;
            null != e.maxLength && (t = Math.max(t, e.maxLength)),
              (e.maxLength = t);
            for (
              var n = String(e.from).padStart(t, "0"),
                i = String(e.to).padStart(t, "0"),
                o = 0;
              o < i.length && i[o] === n[o];

            )
              ++o;
            (e.mask = i.slice(0, o).replace(/0/g, "\\0") + "0".repeat(t - o)),
              Ye(Re(Tt.prototype), "_update", this).call(this, e);
          },
        },
        {
          key: "boundaries",
          value: function (e) {
            var t = "",
              n = "",
              i = Ke(e.match(/^(\D*)(\d*)(\D*)/) || [], 3),
              o = i[1],
              r = i[2];
            return (
              r &&
                ((t = "0".repeat(o.length) + r),
                (n = "9".repeat(o.length) + r)),
              [
                (t = t.padEnd(this.maxLength, "0")),
                (n = n.padEnd(this.maxLength, "9")),
              ]
            );
          },
        },
        {
          key: "doPrepare",
          value: function (e) {
            var t =
              1 < arguments.length && void 0 !== arguments[1]
                ? arguments[1]
                : {};
            if (
              ((e = Ye(Re(Tt.prototype), "doPrepare", this)
                .call(this, e, t)
                .replace(/\D/g, "")),
              !this.autofix)
            )
              return e;
            for (
              var n = String(this.from).padStart(this.maxLength, "0"),
                i = String(this.to).padStart(this.maxLength, "0"),
                o = this.value,
                r = "",
                s = 0;
              s < e.length;
              ++s
            ) {
              var a = o + r + e[s],
                l = Ke(this.boundaries(a), 2),
                u = l[0],
                c = l[1];
              Number(c) < this.from
                ? (r += n[a.length - 1])
                : Number(u) > this.to
                ? (r += i[a.length - 1])
                : (r += e[s]);
            }
            return r;
          },
        },
        {
          key: "doValidate",
          value: function () {
            var e,
              t = this.value;
            if (-1 === t.search(/[^0]/) && t.length <= this._matchFrom)
              return !0;
            for (
              var n = Ke(this.boundaries(t), 2),
                i = n[0],
                o = n[1],
                r = arguments.length,
                s = new Array(r),
                a = 0;
              a < r;
              a++
            )
              s[a] = arguments[a];
            return (
              this.from <= Number(o) &&
              Number(i) <= this.to &&
              (e = Ye(Re(Tt.prototype), "doValidate", this)).call.apply(
                e,
                [this].concat(s)
              )
            );
          },
        },
        {
          key: "_matchFrom",
          get: function () {
            return this.maxLength - String(this.from).length;
          },
        },
        {
          key: "isComplete",
          get: function () {
            return (
              Ye(Re(Tt.prototype), "isComplete", this) && Boolean(this.value)
            );
          },
        },
      ]),
      Tt);
    function Tt() {
      return Ie(this, Tt), We(this, Re(Tt).apply(this, arguments));
    }
    ct.MaskedRange = St;
    var At =
      (qe(Et, kt),
      He(Et, [
        {
          key: "_update",
          value: function (n) {
            n.mask === Date && delete n.mask, n.pattern && (n.mask = n.pattern);
            var e = n.blocks;
            (n.blocks = Object.assign({}, Et.GET_DEFAULT_BLOCKS())),
              n.min && (n.blocks.Y.from = n.min.getFullYear()),
              n.max && (n.blocks.Y.to = n.max.getFullYear()),
              n.min &&
                n.max &&
                n.blocks.Y.from === n.blocks.Y.to &&
                ((n.blocks.m.from = n.min.getMonth() + 1),
                (n.blocks.m.to = n.max.getMonth() + 1),
                n.blocks.m.from === n.blocks.m.to &&
                  ((n.blocks.d.from = n.min.getDate()),
                  (n.blocks.d.to = n.max.getDate()))),
              Object.assign(n.blocks, e),
              Object.keys(n.blocks).forEach(function (e) {
                var t = n.blocks[e];
                "autofix" in t || (t.autofix = n.autofix);
              }),
              Ye(Re(Et.prototype), "_update", this).call(this, n);
          },
        },
        {
          key: "doValidate",
          value: function () {
            for (
              var e,
                t = this.date,
                n = arguments.length,
                i = new Array(n),
                o = 0;
              o < n;
              o++
            )
              i[o] = arguments[o];
            return (
              (e = Ye(Re(Et.prototype), "doValidate", this)).call.apply(
                e,
                [this].concat(i)
              ) &&
              (!this.isComplete ||
                (this.isDateExist(this.value) &&
                  null != t &&
                  (null == this.min || this.min <= t) &&
                  (null == this.max || t <= this.max)))
            );
          },
        },
        {
          key: "isDateExist",
          value: function (e) {
            return 0 <= this.format(this.parse(e, this), this).indexOf(e);
          },
        },
        {
          key: "date",
          get: function () {
            return this.typedValue;
          },
          set: function (e) {
            this.typedValue = e;
          },
        },
        {
          key: "typedValue",
          get: function () {
            return this.isComplete
              ? Ye(Re(Et.prototype), "typedValue", this)
              : null;
          },
          set: function (e) {
            Ge(Re(Et.prototype), "typedValue", e, this, !0);
          },
        },
      ]),
      Et);
    function Et(e) {
      return (
        Ie(this, Et),
        We(this, Re(Et).call(this, Object.assign({}, Et.DEFAULTS, {}, e)))
      );
    }
    (At.DEFAULTS = {
      pattern: "d{.}`m{.}`Y",
      format: function (e) {
        return [
          String(e.getDate()).padStart(2, "0"),
          String(e.getMonth() + 1).padStart(2, "0"),
          e.getFullYear(),
        ].join(".");
      },
      parse: function (e) {
        var t = Ke(e.split("."), 3),
          n = t[0],
          i = t[1],
          o = t[2];
        return new Date(o, i - 1, n);
      },
    }),
      (At.GET_DEFAULT_BLOCKS = function () {
        return {
          d: { mask: St, from: 1, to: 31, maxLength: 2 },
          m: { mask: St, from: 1, to: 12, maxLength: 2 },
          Y: { mask: St, from: 1900, to: 9999 },
        };
      }),
      (ct.MaskedDate = At);
    var $t =
      (He(_t, [
        {
          key: "select",
          value: function (e, t) {
            if (
              null != e &&
              null != t &&
              (e !== this.selectionStart || t !== this.selectionEnd)
            )
              try {
                this._unsafeSelect(e, t);
              } catch (e) {}
          },
        },
        { key: "_unsafeSelect", value: function (e, t) {} },
        { key: "bindEvents", value: function (e) {} },
        { key: "unbindEvents", value: function () {} },
        {
          key: "selectionStart",
          get: function () {
            var e;
            try {
              e = this._unsafeSelectionStart;
            } catch (e) {}
            return null != e ? e : this.value.length;
          },
        },
        {
          key: "selectionEnd",
          get: function () {
            var e;
            try {
              e = this._unsafeSelectionEnd;
            } catch (e) {}
            return null != e ? e : this.value.length;
          },
        },
        {
          key: "isActive",
          get: function () {
            return !1;
          },
        },
      ]),
      _t);
    function _t() {
      Ie(this, _t);
    }
    var Dt =
      (qe(Ft, (ct.MaskElement = $t)),
      He(Ft, [
        {
          key: "_unsafeSelect",
          value: function (e, t) {
            this.input.setSelectionRange(e, t);
          },
        },
        {
          key: "bindEvents",
          value: function (t) {
            var n = this;
            Object.keys(t).forEach(function (e) {
              return n._toggleEventHandler(Ft.EVENTS_MAP[e], t[e]);
            });
          },
        },
        {
          key: "unbindEvents",
          value: function () {
            var t = this;
            Object.keys(this._handlers).forEach(function (e) {
              return t._toggleEventHandler(e);
            });
          },
        },
        {
          key: "_toggleEventHandler",
          value: function (e, t) {
            this._handlers[e] &&
              (this.input.removeEventListener(e, this._handlers[e]),
              delete this._handlers[e]),
              t && (this.input.addEventListener(e, t), (this._handlers[e] = t));
          },
        },
        {
          key: "rootElement",
          get: function () {
            return this.input.getRootNode ? this.input.getRootNode() : document;
          },
        },
        {
          key: "isActive",
          get: function () {
            return this.input === this.rootElement.activeElement;
          },
        },
        {
          key: "_unsafeSelectionStart",
          get: function () {
            return this.input.selectionStart;
          },
        },
        {
          key: "_unsafeSelectionEnd",
          get: function () {
            return this.input.selectionEnd;
          },
        },
        {
          key: "value",
          get: function () {
            return this.input.value;
          },
          set: function (e) {
            this.input.value = e;
          },
        },
      ]),
      Ft);
    function Ft(e) {
      var t;
      return (
        Ie(this, Ft),
        ((t = We(this, Re(Ft).call(this))).input = e),
        (t._handlers = {}),
        t
      );
    }
    Dt.EVENTS_MAP = {
      selectionChange: "keydown",
      input: "input",
      drop: "drop",
      click: "click",
      focus: "focus",
      commit: "blur",
    };
    var Pt =
      (qe(jt, (ct.HTMLMaskElement = Dt)),
      He(jt, [
        {
          key: "_unsafeSelect",
          value: function (e, t) {
            if (this.rootElement.createRange) {
              var n = this.rootElement.createRange();
              n.setStart(this.input.firstChild || this.input, e),
                n.setEnd(this.input.lastChild || this.input, t);
              var i = this.rootElement,
                o = i.getSelection && i.getSelection();
              o && (o.removeAllRanges(), o.addRange(n));
            }
          },
        },
        {
          key: "_unsafeSelectionStart",
          get: function () {
            var e = this.rootElement,
              t = e.getSelection && e.getSelection();
            return t && t.anchorOffset;
          },
        },
        {
          key: "_unsafeSelectionEnd",
          get: function () {
            var e = this.rootElement,
              t = e.getSelection && e.getSelection();
            return t && this._unsafeSelectionStart + String(t).length;
          },
        },
        {
          key: "value",
          get: function () {
            return this.input.textContent;
          },
          set: function (e) {
            this.input.textContent = e;
          },
        },
      ]),
      jt);
    function jt() {
      return Ie(this, jt), We(this, Re(jt).apply(this, arguments));
    }
    ct.HTMLContenteditableMaskElement = Pt;
    var Ot =
      (He(Mt, [
        {
          key: "maskEquals",
          value: function (e) {
            return (
              null == e ||
              e === this.masked.mask ||
              (e === Date && this.masked instanceof At)
            );
          },
        },
        {
          key: "_bindEvents",
          value: function () {
            this.el.bindEvents({
              selectionChange: this._saveSelection,
              input: this._onInput,
              drop: this._onDrop,
              click: this._onClick,
              focus: this._onFocus,
              commit: this._onChange,
            });
          },
        },
        {
          key: "_unbindEvents",
          value: function () {
            this.el && this.el.unbindEvents();
          },
        },
        {
          key: "_fireEvent",
          value: function (e) {
            var t = this._listeners[e];
            t &&
              t.forEach(function (e) {
                return e();
              });
          },
        },
        {
          key: "_saveSelection",
          value: function () {
            this.value !== this.el.value &&
              console.warn(
                "Element value was changed outside of mask. Syncronize mask using `mask.updateValue()` to work properly."
              ),
              (this._selection = {
                start: this.selectionStart,
                end: this.cursorPos,
              });
          },
        },
        {
          key: "updateValue",
          value: function () {
            (this.masked.value = this.el.value),
              (this._value = this.masked.value);
          },
        },
        {
          key: "updateControl",
          value: function () {
            var e = this.masked.unmaskedValue,
              t = this.masked.value,
              n = this.unmaskedValue !== e || this.value !== t;
            (this._unmaskedValue = e),
              (this._value = t),
              this.el.value !== t && (this.el.value = t),
              n && this._fireChangeEvents();
          },
        },
        {
          key: "updateOptions",
          value: function (e) {
            var t = e.mask,
              n = Ve(e, ["mask"]),
              i = !this.maskEquals(t),
              o = !(function e(t, n) {
                if (n === t) return 1;
                var i,
                  o = Array.isArray(n),
                  r = Array.isArray(t);
                if (o && r) {
                  if (n.length != t.length) return;
                  for (i = 0; i < n.length; i++) if (!e(n[i], t[i])) return;
                  return 1;
                }
                if (o == r) {
                  if (n && t && "object" === Le(n) && "object" === Le(t)) {
                    var s = n instanceof Date,
                      a = t instanceof Date;
                    if (s && a) return n.getTime() == t.getTime();
                    if (s != a) return;
                    var l = n instanceof RegExp,
                      u = t instanceof RegExp;
                    if (l && u) return n.toString() == t.toString();
                    if (l != u) return;
                    var c = Object.keys(n);
                    for (i = 0; i < c.length; i++)
                      if (!Object.prototype.hasOwnProperty.call(t, c[i]))
                        return;
                    for (i = 0; i < c.length; i++)
                      if (!e(t[c[i]], n[c[i]])) return;
                    return 1;
                  }
                  return (
                    n &&
                    t &&
                    "function" == typeof n &&
                    "function" == typeof t &&
                    n.toString() === t.toString()
                  );
                }
              })(this.masked, n);
            i && (this.mask = t),
              o && this.masked.updateOptions(n),
              (i || o) && this.updateControl();
          },
        },
        {
          key: "updateCursor",
          value: function (e) {
            null != e && ((this.cursorPos = e), this._delayUpdateCursor(e));
          },
        },
        {
          key: "_delayUpdateCursor",
          value: function (e) {
            var t = this;
            this._abortUpdateCursor(),
              (this._changingCursorPos = e),
              (this._cursorChanging = setTimeout(function () {
                t.el &&
                  ((t.cursorPos = t._changingCursorPos),
                  t._abortUpdateCursor());
              }, 10));
          },
        },
        {
          key: "_fireChangeEvents",
          value: function () {
            this._fireEvent("accept"),
              this.masked.isComplete && this._fireEvent("complete");
          },
        },
        {
          key: "_abortUpdateCursor",
          value: function () {
            this._cursorChanging &&
              (clearTimeout(this._cursorChanging), delete this._cursorChanging);
          },
        },
        {
          key: "alignCursor",
          value: function () {
            this.cursorPos = this.masked.nearestInputPos(this.cursorPos, Je);
          },
        },
        {
          key: "alignCursorFriendly",
          value: function () {
            this.selectionStart === this.cursorPos && this.alignCursor();
          },
        },
        {
          key: "on",
          value: function (e, t) {
            return (
              this._listeners[e] || (this._listeners[e] = []),
              this._listeners[e].push(t),
              this
            );
          },
        },
        {
          key: "off",
          value: function (e, t) {
            if (!this._listeners[e]) return this;
            if (!t) return delete this._listeners[e], this;
            var n = this._listeners[e].indexOf(t);
            return 0 <= n && this._listeners[e].splice(n, 1), this;
          },
        },
        {
          key: "_onInput",
          value: function () {
            if ((this._abortUpdateCursor(), !this._selection))
              return this.updateValue();
            var e = new ot(
                this.el.value,
                this.cursorPos,
                this.value,
                this._selection
              ),
              t = this.masked.rawInputValue,
              n = this.masked.splice(
                e.startChangePos,
                e.removed.length,
                e.inserted,
                e.removeDirection
              ).offset,
              i = t === this.masked.rawInputValue ? e.removeDirection : Ze,
              o = this.masked.nearestInputPos(e.startChangePos + n, i);
            this.updateControl(), this.updateCursor(o);
          },
        },
        {
          key: "_onChange",
          value: function () {
            this.value !== this.el.value && this.updateValue(),
              this.masked.doCommit(),
              this.updateControl(),
              this._saveSelection();
          },
        },
        {
          key: "_onDrop",
          value: function (e) {
            e.preventDefault(), e.stopPropagation();
          },
        },
        {
          key: "_onFocus",
          value: function (e) {
            this.alignCursorFriendly();
          },
        },
        {
          key: "_onClick",
          value: function (e) {
            this.alignCursorFriendly();
          },
        },
        {
          key: "destroy",
          value: function () {
            this._unbindEvents(), (this._listeners.length = 0), delete this.el;
          },
        },
        {
          key: "mask",
          get: function () {
            return this.masked.mask;
          },
          set: function (e) {
            if (!this.maskEquals(e))
              if (this.masked.constructor !== ht(e)) {
                var t = ft({ mask: e });
                (t.unmaskedValue = this.masked.unmaskedValue),
                  (this.masked = t);
              } else this.masked.updateOptions({ mask: e });
          },
        },
        {
          key: "value",
          get: function () {
            return this._value;
          },
          set: function (e) {
            (this.masked.value = e), this.updateControl(), this.alignCursor();
          },
        },
        {
          key: "unmaskedValue",
          get: function () {
            return this._unmaskedValue;
          },
          set: function (e) {
            (this.masked.unmaskedValue = e),
              this.updateControl(),
              this.alignCursor();
          },
        },
        {
          key: "typedValue",
          get: function () {
            return this.masked.typedValue;
          },
          set: function (e) {
            (this.masked.typedValue = e),
              this.updateControl(),
              this.alignCursor();
          },
        },
        {
          key: "selectionStart",
          get: function () {
            return this._cursorChanging
              ? this._changingCursorPos
              : this.el.selectionStart;
          },
        },
        {
          key: "cursorPos",
          get: function () {
            return this._cursorChanging
              ? this._changingCursorPos
              : this.el.selectionEnd;
          },
          set: function (e) {
            this.el.isActive && (this.el.select(e, e), this._saveSelection());
          },
        },
      ]),
      Mt);
    function Mt(e, t) {
      Ie(this, Mt),
        (this.el =
          e instanceof $t
            ? e
            : new (e.isContentEditable &&
              "INPUT" !== e.tagName &&
              "TEXTAREA" !== e.tagName
                ? Pt
                : Dt)(e)),
        (this.masked = ft(t)),
        (this._listeners = {}),
        (this._value = ""),
        (this._unmaskedValue = ""),
        (this._saveSelection = this._saveSelection.bind(this)),
        (this._onInput = this._onInput.bind(this)),
        (this._onChange = this._onChange.bind(this)),
        (this._onDrop = this._onDrop.bind(this)),
        (this._onFocus = this._onFocus.bind(this)),
        (this._onClick = this._onClick.bind(this)),
        (this.alignCursor = this.alignCursor.bind(this)),
        (this.alignCursorFriendly = this.alignCursorFriendly.bind(this)),
        this._bindEvents(),
        this.updateValue(),
        this._onChange();
    }
    ct.InputMask = Ot;
    var Bt =
      (qe(Lt, kt),
      He(Lt, [
        {
          key: "_update",
          value: function (e) {
            e.enum && (e.mask = "*".repeat(e.enum[0].length)),
              Ye(Re(Lt.prototype), "_update", this).call(this, e);
          },
        },
        {
          key: "doValidate",
          value: function () {
            for (
              var e, t = this, n = arguments.length, i = new Array(n), o = 0;
              o < n;
              o++
            )
              i[o] = arguments[o];
            return (
              this.enum.some(function (e) {
                return 0 <= e.indexOf(t.unmaskedValue);
              }) &&
              (e = Ye(Re(Lt.prototype), "doValidate", this)).call.apply(
                e,
                [this].concat(i)
              )
            );
          },
        },
      ]),
      Lt);
    function Lt() {
      return Ie(this, Lt), We(this, Re(Lt).apply(this, arguments));
    }
    ct.MaskedEnum = Bt;
    var It =
      (qe(Nt, dt),
      He(Nt, [
        {
          key: "_update",
          value: function (e) {
            Ye(Re(Nt.prototype), "_update", this).call(this, e),
              this._updateRegExps();
          },
        },
        {
          key: "_updateRegExps",
          value: function () {
            var e = "^" + (this.allowNegative ? "[+|\\-]?" : ""),
              t =
                (this.scale
                  ? "(" + it(this.radix) + "\\d{0," + this.scale + "})?"
                  : "") + "$";
            (this._numberRegExpInput = new RegExp(e + "(0|([1-9]+\\d*))?" + t)),
              (this._numberRegExp = new RegExp(e + "\\d*" + t)),
              (this._mapToRadixRegExp = new RegExp(
                "[" + this.mapToRadix.map(it).join("") + "]",
                "g"
              )),
              (this._thousandsSeparatorRegExp = new RegExp(
                it(this.thousandsSeparator),
                "g"
              ));
          },
        },
        {
          key: "_removeThousandsSeparators",
          value: function (e) {
            return e.replace(this._thousandsSeparatorRegExp, "");
          },
        },
        {
          key: "_insertThousandsSeparators",
          value: function (e) {
            var t = e.split(this.radix);
            return (
              (t[0] = t[0].replace(
                /\B(?=(\d{3})+(?!\d))/g,
                this.thousandsSeparator
              )),
              t.join(this.radix)
            );
          },
        },
        {
          key: "doPrepare",
          value: function (e) {
            for (
              var t,
                n = arguments.length,
                i = new Array(1 < n ? n - 1 : 0),
                o = 1;
              o < n;
              o++
            )
              i[o - 1] = arguments[o];
            return (t = Ye(Re(Nt.prototype), "doPrepare", this)).call.apply(
              t,
              [
                this,
                this._removeThousandsSeparators(
                  e.replace(this._mapToRadixRegExp, this.radix)
                ),
              ].concat(i)
            );
          },
        },
        {
          key: "_separatorsCount",
          value: function (e) {
            for (
              var t =
                  1 < arguments.length &&
                  void 0 !== arguments[1] &&
                  arguments[1],
                n = 0,
                i = 0;
              i < e;
              ++i
            )
              this._value.indexOf(this.thousandsSeparator, i) === i &&
                (++n, t && (e += this.thousandsSeparator.length));
            return n;
          },
        },
        {
          key: "_separatorsCountFromSlice",
          value: function () {
            var e =
              0 < arguments.length && void 0 !== arguments[0]
                ? arguments[0]
                : this._value;
            return this._separatorsCount(
              this._removeThousandsSeparators(e).length,
              !0
            );
          },
        },
        {
          key: "extractInput",
          value: function () {
            var e =
                0 < arguments.length && void 0 !== arguments[0]
                  ? arguments[0]
                  : 0,
              t =
                1 < arguments.length && void 0 !== arguments[1]
                  ? arguments[1]
                  : this.value.length,
              n = 2 < arguments.length ? arguments[2] : void 0,
              i = Ke(this._adjustRangeWithSeparators(e, t), 2);
            return (
              (e = i[0]),
              (t = i[1]),
              this._removeThousandsSeparators(
                Ye(Re(Nt.prototype), "extractInput", this).call(this, e, t, n)
              )
            );
          },
        },
        {
          key: "_appendCharRaw",
          value: function (e) {
            var t =
              1 < arguments.length && void 0 !== arguments[1]
                ? arguments[1]
                : {};
            if (!this.thousandsSeparator)
              return Ye(Re(Nt.prototype), "_appendCharRaw", this).call(
                this,
                e,
                t
              );
            var n =
                t.tail && t._beforeTailState
                  ? t._beforeTailState._value
                  : this._value,
              i = this._separatorsCountFromSlice(n);
            this._value = this._removeThousandsSeparators(this.value);
            var o = Ye(Re(Nt.prototype), "_appendCharRaw", this).call(
              this,
              e,
              t
            );
            this._value = this._insertThousandsSeparators(this._value);
            var r =
                t.tail && t._beforeTailState
                  ? t._beforeTailState._value
                  : this._value,
              s = this._separatorsCountFromSlice(r);
            return (o.tailShift += (s - i) * this.thousandsSeparator.length), o;
          },
        },
        {
          key: "_findSeparatorAround",
          value: function (e) {
            if (this.thousandsSeparator) {
              var t = e - this.thousandsSeparator.length + 1,
                n = this.value.indexOf(this.thousandsSeparator, t);
              if (n <= e) return n;
            }
            return -1;
          },
        },
        {
          key: "_adjustRangeWithSeparators",
          value: function (e, t) {
            var n = this._findSeparatorAround(e);
            0 <= n && (e = n);
            var i = this._findSeparatorAround(t);
            return 0 <= i && (t = i + this.thousandsSeparator.length), [e, t];
          },
        },
        {
          key: "remove",
          value: function () {
            var e =
                0 < arguments.length && void 0 !== arguments[0]
                  ? arguments[0]
                  : 0,
              t =
                1 < arguments.length && void 0 !== arguments[1]
                  ? arguments[1]
                  : this.value.length,
              n = Ke(this._adjustRangeWithSeparators(e, t), 2);
            (e = n[0]), (t = n[1]);
            var i = this.value.slice(0, e),
              o = this.value.slice(t),
              r = this._separatorsCount(i.length);
            this._value = this._insertThousandsSeparators(
              this._removeThousandsSeparators(i + o)
            );
            var s = this._separatorsCountFromSlice(i);
            return new rt({
              tailShift: (s - r) * this.thousandsSeparator.length,
            });
          },
        },
        {
          key: "nearestInputPos",
          value: function (e, t) {
            if (!this.thousandsSeparator) return e;
            switch (t) {
              case Ze:
              case Je:
              case et:
                var n = this._findSeparatorAround(e - 1);
                if (0 <= n) {
                  var i = n + this.thousandsSeparator.length;
                  if (e < i || this.value.length <= i || t === et) return n;
                }
                break;
              case tt:
              case nt:
                var o = this._findSeparatorAround(e);
                if (0 <= o) return o + this.thousandsSeparator.length;
            }
            return e;
          },
        },
        {
          key: "doValidate",
          value: function (e) {
            var t = (e.input
              ? this._numberRegExpInput
              : this._numberRegExp
            ).test(this._removeThousandsSeparators(this.value));
            if (t) {
              var n = this.number;
              t =
                t &&
                !isNaN(n) &&
                (null == this.min ||
                  0 <= this.min ||
                  this.min <= this.number) &&
                (null == this.max || this.max <= 0 || this.number <= this.max);
            }
            return t && Ye(Re(Nt.prototype), "doValidate", this).call(this, e);
          },
        },
        {
          key: "doCommit",
          value: function () {
            if (this.value) {
              var e = this.number,
                t = e;
              null != this.min && (t = Math.max(t, this.min)),
                null != this.max && (t = Math.min(t, this.max)),
                t !== e && (this.unmaskedValue = String(t));
              var n = this.value;
              this.normalizeZeros && (n = this._normalizeZeros(n)),
                this.padFractionalZeros && (n = this._padFractionalZeros(n)),
                (this._value = n);
            }
            Ye(Re(Nt.prototype), "doCommit", this).call(this);
          },
        },
        {
          key: "_normalizeZeros",
          value: function (e) {
            var t = this._removeThousandsSeparators(e).split(this.radix);
            return (
              (t[0] = t[0].replace(/^(\D*)(0*)(\d*)/, function (e, t, n, i) {
                return t + i;
              })),
              e.length && !/\d$/.test(t[0]) && (t[0] = t[0] + "0"),
              1 < t.length &&
                ((t[1] = t[1].replace(/0*$/, "")),
                t[1].length || (t.length = 1)),
              this._insertThousandsSeparators(t.join(this.radix))
            );
          },
        },
        {
          key: "_padFractionalZeros",
          value: function (e) {
            if (!e) return e;
            var t = e.split(this.radix);
            return (
              t.length < 2 && t.push(""),
              (t[1] = t[1].padEnd(this.scale, "0")),
              t.join(this.radix)
            );
          },
        },
        {
          key: "unmaskedValue",
          get: function () {
            return this._removeThousandsSeparators(
              this._normalizeZeros(this.value)
            ).replace(this.radix, ".");
          },
          set: function (e) {
            Ge(
              Re(Nt.prototype),
              "unmaskedValue",
              e.replace(".", this.radix),
              this,
              !0
            );
          },
        },
        {
          key: "typedValue",
          get: function () {
            return Number(this.unmaskedValue);
          },
          set: function (e) {
            Ge(Re(Nt.prototype), "unmaskedValue", String(e), this, !0);
          },
        },
        {
          key: "number",
          get: function () {
            return this.typedValue;
          },
          set: function (e) {
            this.typedValue = e;
          },
        },
        {
          key: "allowNegative",
          get: function () {
            return (
              this.signed ||
              (null != this.min && this.min < 0) ||
              (null != this.max && this.max < 0)
            );
          },
        },
      ]),
      Nt);
    function Nt(e) {
      return (
        Ie(this, Nt),
        We(this, Re(Nt).call(this, Object.assign({}, Nt.DEFAULTS, {}, e)))
      );
    }
    (It.DEFAULTS = {
      radix: ",",
      thousandsSeparator: "",
      mapToRadix: ["."],
      scale: 2,
      signed: !1,
      normalizeZeros: !0,
      padFractionalZeros: !1,
    }),
      (ct.MaskedNumber = It);
    var Ht =
      (qe(qt, dt),
      He(qt, [
        {
          key: "_update",
          value: function (t) {
            t.mask &&
              (t.validate = function (e) {
                return 0 <= e.search(t.mask);
              }),
              Ye(Re(qt.prototype), "_update", this).call(this, t);
          },
        },
      ]),
      qt);
    function qt() {
      return Ie(this, qt), We(this, Re(qt).apply(this, arguments));
    }
    ct.MaskedRegExp = Ht;
    var Rt =
      (qe(zt, dt),
      He(zt, [
        {
          key: "_update",
          value: function (e) {
            e.mask && (e.validate = e.mask),
              Ye(Re(zt.prototype), "_update", this).call(this, e);
          },
        },
      ]),
      zt);
    function zt() {
      return Ie(this, zt), We(this, Re(zt).apply(this, arguments));
    }
    ct.MaskedFunction = Rt;
    var Vt =
      (qe(Wt, dt),
      He(Wt, [
        {
          key: "_update",
          value: function (e) {
            Ye(Re(Wt.prototype), "_update", this).call(this, e),
              "mask" in e &&
                (this.compiledMasks = Array.isArray(e.mask)
                  ? e.mask.map(function (e) {
                      return ft(e);
                    })
                  : []);
          },
        },
        {
          key: "_appendCharRaw",
          value: function () {
            var e,
              t = this._applyDispatch.apply(this, arguments);
            return (
              this.currentMask &&
                t.aggregate(
                  (e = this.currentMask)._appendChar.apply(e, arguments)
                ),
              t
            );
          },
        },
        {
          key: "_applyDispatch",
          value: function () {
            var e =
                0 < arguments.length && void 0 !== arguments[0]
                  ? arguments[0]
                  : "",
              t =
                1 < arguments.length && void 0 !== arguments[1]
                  ? arguments[1]
                  : {},
              n =
                t.tail && null != t._beforeTailState
                  ? t._beforeTailState._value
                  : this.value,
              i = this.rawInputValue,
              o =
                t.tail && null != t._beforeTailState
                  ? t._beforeTailState._rawInputValue
                  : i,
              r = i.slice(o.length),
              s = this.currentMask,
              a = new rt(),
              l = s && s.state;
            if (
              ((this.currentMask = this.doDispatch(e, Object.assign({}, t))),
              this.currentMask)
            )
              if (this.currentMask !== s) {
                this.currentMask.reset();
                var u = this.currentMask.append(o, { raw: !0 });
                (a.tailShift = u.inserted.length - n.length),
                  r &&
                    (a.tailShift += this.currentMask.append(r, {
                      raw: !0,
                      tail: !0,
                    }).tailShift);
              } else this.currentMask.state = l;
            return a;
          },
        },
        {
          key: "_appendPlaceholder",
          value: function () {
            var e = this._applyDispatch.apply(this, arguments);
            return (
              this.currentMask &&
                e.aggregate(this.currentMask._appendPlaceholder()),
              e
            );
          },
        },
        {
          key: "doDispatch",
          value: function (e) {
            var t =
              1 < arguments.length && void 0 !== arguments[1]
                ? arguments[1]
                : {};
            return this.dispatch(e, this, t);
          },
        },
        {
          key: "doValidate",
          value: function () {
            for (
              var e, t, n = arguments.length, i = new Array(n), o = 0;
              o < n;
              o++
            )
              i[o] = arguments[o];
            return (
              (e = Ye(Re(Wt.prototype), "doValidate", this)).call.apply(
                e,
                [this].concat(i)
              ) &&
              (!this.currentMask ||
                (t = this.currentMask).doValidate.apply(t, i))
            );
          },
        },
        {
          key: "reset",
          value: function () {
            this.currentMask && this.currentMask.reset(),
              this.compiledMasks.forEach(function (e) {
                return e.reset();
              });
          },
        },
        {
          key: "remove",
          value: function () {
            var e,
              t = new rt();
            return (
              this.currentMask &&
                t
                  .aggregate((e = this.currentMask).remove.apply(e, arguments))
                  .aggregate(this._applyDispatch()),
              t
            );
          },
        },
        {
          key: "extractInput",
          value: function () {
            var e;
            return this.currentMask
              ? (e = this.currentMask).extractInput.apply(e, arguments)
              : "";
          },
        },
        {
          key: "extractTail",
          value: function () {
            for (
              var e, t, n = arguments.length, i = new Array(n), o = 0;
              o < n;
              o++
            )
              i[o] = arguments[o];
            return this.currentMask
              ? (e = this.currentMask).extractTail.apply(e, i)
              : (t = Ye(Re(Wt.prototype), "extractTail", this)).call.apply(
                  t,
                  [this].concat(i)
                );
          },
        },
        {
          key: "doCommit",
          value: function () {
            this.currentMask && this.currentMask.doCommit(),
              Ye(Re(Wt.prototype), "doCommit", this).call(this);
          },
        },
        {
          key: "nearestInputPos",
          value: function () {
            for (
              var e, t, n = arguments.length, i = new Array(n), o = 0;
              o < n;
              o++
            )
              i[o] = arguments[o];
            return this.currentMask
              ? (e = this.currentMask).nearestInputPos.apply(e, i)
              : (t = Ye(Re(Wt.prototype), "nearestInputPos", this)).call.apply(
                  t,
                  [this].concat(i)
                );
          },
        },
        {
          key: "value",
          get: function () {
            return this.currentMask ? this.currentMask.value : "";
          },
          set: function (e) {
            Ge(Re(Wt.prototype), "value", e, this, !0);
          },
        },
        {
          key: "unmaskedValue",
          get: function () {
            return this.currentMask ? this.currentMask.unmaskedValue : "";
          },
          set: function (e) {
            Ge(Re(Wt.prototype), "unmaskedValue", e, this, !0);
          },
        },
        {
          key: "typedValue",
          get: function () {
            return this.currentMask ? this.currentMask.typedValue : "";
          },
          set: function (e) {
            var t = String(e);
            this.currentMask &&
              ((this.currentMask.typedValue = e),
              (t = this.currentMask.unmaskedValue)),
              (this.unmaskedValue = t);
          },
        },
        {
          key: "isComplete",
          get: function () {
            return !!this.currentMask && this.currentMask.isComplete;
          },
        },
        {
          key: "state",
          get: function () {
            return Object.assign({}, Ye(Re(Wt.prototype), "state", this), {
              _rawInputValue: this.rawInputValue,
              compiledMasks: this.compiledMasks.map(function (e) {
                return e.state;
              }),
              currentMaskRef: this.currentMask,
              currentMask: this.currentMask && this.currentMask.state,
            });
          },
          set: function (e) {
            var n = e.compiledMasks,
              t = e.currentMaskRef,
              i = e.currentMask,
              o = Ve(e, ["compiledMasks", "currentMaskRef", "currentMask"]);
            this.compiledMasks.forEach(function (e, t) {
              return (e.state = n[t]);
            }),
              null != t &&
                ((this.currentMask = t), (this.currentMask.state = i)),
              Ge(Re(Wt.prototype), "state", o, this, !0);
          },
        },
        {
          key: "overwrite",
          get: function () {
            return this.currentMask
              ? this.currentMask.overwrite
              : Ye(Re(Wt.prototype), "overwrite", this);
          },
          set: function (e) {
            console.warn(
              '"overwrite" option is not available in dynamic mask, use this option in siblings'
            );
          },
        },
      ]),
      Wt);
    function Wt(e) {
      var t;
      return (
        Ie(this, Wt),
        ((t = We(
          this,
          Re(Wt).call(this, Object.assign({}, Wt.DEFAULTS, {}, e))
        )).currentMask = null),
        t
      );
    }
    (Vt.DEFAULTS = {
      dispatch: function (n, e, i) {
        if (e.compiledMasks.length) {
          var o = e.rawInputValue,
            t = e.compiledMasks.map(function (e, t) {
              return (
                e.reset(),
                e.append(o, { raw: !0 }),
                e.append(n, i),
                { weight: e.rawInputValue.length, index: t }
              );
            });
          return (
            t.sort(function (e, t) {
              return t.weight - e.weight;
            }),
            e.compiledMasks[t[0].index]
          );
        }
      },
    }),
      (ct.MaskedDynamic = Vt);
    var Xt = {
      MASKED: "value",
      UNMASKED: "unmaskedValue",
      TYPED: "typedValue",
    };
    function Yt(e) {
      var n =
          1 < arguments.length && void 0 !== arguments[1]
            ? arguments[1]
            : Xt.MASKED,
        i =
          2 < arguments.length && void 0 !== arguments[2]
            ? arguments[2]
            : Xt.MASKED,
        o = ft(e);
      return function (t) {
        return o.runIsolated(function (e) {
          return (e[n] = t), e[i];
        });
      };
    }
    function Ut(e) {
      for (
        var t = arguments.length, n = new Array(1 < t ? t - 1 : 0), i = 1;
        i < t;
        i++
      )
        n[i - 1] = arguments[i];
      return Yt.apply(void 0, n)(e);
    }
    (ct.PIPE_TYPE = Xt),
      (ct.createPipe = Yt),
      (ct.pipe = Ut),
      (globalThis.IMask = ct),
      (e.HTMLContenteditableMaskElement = Pt),
      (e.HTMLMaskElement = Dt),
      (e.InputMask = Ot),
      (e.MaskElement = $t),
      (e.Masked = dt),
      (e.MaskedDate = At),
      (e.MaskedDynamic = Vt),
      (e.MaskedEnum = Bt),
      (e.MaskedFunction = Rt),
      (e.MaskedNumber = It),
      (e.MaskedPattern = kt),
      (e.MaskedRange = St),
      (e.MaskedRegExp = Ht),
      (e.PIPE_TYPE = Xt),
      (e.createMask = ft),
      (e.createPipe = Yt),
      (e.default = ct),
      (e.pipe = Ut),
      Object.defineProperty(e, "__esModule", { value: !0 });
  }),
  (function (e, t) {
    "function" == typeof define && define.amd
      ? define(["jquery"], function (e) {
          return t(e);
        })
      : "object" == typeof module && module.exports
      ? (module.exports = t(require("jquery")))
      : t(e.jQuery);
  })(this, function (g) {
    !(function () {
      "use strict";
      function t(e, t) {
        if (
          ((this.el = e),
          (this.$el = g(e)),
          (this.s = g.extend({}, n, t)),
          this.s.dynamic &&
            "undefined" !== this.s.dynamicEl &&
            this.s.dynamicEl.constructor === Array &&
            !this.s.dynamicEl.length)
        )
          throw "When using dynamic mode, you must also define dynamicEl as an Array.";
        return (
          (this.modules = {}),
          (this.lGalleryOn = !1),
          (this.lgBusy = !1),
          (this.hideBartimeout = !1),
          (this.isTouch = "ontouchstart" in document.documentElement),
          this.s.slideEndAnimatoin && (this.s.hideControlOnEnd = !1),
          this.s.dynamic
            ? (this.$items = this.s.dynamicEl)
            : "this" === this.s.selector
            ? (this.$items = this.$el)
            : "" !== this.s.selector
            ? this.s.selectWithin
              ? (this.$items = g(this.s.selectWithin).find(this.s.selector))
              : (this.$items = this.$el.find(g(this.s.selector)))
            : (this.$items = this.$el.children()),
          (this.$slide = ""),
          (this.$outer = ""),
          this.init(),
          this
        );
      }
      var n = {
        mode: "lg-slide",
        cssEasing: "ease",
        easing: "linear",
        speed: 600,
        height: "100%",
        width: "100%",
        addClass: "",
        startClass: "lg-start-zoom",
        backdropDuration: 150,
        hideBarsDelay: 6e3,
        useLeft: !1,
        closable: !0,
        loop: !0,
        escKey: !0,
        keyPress: !0,
        controls: !0,
        slideEndAnimatoin: !0,
        hideControlOnEnd: !1,
        mousewheel: !0,
        getCaptionFromTitleOrAlt: !0,
        appendSubHtmlTo: ".lg-sub-html",
        subHtmlSelectorRelative: !1,
        preload: 1,
        showAfterLoad: !0,
        selector: "",
        selectWithin: "",
        nextHtml: "",
        prevHtml: "",
        index: !1,
        iframeMaxWidth: "100%",
        download: !0,
        counter: !0,
        appendCounterTo: ".lg-toolbar",
        swipeThreshold: 50,
        enableSwipe: !0,
        enableDrag: !0,
        dynamic: !1,
        dynamicEl: [],
        galleryId: 1,
      };
      (t.prototype.init = function () {
        var e = this;
        e.s.preload > e.$items.length && (e.s.preload = e.$items.length);
        var t = window.location.hash;
        0 < t.indexOf("lg=" + this.s.galleryId) &&
          ((e.index = parseInt(t.split("&slide=")[1], 10)),
          g("body").addClass("lg-from-hash"),
          g("body").hasClass("lg-on") ||
            (setTimeout(function () {
              e.build(e.index);
            }),
            g("body").addClass("lg-on"))),
          e.s.dynamic
            ? (e.$el.trigger("onBeforeOpen.lg"),
              (e.index = e.s.index || 0),
              g("body").hasClass("lg-on") ||
                setTimeout(function () {
                  e.build(e.index), g("body").addClass("lg-on");
                }))
            : e.$items.on("click.lgcustom", function (t) {
                try {
                  t.preventDefault(), t.preventDefault();
                } catch (e) {
                  t.returnValue = !1;
                }
                e.$el.trigger("onBeforeOpen.lg"),
                  (e.index = e.s.index || e.$items.index(this)),
                  g("body").hasClass("lg-on") ||
                    (e.build(e.index), g("body").addClass("lg-on"));
              });
      }),
        (t.prototype.build = function (e) {
          var t = this;
          t.structure(),
            g.each(g.fn.lightGallery.modules, function (e) {
              t.modules[e] = new g.fn.lightGallery.modules[e](t.el);
            }),
            t.slide(e, !1, !1, !1),
            t.s.keyPress && t.keyPress(),
            1 < t.$items.length
              ? (t.arrow(),
                setTimeout(function () {
                  t.enableDrag(), t.enableSwipe();
                }, 50),
                t.s.mousewheel && t.mousewheel())
              : t.$slide.on("click.lg", function () {
                  t.$el.trigger("onSlideClick.lg");
                }),
            t.counter(),
            t.closeGallery(),
            t.$el.trigger("onAfterOpen.lg"),
            t.$outer.on("mousemove.lg click.lg touchstart.lg", function () {
              t.$outer.removeClass("lg-hide-items"),
                clearTimeout(t.hideBartimeout),
                (t.hideBartimeout = setTimeout(function () {
                  t.$outer.addClass("lg-hide-items");
                }, t.s.hideBarsDelay));
            }),
            t.$outer.trigger("mousemove.lg");
        }),
        (t.prototype.structure = function () {
          var e,
            t = "",
            n = "",
            i = 0,
            o = "",
            r = this;
          for (
            g("body").append('<div class="lg-backdrop"></div>'),
              g(".lg-backdrop").css(
                "transition-duration",
                this.s.backdropDuration + "ms"
              ),
              i = 0;
            i < this.$items.length;
            i++
          )
            t += '<div class="lg-item"></div>';
          if (
            (this.s.controls &&
              1 < this.$items.length &&
              (n =
                '<div class="lg-actions"><button class="lg-prev "><i class="fas fa-arrow-left"></i>' +
                this.s.prevHtml +
                '</button><button class="lg-next"><i class="fas fa-arrow-right"></i>' +
                this.s.nextHtml +
                "</button></div>"),
            ".lg-sub-html" === this.s.appendSubHtmlTo &&
              (o = '<div class="lg-sub-html"></div>'),
            (e =
              '<div class="lg-outer ' +
              this.s.addClass +
              " " +
              this.s.startClass +
              '"><div class="lg" style="width:' +
              this.s.width +
              "; height:" +
              this.s.height +
              '"><div class="lg-inner">' +
              t +
              '</div><div class="lg-toolbar lg-group"><span class="lg-close lg-icon"><i class="fas fa-times"></i></span></div>' +
              n +
              o +
              "</div></div>"),
            g("body").append(e),
            (this.$outer = g(".lg-outer")),
            (this.$slide = this.$outer.find(".lg-item")),
            this.s.useLeft
              ? (this.$outer.addClass("lg-use-left"),
                (this.s.mode = "lg-slide"))
              : this.$outer.addClass("lg-use-css3"),
            r.setTop(),
            g(window).on("resize.lg orientationchange.lg", function () {
              setTimeout(function () {
                r.setTop();
              }, 100);
            }),
            this.$slide.eq(this.index).addClass("lg-current"),
            this.doCss()
              ? this.$outer.addClass("lg-css3")
              : (this.$outer.addClass("lg-css"), (this.s.speed = 0)),
            this.$outer.addClass(this.s.mode),
            this.s.enableDrag &&
              1 < this.$items.length &&
              this.$outer.addClass("lg-grab"),
            this.s.showAfterLoad && this.$outer.addClass("lg-show-after-load"),
            this.doCss())
          ) {
            var s = this.$outer.find(".lg-inner");
            s.css("transition-timing-function", this.s.cssEasing),
              s.css("transition-duration", this.s.speed + "ms");
          }
          setTimeout(function () {
            g(".lg-backdrop").addClass("in");
          }),
            setTimeout(function () {
              r.$outer.addClass("lg-visible");
            }, this.s.backdropDuration),
            this.s.download &&
              this.$outer
                .find(".lg-toolbar")
                .append(
                  '<a id="lg-download" target="_blank" download class="lg-download lg-icon"></a>'
                ),
            (this.prevScrollTop = g(window).scrollTop());
        }),
        (t.prototype.setTop = function () {
          if ("100%" !== this.s.height) {
            var e = g(window).height(),
              t = (e - parseInt(this.s.height, 10)) / 2,
              n = this.$outer.find(".lg");
            e >= parseInt(this.s.height, 10)
              ? n.css("top", t + "px")
              : n.css("top", "0px");
          }
        }),
        (t.prototype.doCss = function () {
          return !!(function () {
            var e = [
                "transition",
                "MozTransition",
                "WebkitTransition",
                "OTransition",
                "msTransition",
                "KhtmlTransition",
              ],
              t = document.documentElement,
              n = 0;
            for (n = 0; n < e.length; n++) if (e[n] in t.style) return 1;
          })();
        }),
        (t.prototype.isVideo = function (e, t) {
          var n;
          if (
            ((n = this.s.dynamic
              ? this.s.dynamicEl[t].html
              : this.$items.eq(t).attr("data-html")),
            !e)
          )
            return n
              ? { html5: !0 }
              : (console.error(
                  "lightGallery :- data-src is not provided on slide item " +
                    (t + 1) +
                    ". Please make sure the selector property is properly configured. More info - http://sachinchoolur.github.io/lightGallery/demos/html-markup.html"
                ),
                !1);
          var i = e.match(
              /\/\/(?:www\.)?youtu(?:\.be|be\.com|be-nocookie\.com)\/(?:watch\?v=|embed\/)?([a-z0-9\-\_\%]+)/i
            ),
            o = e.match(/\/\/(?:www\.)?vimeo.com\/([0-9a-z\-_]+)/i),
            r = e.match(/\/\/(?:www\.)?dai.ly\/([0-9a-z\-_]+)/i),
            s = e.match(
              /\/\/(?:www\.)?(?:vk\.com|vkontakte\.ru)\/(?:video_ext\.php\?)(.*)/i
            );
          return i
            ? { youtube: i }
            : o
            ? { vimeo: o }
            : r
            ? { dailymotion: r }
            : s
            ? { vk: s }
            : void 0;
        }),
        (t.prototype.counter = function () {
          this.s.counter &&
            g(this.s.appendCounterTo).append(
              '<div id="lg-counter"><span id="lg-counter-current">' +
                (parseInt(this.index, 10) + 1) +
                '</span> / <span id="lg-counter-all">' +
                this.$items.length +
                "</span></div>"
            );
        }),
        (t.prototype.addHtml = function (e) {
          var t,
            n,
            i = null;
          if (
            (this.s.dynamic
              ? this.s.dynamicEl[e].subHtmlUrl
                ? (t = this.s.dynamicEl[e].subHtmlUrl)
                : (i = this.s.dynamicEl[e].subHtml)
              : (n = this.$items.eq(e)).attr("data-sub-html-url")
              ? (t = n.attr("data-sub-html-url"))
              : ((i = n.attr("data-sub-html")),
                this.s.getCaptionFromTitleOrAlt &&
                  !i &&
                  (i = n.attr("title") || n.find("img").first().attr("alt"))),
            !t)
          )
            if (null != i) {
              var o = i.substring(0, 1);
              ("." !== o && "#" !== o) ||
                (i =
                  this.s.subHtmlSelectorRelative && !this.s.dynamic
                    ? n.find(i).html()
                    : g(i).html());
            } else i = "";
          ".lg-sub-html" === this.s.appendSubHtmlTo
            ? t
              ? this.$outer.find(this.s.appendSubHtmlTo).load(t)
              : this.$outer.find(this.s.appendSubHtmlTo).html(i)
            : t
            ? this.$slide.eq(e).load(t)
            : this.$slide.eq(e).append(i),
            null != i &&
              ("" === i
                ? this.$outer
                    .find(this.s.appendSubHtmlTo)
                    .addClass("lg-empty-html")
                : this.$outer
                    .find(this.s.appendSubHtmlTo)
                    .removeClass("lg-empty-html")),
            this.$el.trigger("onAfterAppendSubHtml.lg", [e]);
        }),
        (t.prototype.preload = function (e) {
          var t = 1,
            n = 1;
          for (
            t = 1;
            t <= this.s.preload && !(t >= this.$items.length - e);
            t++
          )
            this.loadContent(e + t, !1, 0);
          for (n = 1; n <= this.s.preload && !(e - n < 0); n++)
            this.loadContent(e - n, !1, 0);
        }),
        (t.prototype.loadContent = function (t, e, n) {
          function i(e) {
            for (var t = [], n = [], i = 0; i < e.length; i++) {
              var o = e[i].split(" ");
              "" === o[0] && o.splice(0, 1), n.push(o[0]), t.push(o[1]);
            }
            for (var r = g(window).width(), s = 0; s < t.length; s++)
              if (parseInt(t[s], 10) > r) {
                a = n[s];
                break;
              }
          }
          var o,
            a,
            r,
            s,
            l,
            u,
            c = this,
            d = !1;
          l = c.s.dynamic
            ? (c.s.dynamicEl[t].poster &&
                ((d = !0), (r = c.s.dynamicEl[t].poster)),
              (u = c.s.dynamicEl[t].html),
              (a = c.s.dynamicEl[t].src),
              c.s.dynamicEl[t].responsive &&
                i(c.s.dynamicEl[t].responsive.split(",")),
              (s = c.s.dynamicEl[t].srcset),
              c.s.dynamicEl[t].sizes)
            : (c.$items.eq(t).attr("data-poster") &&
                ((d = !0), (r = c.$items.eq(t).attr("data-poster"))),
              (u = c.$items.eq(t).attr("data-html")),
              (a =
                c.$items.eq(t).attr("href") || c.$items.eq(t).attr("data-src")),
              c.$items.eq(t).attr("data-responsive") &&
                i(c.$items.eq(t).attr("data-responsive").split(",")),
              (s = c.$items.eq(t).attr("data-srcset")),
              c.$items.eq(t).attr("data-sizes"));
          var p = !1;
          c.s.dynamic
            ? c.s.dynamicEl[t].iframe && (p = !0)
            : "true" === c.$items.eq(t).attr("data-iframe") && (p = !0);
          var h = c.isVideo(a, t);
          if (!c.$slide.eq(t).hasClass("lg-loaded")) {
            if (p)
              c.$slide
                .eq(t)
                .prepend(
                  '<div class="lg-video-cont lg-has-iframe" style="max-width:' +
                    c.s.iframeMaxWidth +
                    '"><div class="lg-video"><iframe class="lg-object" frameborder="0" src="' +
                    a +
                    '"  allowfullscreen="true"></iframe></div></div>'
                );
            else if (d) {
              var f;
              (f =
                h && h.youtube
                  ? "lg-has-youtube"
                  : h && h.vimeo
                  ? "lg-has-vimeo"
                  : "lg-has-html5"),
                c.$slide
                  .eq(t)
                  .prepend(
                    '<div class="lg-video-cont ' +
                      f +
                      ' "><div class="lg-video"><span class="lg-video-play"></span><img class="lg-object lg-has-poster" src="' +
                      r +
                      '" /></div></div>'
                  );
            } else
              h
                ? (c.$slide
                    .eq(t)
                    .prepend(
                      '<div class="lg-video-cont "><div class="lg-video"></div></div>'
                    ),
                  c.$el.trigger("hasVideo.lg", [t, a, u]))
                : c.$slide
                    .eq(t)
                    .prepend(
                      '<div class="lg-img-wrap"><img class="lg-object lg-image" src="' +
                        a +
                        '" /></div>'
                    );
            if (
              (c.$el.trigger("onAferAppendSlide.lg", [t]),
              (o = c.$slide.eq(t).find(".lg-object")),
              l && o.attr("sizes", l),
              s)
            ) {
              o.attr("srcset", s);
              try {
                picturefill({ elements: [o[0]] });
              } catch (e) {
                console.warn(
                  "lightGallery :- If you want srcset to be supported for older browser please include picturefil version 2 javascript library in your document."
                );
              }
            }
            ".lg-sub-html" !== this.s.appendSubHtmlTo && c.addHtml(t),
              c.$slide.eq(t).addClass("lg-loaded");
          }
          c.$slide
            .eq(t)
            .find(".lg-object")
            .on("load.lg error.lg", function () {
              var e = 0;
              n && !g("body").hasClass("lg-from-hash") && (e = n),
                setTimeout(function () {
                  c.$slide.eq(t).addClass("lg-complete"),
                    c.$el.trigger("onSlideItemLoad.lg", [t, n || 0]);
                }, e);
            }),
            h && h.html5 && !d && c.$slide.eq(t).addClass("lg-complete"),
            !0 === e &&
              (c.$slide.eq(t).hasClass("lg-complete")
                ? c.preload(t)
                : c.$slide
                    .eq(t)
                    .find(".lg-object")
                    .on("load.lg error.lg", function () {
                      c.preload(t);
                    }));
        }),
        (t.prototype.slide = function (e, t, n, i) {
          var o = this.$outer.find(".lg-current").index(),
            r = this;
          if (!r.lGalleryOn || o !== e) {
            var s = this.$slide.length,
              a = r.lGalleryOn ? this.s.speed : 0;
            if (!r.lgBusy) {
              var l, u, c;
              if (this.s.download)
                (l = r.s.dynamic
                  ? !1 !== r.s.dynamicEl[e].downloadUrl &&
                    (r.s.dynamicEl[e].downloadUrl || r.s.dynamicEl[e].src)
                  : "false" !== r.$items.eq(e).attr("data-download-url") &&
                    (r.$items.eq(e).attr("data-download-url") ||
                      r.$items.eq(e).attr("href") ||
                      r.$items.eq(e).attr("data-src")))
                  ? (g("#lg-download").attr("href", l),
                    r.$outer.removeClass("lg-hide-download"))
                  : r.$outer.addClass("lg-hide-download");
              if (
                (this.$el.trigger("onBeforeSlide.lg", [o, e, t, n]),
                (r.lgBusy = !0),
                clearTimeout(r.hideBartimeout),
                ".lg-sub-html" === this.s.appendSubHtmlTo &&
                  setTimeout(function () {
                    r.addHtml(e);
                  }, a),
                this.arrowDisable(e),
                i || (e < o ? (i = "prev") : o < e && (i = "next")),
                t)
              )
                this.$slide.removeClass(
                  "lg-prev-slide lg-current lg-next-slide"
                ),
                  2 < s
                    ? ((u = e - 1),
                      (c = e + 1),
                      ((0 === e && o === s - 1) || (e === s - 1 && 0 === o)) &&
                        ((c = 0), (u = s - 1)))
                    : ((u = 0), (c = 1)),
                  "prev" === i
                    ? r.$slide.eq(c).addClass("lg-next-slide")
                    : r.$slide.eq(u).addClass("lg-prev-slide"),
                  r.$slide.eq(e).addClass("lg-current");
              else
                r.$outer.addClass("lg-no-trans"),
                  this.$slide.removeClass("lg-prev-slide lg-next-slide"),
                  "prev" === i
                    ? (this.$slide.eq(e).addClass("lg-prev-slide"),
                      this.$slide.eq(o).addClass("lg-next-slide"))
                    : (this.$slide.eq(e).addClass("lg-next-slide"),
                      this.$slide.eq(o).addClass("lg-prev-slide")),
                  setTimeout(function () {
                    r.$slide.removeClass("lg-current"),
                      r.$slide.eq(e).addClass("lg-current"),
                      r.$outer.removeClass("lg-no-trans");
                  }, 50);
              r.lGalleryOn
                ? (setTimeout(function () {
                    r.loadContent(e, !0, 0);
                  }, this.s.speed + 50),
                  setTimeout(function () {
                    (r.lgBusy = !1),
                      r.$el.trigger("onAfterSlide.lg", [o, e, t, n]);
                  }, this.s.speed))
                : (r.loadContent(e, !0, r.s.backdropDuration),
                  (r.lgBusy = !1),
                  r.$el.trigger("onAfterSlide.lg", [o, e, t, n])),
                (r.lGalleryOn = !0),
                this.s.counter && g("#lg-counter-current").text(e + 1);
            }
            r.index = e;
          }
        }),
        (t.prototype.goToNextSlide = function (e) {
          var t = this,
            n = t.s.loop;
          e && t.$slide.length < 3 && (n = !1),
            t.lgBusy ||
              (t.index + 1 < t.$slide.length
                ? (t.index++,
                  t.$el.trigger("onBeforeNextSlide.lg", [t.index]),
                  t.slide(t.index, e, !1, "next"))
                : n
                ? ((t.index = 0),
                  t.$el.trigger("onBeforeNextSlide.lg", [t.index]),
                  t.slide(t.index, e, !1, "next"))
                : t.s.slideEndAnimatoin &&
                  !e &&
                  (t.$outer.addClass("lg-right-end"),
                  setTimeout(function () {
                    t.$outer.removeClass("lg-right-end");
                  }, 400)));
        }),
        (t.prototype.goToPrevSlide = function (e) {
          var t = this,
            n = t.s.loop;
          e && t.$slide.length < 3 && (n = !1),
            t.lgBusy ||
              (0 < t.index
                ? (t.index--,
                  t.$el.trigger("onBeforePrevSlide.lg", [t.index, e]),
                  t.slide(t.index, e, !1, "prev"))
                : n
                ? ((t.index = t.$items.length - 1),
                  t.$el.trigger("onBeforePrevSlide.lg", [t.index, e]),
                  t.slide(t.index, e, !1, "prev"))
                : t.s.slideEndAnimatoin &&
                  !e &&
                  (t.$outer.addClass("lg-left-end"),
                  setTimeout(function () {
                    t.$outer.removeClass("lg-left-end");
                  }, 400)));
        }),
        (t.prototype.keyPress = function () {
          var t = this;
          1 < this.$items.length &&
            g(window).on("keyup.lg", function (e) {
              1 < t.$items.length &&
                (37 === e.keyCode && (e.preventDefault(), t.goToPrevSlide()),
                39 === e.keyCode && (e.preventDefault(), t.goToNextSlide()));
            }),
            g(window).on("keydown.lg", function (e) {
              !0 === t.s.escKey &&
                27 === e.keyCode &&
                (e.preventDefault(),
                t.$outer.hasClass("lg-thumb-open")
                  ? t.$outer.removeClass("lg-thumb-open")
                  : t.destroy());
            });
        }),
        (t.prototype.arrow = function () {
          var e = this;
          this.$outer.find(".lg-prev").on("click.lg", function () {
            e.goToPrevSlide();
          }),
            this.$outer.find(".lg-next").on("click.lg", function () {
              e.goToNextSlide();
            });
        }),
        (t.prototype.arrowDisable = function (e) {
          !this.s.loop &&
            this.s.hideControlOnEnd &&
            (e + 1 < this.$slide.length
              ? this.$outer
                  .find(".lg-next")
                  .removeAttr("disabled")
                  .removeClass("disabled")
              : this.$outer
                  .find(".lg-next")
                  .attr("disabled", "disabled")
                  .addClass("disabled"),
            0 < e
              ? this.$outer
                  .find(".lg-prev")
                  .removeAttr("disabled")
                  .removeClass("disabled")
              : this.$outer
                  .find(".lg-prev")
                  .attr("disabled", "disabled")
                  .addClass("disabled"));
        }),
        (t.prototype.setTranslate = function (e, t, n) {
          this.s.useLeft
            ? e.css("left", t)
            : e.css({
                transform: "translate3d(" + t + "px, " + n + "px, 0px)",
              });
        }),
        (t.prototype.touchMove = function (e, t) {
          var n = t - e;
          15 < Math.abs(n) &&
            (this.$outer.addClass("lg-dragging"),
            this.setTranslate(this.$slide.eq(this.index), n, 0),
            this.setTranslate(
              g(".lg-prev-slide"),
              -this.$slide.eq(this.index).width() + n,
              0
            ),
            this.setTranslate(
              g(".lg-next-slide"),
              this.$slide.eq(this.index).width() + n,
              0
            ));
        }),
        (t.prototype.touchEnd = function (e) {
          var t = this;
          "lg-slide" !== t.s.mode && t.$outer.addClass("lg-slide"),
            this.$slide
              .not(".lg-current, .lg-prev-slide, .lg-next-slide")
              .css("opacity", "0"),
            setTimeout(function () {
              t.$outer.removeClass("lg-dragging"),
                e < 0 && Math.abs(e) > t.s.swipeThreshold
                  ? t.goToNextSlide(!0)
                  : 0 < e && Math.abs(e) > t.s.swipeThreshold
                  ? t.goToPrevSlide(!0)
                  : Math.abs(e) < 5 && t.$el.trigger("onSlideClick.lg"),
                t.$slide.removeAttr("style");
            }),
            setTimeout(function () {
              t.$outer.hasClass("lg-dragging") ||
                "lg-slide" === t.s.mode ||
                t.$outer.removeClass("lg-slide");
            }, t.s.speed + 100);
        }),
        (t.prototype.enableSwipe = function () {
          var t = this,
            n = 0,
            i = 0,
            o = !1;
          t.s.enableSwipe &&
            t.doCss() &&
            (t.$slide.on("touchstart.lg", function (e) {
              t.$outer.hasClass("lg-zoomed") ||
                t.lgBusy ||
                (e.preventDefault(),
                t.manageSwipeClass(),
                (n = e.originalEvent.targetTouches[0].pageX));
            }),
            t.$slide.on("touchmove.lg", function (e) {
              t.$outer.hasClass("lg-zoomed") ||
                (e.preventDefault(),
                (i = e.originalEvent.targetTouches[0].pageX),
                t.touchMove(n, i),
                (o = !0));
            }),
            t.$slide.on("touchend.lg", function () {
              t.$outer.hasClass("lg-zoomed") ||
                (o
                  ? ((o = !1), t.touchEnd(i - n))
                  : t.$el.trigger("onSlideClick.lg"));
            }));
        }),
        (t.prototype.enableDrag = function () {
          var t = this,
            n = 0,
            i = 0,
            o = !1,
            r = !1;
          t.s.enableDrag &&
            t.doCss() &&
            (t.$slide.on("mousedown.lg", function (e) {
              t.$outer.hasClass("lg-zoomed") ||
                t.lgBusy ||
                g(e.target).text().trim() ||
                (e.preventDefault(),
                t.manageSwipeClass(),
                (n = e.pageX),
                (o = !0),
                (t.$outer.scrollLeft += 1),
                --t.$outer.scrollLeft,
                t.$outer.removeClass("lg-grab").addClass("lg-grabbing"),
                t.$el.trigger("onDragstart.lg"));
            }),
            g(window).on("mousemove.lg", function (e) {
              o &&
                ((r = !0),
                (i = e.pageX),
                t.touchMove(n, i),
                t.$el.trigger("onDragmove.lg"));
            }),
            g(window).on("mouseup.lg", function (e) {
              r
                ? ((r = !1), t.touchEnd(i - n), t.$el.trigger("onDragend.lg"))
                : (g(e.target).hasClass("lg-object") ||
                    g(e.target).hasClass("lg-video-play")) &&
                  t.$el.trigger("onSlideClick.lg"),
                o &&
                  ((o = !1),
                  t.$outer.removeClass("lg-grabbing").addClass("lg-grab"));
            }));
        }),
        (t.prototype.manageSwipeClass = function () {
          var e = this.index + 1,
            t = this.index - 1;
          this.s.loop &&
            2 < this.$slide.length &&
            (0 === this.index
              ? (t = this.$slide.length - 1)
              : this.index === this.$slide.length - 1 && (e = 0)),
            this.$slide.removeClass("lg-next-slide lg-prev-slide"),
            -1 < t && this.$slide.eq(t).addClass("lg-prev-slide"),
            this.$slide.eq(e).addClass("lg-next-slide");
        }),
        (t.prototype.mousewheel = function () {
          var t = this;
          t.$outer.on("mousewheel.lg", function (e) {
            e.deltaY &&
              (0 < e.deltaY ? t.goToPrevSlide() : t.goToNextSlide(),
              e.preventDefault());
          });
        }),
        (t.prototype.closeGallery = function () {
          var t = this,
            n = !1;
          this.$outer.find(".lg-close").on("click.lg", function () {
            t.destroy();
          }),
            t.s.closable &&
              (t.$outer.on("mousedown.lg", function (e) {
                n = !!(
                  g(e.target).is(".lg-outer") ||
                  g(e.target).is(".lg-item ") ||
                  g(e.target).is(".lg-img-wrap")
                );
              }),
              t.$outer.on("mousemove.lg", function () {
                n = !1;
              }),
              t.$outer.on("mouseup.lg", function (e) {
                (g(e.target).is(".lg-outer") ||
                  g(e.target).is(".lg-item ") ||
                  (g(e.target).is(".lg-img-wrap") && n)) &&
                  (t.$outer.hasClass("lg-dragging") || t.destroy());
              }));
        }),
        (t.prototype.destroy = function (e) {
          var t = this;
          e ||
            (t.$el.trigger("onBeforeClose.lg"),
            g(window).scrollTop(t.prevScrollTop)),
            e &&
              (t.s.dynamic || this.$items.off("click.lg click.lgcustom"),
              g.removeData(t.el, "lightGallery")),
            this.$el.off(".lg.tm"),
            g.each(g.fn.lightGallery.modules, function (e) {
              t.modules[e] && t.modules[e].destroy();
            }),
            (this.lGalleryOn = !1),
            clearTimeout(t.hideBartimeout),
            (this.hideBartimeout = !1),
            g(window).off(".lg"),
            g("body").removeClass("lg-on lg-from-hash"),
            t.$outer && t.$outer.removeClass("lg-visible"),
            g(".lg-backdrop").removeClass("in"),
            setTimeout(function () {
              t.$outer && t.$outer.remove(),
                g(".lg-backdrop").remove(),
                e || t.$el.trigger("onCloseAfter.lg");
            }, t.s.backdropDuration + 50);
        }),
        (g.fn.lightGallery = function (e) {
          return this.each(function () {
            if (g.data(this, "lightGallery"))
              try {
                g(this).data("lightGallery").init();
              } catch (e) {
                console.error("lightGallery has not initiated properly");
              }
            else g.data(this, "lightGallery", new t(this, e));
          });
        }),
        (g.fn.lightGallery.modules = {});
    })();
  }),
  (function (e) {
    "function" == typeof define && define.amd
      ? define([], e)
      : "undefined" != typeof module && null !== module && module.exports
      ? (module.exports = e)
      : e();
  })(function () {
    var o = Object.assign || (window.jQuery && jQuery.extend),
      g = 8,
      r =
        window.requestAnimationFrame ||
        window.webkitRequestAnimationFrame ||
        window.mozRequestAnimationFrame ||
        window.oRequestAnimationFrame ||
        window.msRequestAnimationFrame ||
        function (e, t) {
          return window.setTimeout(function () {
            e();
          }, 25);
        };
    function e(e, t) {
      t = t || { bubbles: !1, cancelable: !1, detail: void 0 };
      var n = document.createEvent("CustomEvent");
      return n.initCustomEvent(e, t.bubbles, t.cancelable, t.detail), n;
    }
    "function" != typeof window.CustomEvent &&
      ((e.prototype = window.Event.prototype), (window.CustomEvent = e));
    var i = { textarea: !0, input: !0, select: !0, button: !0 },
      s = { move: "mousemove", cancel: "mouseup dragstart", end: "mouseup" },
      a = { move: "touchmove", cancel: "touchend", end: "touchend" },
      l = /\s+/,
      u = { bubbles: !0, cancelable: !0 },
      t = "function" == typeof Symbol ? Symbol("events") : {};
    function c(e) {
      return e[t] || (e[t] = {});
    }
    function d(e, t, n, i) {
      t = t.split(l);
      var o,
        r = c(e),
        s = t.length;
      function a(e) {
        n(e, i);
      }
      for (; s--; )
        (r[(o = t[s])] || (r[o] = [])).push([n, a]), e.addEventListener(o, a);
    }
    function p(e, t, n) {
      t = t.split(l);
      var i,
        o,
        r,
        s = c(e),
        a = t.length;
      if (s)
        for (; a--; )
          if ((o = s[(i = t[a])]))
            for (r = o.length; r--; )
              o[r][0] === n &&
                (e.removeEventListener(i, o[r][1]), o.splice(r, 1));
    }
    function v(e, t, n) {
      var i = new CustomEvent(t, u);
      n && o(i, n), e.dispatchEvent(i);
    }
    function h(e) {
      var n = e,
        i = !1,
        o = !1;
      function t(e) {
        i ? (n(), r(t), (i = !(o = !0))) : (o = !1);
      }
      (this.kick = function (e) {
        (i = !0), o || t();
      }),
        (this.end = function (e) {
          var t = n;
          e &&
            (o
              ? ((n = i
                  ? function () {
                      t(), e();
                    }
                  : e),
                (i = !0))
              : e());
        });
    }
    function m() {}
    function f(e) {
      e.preventDefault();
    }
    function y(e, t) {
      var n, i;
      if (e.identifiedTouch) return e.identifiedTouch(t);
      for (n = -1, i = e.length; ++n < i; )
        if (e[n].identifier === t) return e[n];
    }
    function k(e, t) {
      var n = y(e.changedTouches, t.identifier);
      if (n && (n.pageX !== t.pageX || n.pageY !== t.pageY)) return n;
    }
    function n(e, t) {
      x(e, t, e, w);
    }
    function b(e, t) {
      w();
    }
    function w() {
      p(document, s.move, n), p(document, s.cancel, b);
    }
    function C(e) {
      p(document, a.move, e.touchmove), p(document, a.cancel, e.touchend);
    }
    function x(e, t, n, i) {
      var o,
        r,
        s,
        a,
        l,
        u,
        c,
        d,
        p,
        h = n.pageX - t.pageX,
        f = n.pageY - t.pageY;
      h * h + f * f < g * g ||
        ((r = t),
        (s = n),
        (a = h),
        (l = f),
        (u = i),
        (c = (o = e).targetTouches),
        (d = o.timeStamp - r.timeStamp),
        (p = {
          altKey: o.altKey,
          ctrlKey: o.ctrlKey,
          shiftKey: o.shiftKey,
          startX: r.pageX,
          startY: r.pageY,
          distX: a,
          distY: l,
          deltaX: a,
          deltaY: l,
          pageX: s.pageX,
          pageY: s.pageY,
          velocityX: a / d,
          velocityY: l / d,
          identifier: r.identifier,
          targetTouches: c,
          finger: c ? c.length : 1,
          enableMove: function () {
            (this.moveEnabled = !0), (this.enableMove = m), o.preventDefault();
          },
        }),
        v(r.target, "movestart", p),
        u(r));
    }
    function S(e, t) {
      var n = t.timer;
      (t.touch = e), (t.timeStamp = e.timeStamp), n.kick();
    }
    function T(e, t) {
      var n = t.target,
        i = t.event,
        o = t.timer;
      p(document, s.move, S),
        p(document, s.end, T),
        E(n, i, o, function () {
          setTimeout(function () {
            p(n, "click", f);
          }, 0);
        });
    }
    function A(e, t) {
      var n,
        i = t.target,
        o = t.event,
        r = t.timer;
      y(e.changedTouches, o.identifier) &&
        ((n = t),
        p(document, a.move, n.activeTouchmove),
        p(document, a.end, n.activeTouchend),
        E(i, o, r));
    }
    function E(e, t, n, i) {
      n.end(function () {
        return v(e, "moveend", t), i && i();
      });
    }
    if (
      (d(document, "mousedown", function (e) {
        var t;
        1 !== (t = e).which ||
          t.ctrlKey ||
          t.altKey ||
          i[e.target.tagName.toLowerCase()] ||
          (d(document, s.move, n, e), d(document, s.cancel, b, e));
      }),
      d(document, "touchstart", function (e) {
        if (!i[e.target.tagName.toLowerCase()]) {
          var t = e.changedTouches[0],
            n = {
              target: t.target,
              pageX: t.pageX,
              pageY: t.pageY,
              identifier: t.identifier,
              touchmove: function (e, t) {
                !(function (e, t) {
                  var n = k(e, t);
                  if (!n) return;
                  x(e, t, n, C);
                })(e, t);
              },
              touchend: function (e, t) {
                !(function (e, t) {
                  if (!y(e.changedTouches, t.identifier)) return;
                  C(t);
                })(e, t);
              },
            };
          d(document, a.move, n.touchmove, n),
            d(document, a.cancel, n.touchend, n);
        }
      }),
      d(document, "movestart", function (e) {
        if (!e.defaultPrevented && e.moveEnabled) {
          var t = {
              startX: e.startX,
              startY: e.startY,
              pageX: e.pageX,
              pageY: e.pageY,
              distX: e.distX,
              distY: e.distY,
              deltaX: e.deltaX,
              deltaY: e.deltaY,
              velocityX: e.velocityX,
              velocityY: e.velocityY,
              identifier: e.identifier,
              targetTouches: e.targetTouches,
              finger: e.finger,
            },
            n = {
              target: e.target,
              event: t,
              timer: new h(function (e) {
                (function (e, t, n) {
                  var i = n - e.timeStamp;
                  (e.distX = t.pageX - e.startX),
                    (e.distY = t.pageY - e.startY),
                    (e.deltaX = t.pageX - e.pageX),
                    (e.deltaY = t.pageY - e.pageY),
                    (e.velocityX = 0.3 * e.velocityX + (0.7 * e.deltaX) / i),
                    (e.velocityY = 0.3 * e.velocityY + (0.7 * e.deltaY) / i),
                    (e.pageX = t.pageX),
                    (e.pageY = t.pageY);
                })(t, n.touch, n.timeStamp),
                  v(n.target, "move", t);
              }),
              touch: void 0,
              timeStamp: e.timeStamp,
            };
          void 0 === e.identifier
            ? (d(e.target, "click", f),
              d(document, s.move, S, n),
              d(document, s.end, T, n))
            : ((n.activeTouchmove = function (e, t) {
                var n, i, o, r, s;
                (n = e),
                  (o = (i = t).event),
                  (r = i.timer),
                  (s = k(n, o)) &&
                    (n.preventDefault(),
                    (o.targetTouches = n.targetTouches),
                    (i.touch = s),
                    (i.timeStamp = n.timeStamp),
                    r.kick());
              }),
              (n.activeTouchend = function (e, t) {
                A(e, t);
              }),
              d(document, a.move, n.activeTouchmove, n),
              d(document, a.end, n.activeTouchend, n));
        }
      }),
      window.jQuery)
    ) {
      var $ = "startX startY pageX pageY distX distY deltaX deltaY velocityX velocityY".split(
        " "
      );
      (jQuery.event.special.movestart = {
        setup: function () {
          return d(this, "movestart", _), !1;
        },
        teardown: function () {
          return p(this, "movestart", _), !1;
        },
        add: P,
      }),
        (jQuery.event.special.move = {
          setup: function () {
            return d(this, "movestart", D), !1;
          },
          teardown: function () {
            return p(this, "movestart", D), !1;
          },
          add: P,
        }),
        (jQuery.event.special.moveend = {
          setup: function () {
            return d(this, "movestart", F), !1;
          },
          teardown: function () {
            return p(this, "movestart", F), !1;
          },
          add: P,
        });
    }
    function _(e) {
      e.enableMove();
    }
    function D(e) {
      e.enableMove();
    }
    function F(e) {
      e.enableMove();
    }
    function P(e) {
      var i = e.handler;
      e.handler = function (e) {
        for (var t, n = $.length; n--; ) e[(t = $[n])] = e.originalEvent[t];
        i.apply(this, arguments);
      };
    }
  }),
  (function (b) {
    b.fn.twentytwenty = function (k) {
      k = b.extend(
        {
          default_offset_pct: 0.5,
          orientation: "horizontal",
          before_label: "Before",
          after_label: "After",
          no_overlay: !1,
          move_slider_on_hover: !1,
          move_with_handle_only: !0,
          click_to_move: !1,
        },
        k
      );
      return this.each(function () {
        var t = k.default_offset_pct,
          s = b(this),
          a = k.orientation,
          e = "vertical" === a ? "down" : "left",
          n = "vertical" === a ? "up" : "right";
        if (
          (s.wrap(
            "<div class='twentytwenty-wrapper twentytwenty-" + a + "'></div>"
          ),
          !k.no_overlay)
        ) {
          s.append("<div class='twentytwenty-overlay'></div>");
          var i = s.find(".twentytwenty-overlay");
          i.append(
            "<div class='twentytwenty-before-label' data-content='" +
              k.before_label +
              "'></div>"
          ),
            i.append(
              "<div class='twentytwenty-after-label' data-content='" +
                k.after_label +
                "'></div>"
            );
        }
        var l = s.find("img:first"),
          u = s.find("img:last");
        s.append("<div class='twentytwenty-handle'></div>");
        var c = s.find(".twentytwenty-handle");
        c.append("<span class='twentytwenty-" + e + "-arrow'></span>"),
          c.append("<span class='twentytwenty-" + n + "-arrow'></span>"),
          s.addClass("twentytwenty-container"),
          l.addClass("twentytwenty-before"),
          u.addClass("twentytwenty-after");
        function o(e) {
          var t,
            n,
            i,
            o,
            r =
              ((t = e),
              (n = l.width()),
              (i = l.height()),
              { w: n + "px", h: i + "px", cw: t * n + "px", ch: t * i + "px" });
          c.css(
            "vertical" === a ? "top" : "left",
            "vertical" === a ? r.ch : r.cw
          ),
            (o = r),
            "vertical" === a
              ? (l.css("clip", "rect(0," + o.w + "," + o.ch + ",0)"),
                u.css("clip", "rect(" + o.ch + "," + o.w + "," + o.h + ",0)"))
              : (l.css("clip", "rect(0," + o.cw + "," + o.h + ",0)"),
                u.css("clip", "rect(0," + o.w + "," + o.h + "," + o.cw + ")")),
            s.css("height", o.h);
        }
        function r(e, t) {
          var n, i, o;
          return (
            (n = "vertical" === a ? (t - g) / m : (e - f) / v),
            (i = 0),
            (o = 1),
            Math.max(i, Math.min(o, n))
          );
        }
        b(window).on("resize.twentytwenty", function (e) {
          o(t);
        });
        function d(e) {
          ((((e.distX > e.distY && e.distX < -e.distY) ||
            (e.distX < e.distY && e.distX > -e.distY)) &&
            "vertical" !== a) ||
            (((e.distX < e.distY && e.distX < -e.distY) ||
              (e.distX > e.distY && e.distX > -e.distY)) &&
              "vertical" === a)) &&
            e.preventDefault(),
            s.addClass("active"),
            (f = s.offset().left),
            (g = s.offset().top),
            (v = l.width()),
            (m = l.height());
        }
        function p(e) {
          s.hasClass("active") && ((t = r(e.pageX, e.pageY)), o(t));
        }
        function h() {
          s.removeClass("active");
        }
        var f = 0,
          g = 0,
          v = 0,
          m = 0,
          y = k.move_with_handle_only ? c : s;
        y.on("movestart", d),
          y.on("move", p),
          y.on("moveend", h),
          k.move_slider_on_hover &&
            (s.on("mouseenter", d),
            s.on("mousemove", p),
            s.on("mouseleave", h)),
          c.on("touchmove", function (e) {
            e.preventDefault();
          }),
          s.find("img").on("mousedown", function (e) {
            e.preventDefault();
          }),
          k.click_to_move &&
            s.on("click", function (e) {
              (f = s.offset().left),
                (g = s.offset().top),
                (v = l.width()),
                (m = l.height()),
                (t = r(e.pageX, e.pageY)),
                o(t);
            }),
          b(window).trigger("resize.twentytwenty");
      });
    };
  })(jQuery);
